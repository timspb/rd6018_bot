"""Read-only provider adapting the preserved V1/V2 runtime to V3 UI data."""

from __future__ import annotations

import inspect
from dataclasses import replace
from typing import Any, Mapping

from runtime.ui.models import (
    ChargeView,
    DiagnosticsView,
    EntityStatusItem,
    EntityStatusView,
    JournalView,
    RuntimeUISnapshot,
    SafetyView,
    TelemetryView,
)

from .journal_read_service import EventJournalReadService
from .operator_read_source import DiagnosticAuthority, HmiProcessState, OperatorReadSource
from .operator_snapshot import OperatorSnapshot
from .operator_views import OperatorDetailsView, ServiceDetailsView
from .operator_actions import OperatorActionsView
from .operator_button_rules import actions_for_hmi, actions_for_snapshot
from .intents import IntentDispatcher, OperatorIntent


class OperatorSnapshotProvider:
    """Expose sanitized operator views from an explicit read source.

    The provider never receives the production runtime object and never creates
    command handlers.  Composition supplies the read-only source and, when
    mutation intents are enabled, a pre-built dispatcher.
    """

    def __init__(
        self,
        source: OperatorReadSource,
        *,
        intent_dispatcher: IntentDispatcher | None = None,
        event_journal_reader: EventJournalReadService | None = None,
    ) -> None:
        if not isinstance(source, OperatorReadSource):
            raise TypeError("OperatorSnapshotProvider requires OperatorReadSource")
        self._source = source
        self._event_journal_reader = event_journal_reader or EventJournalReadService()
        self.intent_dispatcher = intent_dispatcher or IntentDispatcher()

    async def get_operator_snapshot(self) -> OperatorSnapshot:
        live = await self._source.read_live()
        hmi = self._source.hmi_state(live)
        return self._build_snapshot(live, hmi)

    async def get_diagnostics(self) -> DiagnosticsView:
        live = await self._source.read_live()
        return self._diagnostics(live)

    async def get_operator_details(self) -> OperatorDetailsView:
        live = await self._source.read_live()
        hmi = self._source.hmi_state(live)
        controller = self._source.controller()
        timers = {}
        if controller is not None and bool(getattr(controller, "is_active", False)):
            try:
                timers = dict(controller.get_timers() or {})
            except Exception:
                timers = {}
        request = self._source.manual_request()
        return OperatorDetailsView(
            process_state=hmi.process_state.value,
            authority=hmi.authority.value,
            output_on=bool(hmi.output_on),
            regulator=hmi.regulator,
            battery_label=hmi.battery_label,
            battery_voltage_v=hmi.battery_voltage_v,
            current_a=hmi.current_a,
            battery_temp_c=hmi.battery_temp_c,
            psu_temp_c=hmi.psu_temp_c,
            target_voltage_v=hmi.target_voltage_v,
            current_limit_a=hmi.current_limit_a,
            safety=hmi.safety,
            progress=hmi.progress,
            observer_state=self._observer_state(),
            observer_status=str(getattr(self._source.observer(), "last_status", "") or ""),
            stage=str(getattr(controller, "current_stage", "") or ""),
            battery_type=str(getattr(controller, "battery_type", "") or ""),
            capacity_ah=self._number(getattr(controller, "ah_capacity", None)),
            stage_time=str(timers.get("stage_time", hmi.stage_time or "—")),
            total_time=str(timers.get("total_time", hmi.total_time or "—")),
            remaining_time=str(timers.get("remaining_time", "—")),
            delivered_ah=hmi.delivered_ah if hmi.delivered_ah is not None else self._number(live.get("ah")),
            input_voltage_v=self._number(live.get("input_voltage")),
            uptime=str(live.get("uptime") or "—"),
            manual_capacity_ah=self._number(getattr(request, "capacity_ah", None)),
        )

    async def get_service_details(self) -> ServiceDetailsView:
        live = await self._source.read_live()
        hmi = self._source.hmi_state(live)
        controller = self._source.controller()
        snapshot = {}
        if controller is not None:
            try:
                snapshot = dict(controller.ui_support_snapshot() or {})
            except Exception:
                snapshot = {}
        return ServiceDetailsView(
            authority=hmi.authority.value,
            output_on=bool(hmi.output_on),
            regulator=hmi.regulator,
            stage=str(getattr(controller, "current_stage", "—") or "—"),
            v2_analysis="available" if snapshot.get("runtime_analysis_available") else "unavailable",
            decision=str(snapshot.get("decision") or "—"),
            ovp_v=self._number(live.get("ovp")),
            ocp_a=self._number(live.get("ocp")),
            protection=str(live.get("protection_code") or "—"),
            regulation=str(live.get("regulation_code") or "—"),
            heartbeat=str(live.get("last_reported") or live.get("last_updated") or "—"),
        )

    async def get_operator_actions(self, *, snapshot: OperatorSnapshot | None = None) -> OperatorActionsView:
        # Reuse the complete home read model for every state.  A second live
        # read can otherwise change ownership between the text and keyboard;
        # HANDS_OFF must never be remapped to a safety fault in that gap.
        if snapshot is not None:
            return actions_for_snapshot(snapshot)
        live = await self._source.read_live()
        hmi = self._source.hmi_state(live)
        process = getattr(getattr(hmi, "process_state", None), "value", "")
        authority = getattr(getattr(hmi, "authority", None), "value", "")
        paused = self._source.pause_active() if process in {"running", "paused"} and authority in {"auto", "manual"} else None
        return actions_for_hmi(hmi, paused=paused)

    def _observer_state(self) -> str:
        observer = self._source.observer()
        raw = getattr(observer, "state", "") if observer is not None else ""
        return str(getattr(raw, "value", raw) or "")

    @staticmethod
    def _number(value: Any) -> float | None:
        try:
            return None if value is None else float(value)
        except (TypeError, ValueError):
            return None

    async def get_event_journal(self, limit: int | None = 50) -> JournalView:
        return await self._event_journal_reader.aread(limit)

    async def get_entity_statuses(self) -> EntityStatusView:
        try:
            rows = await self._source.read_entities_status()
        except Exception as exc:
            return EntityStatusView(error=f"{type(exc).__name__}: {exc}")
        items = tuple(
            EntityStatusItem(
                key=str(row.get("key") or ""),
                state=row.get("state"),
                status=str(row.get("status") or "unknown"),
                unit=str(row.get("unit") or ""),
                friendly_name=str(row.get("friendly_name") or ""),
            )
            for row in rows
        )
        return EntityStatusView(items=items)

    async def get_journal(self, limit: int = 20) -> tuple[str, ...]:
        if limit < 0:
            raise ValueError("limit must not be negative")
        recorder = self._source.journal()
        if recorder is None or not callable(getattr(recorder, "tail", None)):
            return ()
        entries = recorder.tail(limit)
        if inspect.isawaitable(entries):
            entries = await entries
        return tuple(self._source.format_journal_entry(entry) for entry in entries)

    async def submit_intent(self, intent: Any):
        """Route read-only intents; execution intents remain unmigrated."""
        from runtime.ui.commands.models import CommandResult, CommandStatus

        if not isinstance(intent, OperatorIntent):
            return CommandResult(CommandStatus.REJECTED, "invalid_operator_intent")
        return await self.intent_dispatcher.dispatch(intent)

    @staticmethod
    def hmi_state_from_snapshot(snapshot: OperatorSnapshot):
        """Adapt sanitized V3 data to the preserved renderer's data model."""
        return OperatorReadSource.hmi_from_snapshot(snapshot)

    def _build_snapshot(self, live: Mapping[str, Any], hmi: Any) -> OperatorSnapshot:
        fresh = self._source.freshness(live, ("switch", "battery_voltage", "current", "protection_code", "regulation_code"))
        state = self._state(hmi, live, fresh)
        stage = str(getattr(self._source.controller(), "current_stage", "") or "")
        if not stage:
            stage = str(getattr(hmi, "title", "IDLE") or "IDLE")
        faults = self._faults(live, hmi)
        diagnostics = self._diagnostics(live, faults=faults)
        safety = SafetyView(
            allowed=not faults and fresh,
            reason="; ".join(faults) if faults else ("telemetry_stale" if not fresh else ""),
            violations=faults,
        )
        authority = getattr(hmi, "authority", "")
        authority = getattr(authority, "value", authority)
        charge = ChargeView(
            stage=stage,
            program=str(authority or ""),
            phase=str(getattr(hmi, "regulator", "") or "") or None,
            timer_text=str(getattr(hmi, "stage_time", "") or getattr(hmi, "total_time", "") or ""),
            waiting_for=(
                str(getattr(hmi, "progress", "") or "") or None
                if authority != "manual"
                else None
            ),
            targets={"voltage": getattr(hmi, "target_voltage_v", None), "current": getattr(hmi, "current_limit_a", None)},
            evidence={"finish": getattr(hmi, "finish_evidence", None), "stage_status": getattr(hmi, "stage_status", "")},
        )
        telemetry = TelemetryView(
            voltage=getattr(hmi, "battery_voltage_v", None),
            current=getattr(hmi, "current_a", None),
            temperature=getattr(hmi, "battery_temp_c", None),
            psu_temperature=getattr(hmi, "psu_temp_c", None),
            accumulated_ah=getattr(hmi, "delivered_ah", None),
        )
        runtime_snapshot = RuntimeUISnapshot(
            charge=charge,
            battery={"label": getattr(hmi, "battery_label", "")},
            telemetry=telemetry,
            diagnostics=diagnostics,
            safety=safety,
            output={"enabled": getattr(hmi, "output_on", None), "power_w": getattr(hmi, "power_w", None)},
            journal_tail=(),
        )
        snapshot = OperatorSnapshot(
            state=state,
            snapshot=runtime_snapshot,
            faults=faults,
            telemetry_fresh=fresh,
            manual_interrupted=bool(getattr(hmi, "manual_interrupted", False)),
            process_state=str(getattr(getattr(hmi, "process_state", None), "value", "") or ""),
        )
        # Published capabilities must match the actual one-owner selector used
        # by the Telegram keyboard for this exact snapshot.
        return replace(snapshot, available_actions=tuple(
            item.action.value for item in actions_for_snapshot(snapshot).available_actions
        ))

    @staticmethod
    def _state(hmi: Any, live: Mapping[str, Any], fresh: bool) -> str:
        process = getattr(hmi, "process_state", None)
        if process in {HmiProcessState.RUNNING, HmiProcessState.PAUSED, HmiProcessState.STORAGE, HmiProcessState.ADOPTED_MIX}:
            return "CHARGING"
        if process is HmiProcessState.HANDS_OFF:
            return "HANDS_OFF"
        if process in {HmiProcessState.CONTAINMENT, HmiProcessState.INTERRUPTED} or not fresh:
            return "FAULT"
        if str(getattr(hmi, "attention", "normal")) == "alarm":
            return "FAULT"
        return "IDLE"

    @staticmethod
    def _faults(live: Mapping[str, Any], hmi: Any) -> tuple[str, ...]:
        faults = []
        if str(getattr(hmi, "attention", "normal")) == "alarm":
            faults.append(str(getattr(hmi, "safety", "safety_alarm")))
        if str(live.get("ovp_triggered", "")).lower() in {"on", "true", "1"}:
            faults.append("OVP")
        if str(live.get("ocp_triggered", "")).lower() in {"on", "true", "1"}:
            faults.append("OCP")
        return tuple(dict.fromkeys(faults))

    def _diagnostics(self, live: Mapping[str, Any], *, faults: tuple[str, ...] = ()) -> DiagnosticsView:
        report = next((self._source.get(name) for name in ("battery_diagnostic_report", "diagnostic_report") if self._source.get(name) is not None), None)
        decision = getattr(report, "authority", report)
        authority = getattr(decision, "value", decision) or DiagnosticAuthority.ALLOW.value
        reasons = tuple(str(x) for x in (getattr(decision, "reasons", ()) or ()))
        return DiagnosticsView(
            authority=str(authority),
            hypotheses=tuple(str(x) for x in faults),
            reasons=reasons or faults,
        )
