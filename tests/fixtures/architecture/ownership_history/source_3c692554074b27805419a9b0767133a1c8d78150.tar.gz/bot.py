"""Production entrypoint for the modular RD6018 runtime.

Production composition imports :mod:`runtime.production_runtime` directly and
exposes only composition-owned application lifecycle from this module.
"""
from __future__ import annotations

import asyncio
import os

from runtime import production_runtime as _runtime_substrate
from application.operator_snapshot_provider import OperatorSnapshotProvider
from application.operator_read_source import OperatorReadSource
from application.operator_intent_factory import build_operator_intent_dispatcher
from diagnostic_persistence import install_diagnostic_persistence
from manual_context import install_manual_context_ui
from operator_dashboard import install_operator_graph_dashboard
from operator_destructive_guard import install_operator_destructive_guard
from operator_hmi import install_operator_hmi
from runtime.ui.telegram.analysis import install_analysis_screen
from runtime.ui.telegram.charge import install_charge_program_screen
from runtime.ui.telegram.recipes import install_recipe_catalog_commands
from runtime.charge.programs.recipe_library import RecipeLibrary
from runtime.charge.programs.recipe_catalog import RecipeCatalog
from runtime.ui.telegram.custom import install_custom_cancel_route
from runtime.ui.telegram.details import install_operator_details_screen
from runtime.ui.telegram.entities import install_entities_screen
from runtime.ui.telegram.help import install_help_screen
from runtime.ui.telegram.home import install_home_command
from runtime.ui.telegram.journal import install_journal_screen
from runtime.ui.telegram.off_conditions import install_off_conditions_screen
from runtime.ui.telegram.service import install_service_details_screen
from runtime.ui.telegram.stats import install_stats_screen
from operator_managed_stop import install_operator_managed_stop
from operator_mix_eligibility import install_mix_action_eligibility
from operator_navigation_recovery import install_operator_navigation_recovery
from operator_output_truth import install_operator_output_truth
from physical_test_control import install_physical_test_control
from physical_test_control_d062 import install_physical_test_control_d062
from physical_test_control_d062_delta import install_physical_test_control_d062_delta
from physical_test_control_diagnostic import install_physical_test_control_diagnostic
from physical_test_control_pb_mode import install_physical_test_control_pb_mode
from physical_test_control_programmed_readback import (
    install_physical_test_control_programmed_readback,
)
from physical_test_control_source_faults import install_physical_test_control_source_faults
from rd_autonomous_mode import install_rd_autonomous_final_hmi, install_rd_autonomous_mode
from rd_control_mode import install_rd_control_mode
from rd_hands_off_background import install_hands_off_background_isolation
from rd_hands_off_release import install_rd_hands_off_release
from rd_live_adoption import install_rd_live_adoption
from rd_managed_adoption import install_managed_live_adoption
from rd_managed_mix_adoption import install_managed_mix_adoption
from rd_ownership_recovery import install_rd_ownership_recovery
from rd_startup_authority import (
    install_rd_startup_authority_gate,
    reconcile_startup_authority,
)
from production_bootstrap import init_production_storage, install_production
from mix_mode import install_mix_only_mode
from runtime.startup_recovery import StartupRecovery


def _env_enabled(name: str, default: bool = True) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return bool(default)
    return str(raw).strip().lower() not in {"0", "false", "no", "off", "disabled"}


class ProductionComposition:
    """Explicit production composition owner for ERADICATION-08.

    Construction is side-effect free. compose() applies the preserved
    installer graph exactly once and captures the resulting lifecycle owners.
    The historical runtime is a compatibility substrate, not the composition
    root itself.
    """

    def __init__(self, runtime: object) -> None:
        self.runtime = runtime
        self.composed = False

    def compose(self) -> "ProductionComposition":
        if self.composed:
            return self
        app = self.runtime
        # install_production() registers the sole Manual text middleware.
        # Optional battery identity is carried in that middleware, never in a second route.

        # Production controller + actuator safety are always installed. V2_UI controls only
        # presentation, exactly as documented; rolling the Telegram UI back must not remove
        # recipe envelopes, verified OFF, telemetry fail-close, or live protection readback.
        _ui_support_enabled = _env_enabled("V2_UI", True)
        install_production(app, install_ui=_ui_support_enabled)
        # Done/Storage intent is owned by canonical charge persistence and the
        # runtime restore/pause guards; composition does not patch controller methods.
        # Software-watchdog containment is owned directly by
        # runtime.production_runtime + runtime.safety.soft_watchdog; composition
        # does not replace the runtime loop.
        # Telegram bootstrap resilience is owned by telegram.runtime's transport
        # implementation; production composition does not patch bot methods.
        # Output register-18 promotion is owned by telemetry canonicalization before
        # runtime-safety captures its reader; no composition-time read wrapper is needed.
        # Vin chemistry authority and Cooling continuation validation are now owned
        # directly by the production runtime/controller; no composition wrapper is required.
        install_diagnostic_persistence(app)
        if _ui_support_enabled:
            install_mix_only_mode(app)
            install_manual_context_ui(app)

        # RD6018 is a general-purpose PSU above the Pb controller. Install this ownership
        # boundary last so HANDS_OFF blocks every already-composed bot actuator path while
        # leaving raw telemetry available and preserving the explicit operator-only OFF action.
        _rd_control_mode = install_rd_control_mode(app, install_ui=_ui_support_enabled)
        # AUTONOMOUS is a separate operation axis above HANDS_OFF. It requires a dedicated
        # persistent edge ACK and never treats plain HANDS_OFF as evidence of offline operation.
        _rd_autonomous_mode = install_rd_autonomous_mode(
            app,
            _rd_control_mode,
            install_ui=_ui_support_enabled,
        )
        # A deliberate HANDS_OFF request may also release an already-running AUTO/Manual
        # software session through the dedicated positively-ACKed live edge release. Ordinary
        # edge disarm remains verified-OFF only and does not enable AUTONOMOUS.
        install_rd_hands_off_release(app, _rd_control_mode)
        # While HANDS_OFF owns an externally-running RD program, the operator may attach the
        # read-only/safety-OFF Mix observer. It imports HA Recorder history as context only;
        # all Delta authority starts from fresh post-activation source reports.
        _rd_live_mix_observer = (
            install_rd_live_adoption(app, _rd_control_mode)
            if _ui_support_enabled
            else None
        )
        # D061 managed live adoption is a different transaction: it can acquire the local
        # dead-man around an already-ON HANDS_OFF Output, re-read the exact live program, and
        # only then cross durable HANDS_OFF -> PB_MANAGED as an Adopted Manual. Explicit
        # AUTONOMOUS must exit while Output is OFF and is never live-adopted here.
        _rd_managed_live_adoption = install_managed_live_adoption(
            app,
            _rd_control_mode,
            install_ui=_ui_support_enabled,
        )
        # D062/D063 builds a separate MIX_ADOPTED authority on the physically same D061 edge
        # primitive. It never masquerades as Manual/AUTO: prior active Mix time must be proven
        # by Recorder or explicitly declared, the remaining Ca/EFB/AGM hard budget is carried
        # into the managed session, Delta starts fresh after takeover, and normal completion is
        # verified OFF rather than SAFE_WAIT/Storage. Runtime-safety composition is installed
        # even with V2_UI disabled; the Telegram workflow itself follows V2_UI.
        _rd_managed_mix_adoption = install_managed_mix_adoption(
            app,
            _rd_control_mode,
            _rd_managed_live_adoption,
            install_ui=_ui_support_enabled,
        )
        _physical_test_control = install_physical_test_control(app)
        # Physical validation also needs one safe inverse ownership transition for OFF-only
        # bench setup. This typed hook delegates to the existing RdControlModeManager and is
        # narrower than the Telegram operator action: no parameters, no actuator writes, clean
        # lease/Protection/Modbus state, and canonical register-18 Output OFF are mandatory.
        install_physical_test_control_pb_mode(app, _physical_test_control)
        # D062/D063 physical validation reuses the same root-only AF_UNIX server. The extension
        # adds only conservative prior-age / near-budget adoption / verified-stop operations;
        # it never creates another listener and remains disabled with the base control plane.
        install_physical_test_control_d062(app, _physical_test_control)
        # The final D062 normal-terminal gate also stays on the same disabled-by-default local
        # socket. It injects only in-memory fresh Delta evidence and rewinds only the sticky
        # finish-hold anchor by 2h; the chemistry active-time clock remains real. The production
        # coordinator must still perform DELTA_HOLD_COMPLETE and its normal verified-OFF/lease-
        # disarm path. This is not a wall-clock endurance claim and exposes no generic
        # clock/setpoint mutation endpoint.
        install_physical_test_control_d062_delta(app, _physical_test_control)
        # Remaining source-freshness bench gates use the same opt-in local socket. Each hook
        # corrupts exactly one in-memory decision snapshot and restores the real reader before
        # production verified-OFF confirmation; no arbitrary HA/entity/timestamp write surface
        # is exposed.
        install_physical_test_control_source_faults(app, _physical_test_control)
        # B16 originally proved that writable number metadata does not provide an authoritative
        # same-value heartbeat in production. Shadow only that operation with the V2 gate backed
        # by force-updated read-only Modbus register mirrors; the number entities remain command
        # endpoints and all other source-fault operations keep their existing implementation.
        install_physical_test_control_programmed_readback(app, _physical_test_control)
        # Diagnostic cancellation/restart physical gates also reuse the same local socket.
        # They can start only one hard-coded low-energy Manual program and a safer current
        # reduction; the restart gate is bounded by an automatic 20 s cleanup if SIGKILL does
        # not arrive. No arbitrary actuator parameters are accepted from the client.
        install_physical_test_control_diagnostic(app, _physical_test_control)
        # The semantic L2/L3 operator station is the final presentation layer. It is installed
        # after ownership and live-session wrappers so the panel describes their effective
        # semantics rather than leaking the underlying composition/debug UI. Managed Stop is
        # then converted from the legacy ON/OFF toggle into a session-bound L4 stop-only action;
        # the graph-backed transport is composed underneath the final semantic state/controls.
        if _ui_support_enabled:
            # Register the real Back/Home handler before operator_hmi installs its historical
            # no-op compatibility handler for the same callback.
            install_operator_navigation_recovery(app)
            install_operator_hmi(app)
            # Re-compose ownership at the *final* semantic HMI boundary. Earlier ownership
            # wrappers target the legacy dashboard builder and were being replaced by
            # install_operator_hmi(), which made HANDS_OFF/release unavailable exactly when an
            # orphan external Output needed operator recovery.
            install_rd_ownership_recovery(app, _rd_control_mode)
            # A second-step adopted-Mix OFF button in an old Telegram message must not remain
            # an indefinitely valid actuator capability. Bind it to the exact current observer
            # epoch before composing the remaining operator actions.
            install_operator_destructive_guard(app)
            install_operator_managed_stop(app)
            install_operator_graph_dashboard(app)
            # Mix affordances are contextual, not generic HANDS_OFF+ON actions. Hide them for
            # setpoints that cannot be high-voltage Mix under any supported chemistry and gate
            # stale Telegram callback messages with the same live rule.
            install_mix_action_eligibility(app)
            # Last presentation boundary: stale/unknown canonical Output evidence must never be
            # rendered as OFF or expose actions whose precondition is proven OFF. This wrapper
            # is deliberately installed after every keyboard composer so UNKNOWN stays visible
            # in the effective production panel without changing any actuator transaction.
            install_operator_output_truth(app)
            # The Bot/AUTONOMOUS switch is composed after output-truth normalization so entry
            # and exit affordances can never treat UNKNOWN/stale Output as confirmed OFF.
            install_rd_autonomous_final_hmi(app, _rd_autonomous_mode)

        # Final execution boundary: before any normal application or ownership transaction can
        # use the fully composed actuator stack, explicit edge mode must be observed and stale
        # managed durable state must be reconciled. Recovery gets a task-local verified-OFF
        # exception; ordinary bot/Telegram/background work remains blocked in parallel.
        _rd_startup_authority = install_rd_startup_authority_gate(app, _rd_control_mode)
        # D066: the legacy logger/restore/tick loop remains useful for raw telemetry, but it
        # must not claim Pb actuator/chemistry authority in HANDS_OFF, AUTONOMOUS, or sibling
        # tasks while D065 startup authority is unresolved. Install after the startup gate so
        # its dynamic predicate sees the final authority boundary; recovery_scope stays exempt.
        install_hands_off_background_isolation(app, _rd_control_mode)

        # Read-only operator boundary: the provider receives an explicit source
        # contract rather than an implicit compatibility facade.
        operator_read_source = OperatorReadSource(app)
        operator_interface = OperatorSnapshotProvider(
            operator_read_source,
            intent_dispatcher=build_operator_intent_dispatcher(app),
        )
        app.operator_interface = operator_interface
        if _ui_support_enabled:
            # Recipe library UI is isolated; no commands start or resume charging.
            from pathlib import Path as _RecipePath
            from runtime.safety.variables import MAX_STAGE_CURRENT_A as _RecipeMaxCurrent
            from config import MAX_MANUAL_VOLTAGE as _RecipeMaxVoltage
            app._user_recipe_catalog = RecipeCatalog(RecipeLibrary(
                    _RecipePath(__file__).resolve().parent.parent / "state" / "user_recipes",
                    max_voltage_v=float(_RecipeMaxVoltage),
                    max_current_a=float(_RecipeMaxCurrent.default),
                ))
            install_recipe_catalog_commands(app, catalog=app._user_recipe_catalog)
            install_charge_program_screen(
                app,
                profile_selector=app._select_quick_profile,
                batteries_handler=app._batteries_handler,
                battery_add_handler=app._battery_add_handler,
                manual_handler=app._manual_choose_handler,
                interrupted_manual_handler=app._manual_interrupted_handler,
                interrupted_manual_provider=lambda: (
                    str(
                        getattr(
                            getattr(getattr(app, "manual_session_manager", None), "state", None),
                            "value",
                            "",
                        )
                    )
                    == "interrupted"
                ),
            )
            install_custom_cancel_route(
                app,
                cancel_state=app._cancel_custom_mode_state,
                home_handler=app._operator_home_handler,
            )
            install_home_command(
                app,
                render_home=app._build_and_send_dashboard,
                show_charge_menu=lambda: not app.charge_controller.is_active,
            )
            install_journal_screen(
                app,
                interface=operator_interface,
                home_handler=app._operator_home_handler,
                retire_graph_tracking=app._retire_graph_tracking_for_message,
                restore_dashboard=app._restore_dashboard_to_bottom,
            )
            install_off_conditions_screen(
                app,
                interface=operator_interface,
                status_provider=app._format_manual_off_for_dashboard,
            )
            install_operator_details_screen(
                app,
                interface=operator_interface,
                home_handler=app._operator_home_handler,
            )
            install_service_details_screen(
                app,
                interface=operator_interface,
                home_handler=app._operator_home_handler,
            )
            install_entities_screen(
                app,
                interface=operator_interface,
                home_handler=app._operator_home_handler,
            )
            install_help_screen(
                app,
            )
            install_stats_screen(
                app,
            )
            install_analysis_screen(
                app,
                analysis_provider=app._build_ai_analysis_text,
                home_handler=app._operator_home_handler,
            )

        runtime_main = app.main
        _startup_recovery = StartupRecovery(
            app,
            _rd_managed_mix_adoption,
            _rd_managed_live_adoption,
            _rd_live_mix_observer,
        )

        self.ui_support_enabled = _ui_support_enabled
        self.rd_control_mode = _rd_control_mode
        self.rd_autonomous_mode = _rd_autonomous_mode
        self.rd_live_mix_observer = _rd_live_mix_observer
        self.rd_managed_live_adoption = _rd_managed_live_adoption
        self.rd_managed_mix_adoption = _rd_managed_mix_adoption
        self.physical_test_control = _physical_test_control
        self.rd_startup_authority = _rd_startup_authority
        self.operator_read_source = operator_read_source
        self.operator_interface = operator_interface
        self.runtime_main = runtime_main
        self.startup_recovery = _startup_recovery
        self.composed = True
        return self

    async def run(
        self,
        *,
        runtime: object | None = None,
        runtime_main=None,
        startup_authority=None,
        startup_recovery=None,
        physical_test_control=None,
        init_storage=None,
    ) -> None:
        """Run the composed production lifecycle with explicit dependencies."""

        if not self.composed:
            self.compose()
        app = self.runtime if runtime is None else runtime
        main_runner = self.runtime_main if runtime_main is None else runtime_main
        authority = (
            self.rd_startup_authority
            if startup_authority is None
            else startup_authority
        )
        recovery = self.startup_recovery if startup_recovery is None else startup_recovery
        physical = (
            self.physical_test_control
            if physical_test_control is None
            else physical_test_control
        )
        storage_init = init_production_storage if init_storage is None else init_storage

        initializer = getattr(app, "initialize_runtime", None)
        if callable(initializer):
            initializer()
        await storage_init()

        authority_task = asyncio.create_task(
            reconcile_startup_authority(
                authority,
                recovery.recover_managed_startup_authority,
                recovery.replay_deferred_startup_restore,
            ),
            name="rd6018-startup-authority-reconciliation",
        )
        self._authority_task = authority_task

        await physical.start()
        try:
            await main_runner()
        finally:
            if not authority_task.done():
                authority_task.cancel()
                try:
                    await authority_task
                except asyncio.CancelledError:
                    pass
            self._authority_task = None
            await physical.stop()


_composition = ProductionComposition(_runtime_substrate).compose()


async def main() -> None:
    await _composition.run()


if __name__ == "__main__":
    asyncio.run(main())
