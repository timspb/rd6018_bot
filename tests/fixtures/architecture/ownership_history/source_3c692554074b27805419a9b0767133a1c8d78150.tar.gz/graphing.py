"""
graphing.py — построение графика U/I во времени (dark theme).
Ось X: время в USER_TIMEZONE (config).
"""
import io
import logging
import math
import threading
from datetime import datetime, time, timezone
from typing import List, Optional, Union

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.dates import DateFormatter

logger = logging.getLogger("rd6018")
_FIGURE = None
_RENDER_LOCK = threading.Lock()


def _to_float_list(data: List) -> List[float]:
    """Преобразовать все элементы в float (защита от categorical units)."""
    out: List[float] = []
    for x in data:
        try:
            out.append(float(x))
        except (TypeError, ValueError):
            out.append(0.0)
    return out


def _smooth(y: List[float], window: int = 5) -> List[float]:
    """Скользящее среднее по window точкам. Границы обрабатываются полусредним (меньшее окно)."""
    n = len(y)
    if n == 0 or window <= 1:
        return list(y)
    out: List[float] = []
    half = window // 2
    for i in range(n):
        lo = max(0, i - half)
        hi = min(n, i + half + 1)
        out.append(sum(y[lo:hi]) / (hi - lo))
    return out


def _parse_timestamps(times: List[str]) -> List[datetime]:
    """Строки времени (ISO из БД или HH:MM:SS) → datetime в USER_TIMEZONE. В БД хранится UTC (Z)."""
    from time_utils import now_user_tz, get_user_timezone

    result: List[datetime] = []
    base_date = now_user_tz().date()
    user_tz = get_user_timezone()

    for ts in times:
        if not ts or not isinstance(ts, str):
            result.append(now_user_tz())
            continue
        try:
            if "T" in ts:
                raw = ts.strip()
                # Явно: суффикс Z = UTC, иначе legacy без TZ
                if raw.endswith("Z"):
                    s = raw[:-1] + "+00:00"
                else:
                    s = raw.replace("Z", "+00:00") if "Z" in raw else raw
                dt = datetime.fromisoformat(s)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                dt = dt.astimezone(user_tz)
            else:
                # HH:MM:SS формат - считаем что это уже в пользовательском часовом поясе
                parts = ts.split(":")
                if len(parts) >= 2:
                    h, m = int(parts[0]), int(parts[1])
                    s = int(parts[2]) if len(parts) >= 3 else 0
                    dt = datetime.combine(base_date, time(h, m, s))
                    dt = user_tz.localize(dt)
                else:
                    dt = now_user_tz()
            result.append(dt)
        except (ValueError, TypeError):
            result.append(now_user_tz())
    return result


def _visible_axis_limits(values: List[float], *, minimum_span: float, relative_span: float = 0.1) -> tuple[float, float]:
    """Autoscale to visible telemetry, including a stable nonzero signal.

    Fixed 0..20 axes were hiding 0.23 A / 14.76 V completely whenever
    all values in the selected window were constant.
    """
    valid = [v for v in values if math.isfinite(v)]
    if not valid:
        return (0.0, minimum_span)
    low, high = min(valid), max(valid)
    if high <= 0 and low >= 0:
        return (0.0, minimum_span)
    span = max(high - low, minimum_span, max(abs(low), abs(high)) * relative_span)
    padding = max((span - (high - low)) / 2.0, (high - low) * 0.08)
    return (max(0.0, low - padding), high + padding)


def generate_chart(
    times: List[str],
    voltages: List[float],
    currents: List[float],
    temps: Optional[List[float]] = None,
) -> Optional[io.BytesIO]:
    """
    Построить dual-axis график U/I.
    Стиль: тёмный фон (#1e1e1e), X — время (HH:MM), Y1 — напряжение (Cyan), Y2 — ток (Yellow).
    Возвращает BytesIO или None при ошибке.
    """
    if not times or not voltages or not currents:
        return None

    v_list = _to_float_list(voltages)
    i_list = _to_float_list(currents)
    t_list = _to_float_list(temps) if temps is not None else []
    n = min(len(times), len(v_list), len(i_list))
    if temps is not None:
        n = min(n, len(t_list))
    if n == 0:
        return None

    times_parsed = _parse_timestamps(times[:n])
    v_list = v_list[:n]
    i_list = i_list[:n]
    if temps is not None:
        t_list = t_list[:n]
    # Сглаживание рядов (зубья — дискретные замеры; при линейном изменении график плавный)
    v_list = _smooth(v_list, window=5)
    i_list = _smooth(i_list, window=5)
    if temps is not None:
        t_list = _smooth(t_list, window=5)

    # График от начала до конца сессии — без обрезки по времени (полный диапазон данных)

    global _FIGURE
    with _RENDER_LOCK:
        try:
            from time_utils import get_user_timezone
            user_tz = get_user_timezone()

            plt.style.use("dark_background")
            has_temps = temps is not None
            if _FIGURE is None:
                _FIGURE = plt.figure(figsize=(7.5, 4.5 if has_temps else 3.0), facecolor="#1e1e1e")
            fig = _FIGURE
            fig.clear()
            fig.set_facecolor("#1e1e1e")
            if has_temps:
                fig.set_size_inches(7.5, 4.5)
                ax1, ax2, ax3 = fig.subplots(
                    3,
                    1,
                    sharex=True,
                    gridspec_kw={"height_ratios": [2, 1.5, 1]},
                )
                for ax in (ax1, ax2, ax3):
                    ax.set_facecolor("#1e1e1e")
                    ax.grid(True, alpha=0.12)
                    ax.xaxis_date(tz=user_tz)

                ax1.plot(times_parsed, v_list, color="#00ffff", linewidth=1.5)
                ax1.set_ylabel("Voltage (V)", color="#00ffff")
                ax1.tick_params(axis="y", colors="#00ffff")
                ax2.plot(times_parsed, i_list, color="#ffff00", linewidth=1.5)
                ax2.set_ylabel("Current (A)", color="#ffff00")
                ax2.tick_params(axis="y", colors="#ffff00")
                ax3.plot(times_parsed, t_list, color="#ff9f43", linewidth=1.5)
                ax3.set_ylabel("Temp (°C)", color="#ff9f43")
                ax3.set_xlabel("Время", color="#fff")
                ax3.tick_params(axis="x", colors="#fff", labelsize=8)
                ax3.tick_params(axis="y", colors="#ff9f43")
                ax3.xaxis.set_major_formatter(DateFormatter("%H:%M", tz=user_tz))

                ax1.set_ylim(*_visible_axis_limits(v_list, minimum_span=0.30))
                ax2.set_ylim(*_visible_axis_limits(i_list, minimum_span=0.10))
                min_t, max_t = min(t_list), max(t_list)
                ax3.set_ylim(
                    max(0, min_t - 1.0),
                    max_t + 1.0 if max_t > 0 else 60,
                )
            else:
                fig.set_size_inches(7.5, 3.0)
                ax1 = fig.add_subplot(111)
                ax1.set_facecolor("#1e1e1e")
                ax1.xaxis_date(tz=user_tz)
                ax1.plot(times_parsed, v_list, color="#00ffff", linewidth=1.5)
                ax1.set_xlabel("Время", color="#fff")
                ax1.set_ylabel("Voltage (V)", color="#00ffff")
                ax1.xaxis.set_major_formatter(DateFormatter("%H:%M", tz=user_tz))
                ax1.tick_params(axis="x", colors="#fff", labelsize=8)
                ax1.tick_params(axis="y", colors="#00ffff")
                ax1.set_ylim(*_visible_axis_limits(v_list, minimum_span=0.30))
                ax2 = ax1.twinx()
                ax2.plot(times_parsed, i_list, color="#ffff00", linewidth=1.5)
                ax2.set_ylabel("Current (A)", color="#ffff00")
                ax2.tick_params(axis="y", colors="#ffff00")
                ax2.set_ylim(*_visible_axis_limits(i_list, minimum_span=0.10))
                fig.legend(loc="upper right", fontsize=8)

            if len(times_parsed) > 1:
                ax1.set_xlim(times_parsed[0], times_parsed[-1])
            fig.autofmt_xdate()
            fig.tight_layout()

            buf = io.BytesIO()
            fig.savefig(buf, format="png", facecolor=fig.get_facecolor(), bbox_inches="tight")
            buf.seek(0)
            return buf
        except Exception as ex:
            logger.error("generate_chart failed: %s", ex)
            if _FIGURE is not None:
                plt.close(_FIGURE)
                _FIGURE = None
            return None


def create_chart(
    times: List[Union[str, float]],
    voltages: List[Union[float, int]],
    currents: List[Union[float, int]],
) -> Optional[io.BytesIO]:
    """
    Алиас для generate_chart. Конвертирует строки времени в HH:MM при необходимости.
    """
    ts_str: List[str] = []
    for t in times:
        if isinstance(t, str):
            ts_str.append(t[-8:] if len(t) >= 8 else t)
        else:
            ts_str.append(str(t))
    return generate_chart(ts_str, list(voltages), list(currents))
