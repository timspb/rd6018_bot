"""
hass_api.py — асинхронный клиент Home Assistant API.
"""
import asyncio
import logging
import time
from datetime import datetime, timezone
from urllib.parse import urlparse
from typing import Any, Dict, List, Optional, Tuple

import aiohttp

from config import ENTITY_MAP, HA_INSECURE_LOCAL, HA_URL, HA_TOKEN
from rd6018_telemetry import canonicalize_live, canonical_programmed_readback, finite_float
from runtime.safety.output_policy import EnableResult, OutputRequest, SafetyPolicy, SafetySupervisor, snapshot_from_live
from application.safe_output_coordinator import SafeOutputCoordinator

logger = logging.getLogger("rd6018")

PROGRAMMING_TRANSACTION_TTL_SEC = 30.0
# Output State Code V2 is published by the ESPHome/Modbus polling loop.  The
# physical node has demonstrated a 6.22 s worst-case publication latency after
# the HA switch command, so keep a bounded margin without changing the
# canonical-source or fail-closed requirements.
OUTPUT_VERIFY_TIMEOUT_SEC = 10.0
OUTPUT_VERIFY_DELAY_SEC = 0.20
OUTPUT_VERIFY_RETRIES = int(OUTPUT_VERIFY_TIMEOUT_SEC / OUTPUT_VERIFY_DELAY_SEC) + 1
OUTPUT_OFF_VERIFY_TIMEOUT_SEC = 10.0
OUTPUT_OFF_VERIFY_DELAY_SEC = 0.20


class HassClient:
    """Асинхронный клиент для Home Assistant REST API."""

    def __init__(self, base_url: str = HA_URL, token: str = HA_TOKEN, *, backend: Any = None) -> None:
        self.base_url = (base_url or "").rstrip("/")
        self.token = token or ""
        self._session: Optional[aiohttp.ClientSession] = None
        self._timeout = aiohttp.ClientTimeout(total=10)
        self._disable_tls_verify = self._looks_like_local_url(self.base_url) and HA_INSECURE_LOCAL
        self._programming_state: Dict[str, Tuple[float, float]] = {}
        self._safety_supervisor = SafetySupervisor()
        self._physical_backend = backend
        # Preserve the native read-only button inventory capability only for a
        # backend that actually implements it. HA-only adapters keep the legacy
        # state/existence preflight used by EdgeSafetyLease.
        native_button_info = getattr(backend, "get_button_info", None)
        if not callable(native_button_info):
            native_button_info = getattr(getattr(backend, "transport", None),
                                         "get_button_info", None)
        if callable(native_button_info):
            self.get_button_info = native_button_info

    @classmethod
    def from_physical_config(cls, root: str | None = None) -> "HassClient":
        """Keep one V2 owner while selecting an existing physical connector by config."""
        from runtime.config import load_config
        from runtime.physical.connectors import PhysicalConnectorFactory

        config = load_config(root)
        connector_name = str(config.default_connector or "")
        if not connector_name:
            raise RuntimeError("physical connector selection is not configured")
        connector = PhysicalConnectorFactory(config).create(connector_name)
        # Keep HA REST available as a lease/read sidecar while the selected
        # physical connector remains authoritative for telemetry and writes.
        return cls(HA_URL, HA_TOKEN, backend=connector)

    @property
    def _uses_physical_backend(self) -> bool:
        return self._physical_backend is not None

    @staticmethod
    def _looks_like_local_url(base_url: str) -> bool:
        if not base_url:
            return False
        host = (urlparse(base_url).hostname or "").lower()
        return host in {"localhost", "127.0.0.1", "::1", "192.168.1.102"}

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
        }

    async def _ensure_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            connector = aiohttp.TCPConnector(ssl=False) if self._disable_tls_verify else None
            self._session = aiohttp.ClientSession(
                headers=self._headers(),
                timeout=self._timeout,
                connector=connector,
            )
        return self._session

    async def close(self) -> None:
        if self._physical_backend is not None:
            await self._physical_backend.close()
            return
        if self._session and not self._session.closed:
            await self._session.close()

    @staticmethod
    def _entity_metadata(entity_id: str, data: Dict[str, Any], status: str) -> Dict[str, Any]:
        last_reported = data.get("last_reported")
        last_updated = data.get("last_updated")
        heartbeat = last_reported if isinstance(last_reported, str) else last_updated
        age_s = None
        if isinstance(heartbeat, str):
            try:
                text = heartbeat[:-1] + "+00:00" if heartbeat.endswith("Z") else heartbeat
                age_s = max(0.0, time.time() - datetime.fromisoformat(text).timestamp())
            except (TypeError, ValueError, OverflowError):
                age_s = None
        return {
            "entity_id": entity_id,
            "status": status,
            "last_reported": last_reported,
            "last_updated": last_updated,
            "last_changed": data.get("last_changed"),
            "age_s": age_s,
        }

    async def get_state(self, entity_id: str) -> Tuple[Any, Dict]:
        """Получить состояние сущности; HA source timestamps сохраняются в attrs."""
        if self._uses_physical_backend:
            reader = getattr(self._physical_backend, "get_state", None)
            if not callable(reader):
                return None, {"source": "physical_backend", "status": "unsupported"}
            return await reader(entity_id)
        if not self.base_url or not self.token:
            logger.warning("HassClient not configured")
            return None, {}

        url = f"{self.base_url}/api/states/{entity_id}"
        try:
            session = await self._ensure_session()
            async with session.get(url) as resp:
                if resp.status != 200:
                    logger.error("HA get_state %s: status %d", entity_id, resp.status)
                    return None, {}
                data = await resp.json()
                state = data.get("state")
                attrs = dict(data.get("attributes", {}))
                attrs["_ha_last_reported"] = data.get("last_reported")
                attrs["_ha_last_updated"] = data.get("last_updated")
                attrs["_ha_last_changed"] = data.get("last_changed")

                if state is not None and state not in ("unknown", "unavailable", ""):
                    try:
                        state = float(state)
                    except (ValueError, TypeError):
                        pass
                return state, attrs
        except aiohttp.ClientError as ex:
            logger.error("HA get_state %s: %s", entity_id, ex)
            return None, {}
        except Exception as ex:
            logger.error("HA get_state %s: %s", entity_id, ex)
            return None, {}

    async def get_native_physical_output_report(self) -> Tuple[Any, Dict[str, Any]] | None:
        """Read native output evidence from the selected physical backend only.

        HA REST state is not a native ESPHome callback and is never a fallback
        for this authority-sensitive read.
        """
        if self._physical_backend is None:
            return None
        reader = getattr(self._physical_backend, "get_physical_output_report", None)
        if not callable(reader):
            return None
        return await reader()

    async def get_native_guard_pre_on_snapshot(self) -> Dict[str, Any] | None:
        """Return the minimal direct ESP callback snapshot used by Guard assessment.

        This deliberately does not fall back to HA or to a fetch timestamp. The
        per-key monotonic timestamp must originate in an ESP Native callback.
        """
        from runtime.physical.connectors.esp_direct import ESPDirectConnector

        backend = self._physical_backend
        if not isinstance(backend, ESPDirectConnector):
            return None
        try:
            live = await backend.get_all_live()
        except Exception:
            return None
        keys = (
            "output_state_code_v2", "set_current_readback_v2",
            "ocp_readback_v2", "protection_code",
        )
        source_meta = live.get("_meta")
        if not isinstance(source_meta, dict):
            return None
        now_monotonic = time.monotonic()
        selected_meta: Dict[str, Any] = {}
        snapshot: Dict[str, Any] = {}
        for key in keys:
            item = source_meta.get(key)
            if not isinstance(item, dict):
                return None
            updated = item.get("subscription_timestamp_monotonic")
            native_type = item.get("native_type")
            age = (now_monotonic - updated
                   if isinstance(updated, (int, float)) and not isinstance(updated, bool)
                   else None)
            if (item.get("source") != "esp_native_api" or item.get("status") != "ok"
                    or native_type != "SensorState" or age is None
                    or age < 0 or age > 10.0):
                return None
            snapshot[key] = live.get(key)
            selected_meta[key] = {
                "source": "esp_native_api", "status": "ok",
                "native_type": native_type, "age_s": age,
                "subscription_timestamp_monotonic": updated,
            }
        snapshot["_meta"] = selected_meta
        # Keep lease separate from the four electrical Guard inputs. It is
        # copied only when its own callback proves Native provenance/freshness.
        try:
            lease_value, lease_meta = await backend.get_state("safety_lease_armed")
        except Exception:
            return snapshot
        updated = lease_meta.get("subscription_timestamp_monotonic")
        age = (time.monotonic() - updated
               if isinstance(updated, (int, float)) and not isinstance(updated, bool)
               else None)
        if (lease_meta.get("source") == "esp_native_api"
                and lease_meta.get("status") == "ok"
                and lease_meta.get("native_type") == "BinarySensorState"
                and age is not None and 0 <= age <= 10.0):
            snapshot["edge_lease_armed"] = lease_value
            snapshot["_lease_meta"] = {
                "source": "esp_native_api", "status": "ok",
                "native_type": "BinarySensorState", "age_s": age,
                "subscription_timestamp_monotonic": updated,
            }
        return snapshot

    async def get_states(self, entity_ids: List[str]) -> Dict[str, Tuple[Any, Dict]]:
        async def _get_one(eid: str) -> Tuple[str, Tuple[Any, Dict]]:
            return eid, await self.get_state(eid)

        results = await asyncio.gather(*[_get_one(eid) for eid in entity_ids])
        return {eid: state for eid, state in results}

    async def press_button(self, entity_id: str) -> bool:
        """Press a configured physical button through the selected backend."""
        if self._uses_physical_backend:
            press = getattr(self._physical_backend, "press_button", None)
            if not callable(press):
                return False
            return bool(await press(entity_id))
        if not self.base_url or not self.token:
            return False
        try:
            session = await self._ensure_session()
            async with session.post(
                f"{self.base_url}/api/services/button/press",
                json={"entity_id": entity_id},
            ) as response:
                return response.status in (200, 201)
        except Exception as ex:
            logger.error("HA button press %s: %s", entity_id, ex)
            return False

    async def set_value(self, entity_id: str, value: Any) -> bool:
        if self._uses_physical_backend:
            mapping = {
                ENTITY_MAP.get("set_voltage"): self.set_voltage,
                ENTITY_MAP.get("set_current"): self.set_current,
                ENTITY_MAP.get("ovp"): self.set_ovp,
                ENTITY_MAP.get("ocp"): self.set_ocp,
            }
            handler = mapping.get(entity_id)
            return bool(await handler(value)) if handler else False
        if not self.base_url or not self.token:
            return False
        try:
            val = float(value)
        except (ValueError, TypeError):
            logger.error("set_value: invalid value %r", value)
            return False

        url = f"{self.base_url}/api/services/number/set_value"
        payload = {"entity_id": entity_id, "value": val}
        try:
            session = await self._ensure_session()
            async with session.post(url, json=payload) as resp:
                ok = resp.status in (200, 201)
                if not ok:
                    logger.error("HA set_value %s: status %d", entity_id, resp.status)
                return ok
        except Exception as ex:
            logger.error("HA set_value %s: %s", entity_id, ex)
            return False

    def _record_programming(self, key: str, value: float, ok: bool) -> None:
        if ok:
            self._programming_state[key] = (float(value), time.monotonic())
        else:
            self._programming_state.pop(key, None)

    async def _tracked_set(self, key: str, entity_id: str, value: float) -> bool:
        ok = await self.set_value(entity_id, value)
        self._record_programming(key, value, ok)
        return ok

    async def set_voltage(self, value: float) -> bool:
        if self._uses_physical_backend:
            await self._physical_backend.set_voltage(float(value))
            self._record_programming("voltage", value, True)
            return True
        return await self._tracked_set("voltage", ENTITY_MAP["set_voltage"], value)

    async def set_current(self, value: float) -> bool:
        if self._uses_physical_backend:
            await self._physical_backend.set_current(float(value))
            self._record_programming("current", value, True)
            return True
        return await self._tracked_set("current", ENTITY_MAP["set_current"], value)

    async def set_ovp(self, value: float) -> bool:
        if self._uses_physical_backend:
            await self._physical_backend.set_ovp(float(value))
            self._record_programming("ovp", value, True)
            return True
        return await self._tracked_set("ovp", ENTITY_MAP["ovp"], value)

    async def set_ocp(self, value: float) -> bool:
        if self._uses_physical_backend:
            await self._physical_backend.set_ocp(float(value))
            self._record_programming("ocp", value, True)
            return True
        return await self._tracked_set("ocp", ENTITY_MAP["ocp"], value)

    def _recent_programming_request(self) -> Optional[OutputRequest]:
        now = time.monotonic()
        required = ("voltage", "current")
        values: Dict[str, float] = {}
        timestamps: Dict[str, float] = {}
        for key in required:
            item = self._programming_state.get(key)
            if item is None:
                return None
            value, timestamp = item
            if now - timestamp > PROGRAMMING_TRANSACTION_TTL_SEC:
                return None
            values[key] = value
            timestamps[key] = timestamp
        for key in ("ovp", "ocp"):
            item = self._programming_state.get(key)
            if item is not None and now - item[1] <= PROGRAMMING_TRANSACTION_TTL_SEC:
                values[key], timestamps[key] = item
        if "ovp" in timestamps and timestamps["voltage"] < timestamps["ovp"]:
            return None
        return OutputRequest(
            voltage_v=values["voltage"],
            current_a=values["current"],
            ovp_v=values.get("ovp"),
            ocp_a=values.get("ocp"),
            recipe_voltage_ceiling_v=self._safety_supervisor.policy.absolute_voltage_ceiling_v,
        )

    def _clear_programming_state(self) -> None:
        self._programming_state.clear()

    async def _retire_unrequested_protection_limits(
        self, request: OutputRequest, before: Any,
    ) -> bool:
        """Reprogram retained OVP/OCP to bounded targets while Output is OFF.

        Riden keeps MIX protection registers across sessions. Clearing these
        registers to zero is not a safe replacement for a new MAIN request,
        and the physical edge may reject it. Use the same owner-defined
        headroom as the normal managed stage, then prove V2 readback.
        """
        from runtime.safety.variables import (
            PROTECTION_OCP_MARGIN_A, PROTECTION_OVP_MARGIN_V,
        )

        policy = self._safety_supervisor.policy
        replacements = []
        for key, requested, current, margin, actual, setter in (
            ("ovp", request.ovp_v, request.voltage_v,
             float(PROTECTION_OVP_MARGIN_V.default), before.ovp_v, self.set_ovp),
            ("ocp", request.ocp_a, request.current_a,
             float(PROTECTION_OCP_MARGIN_A.default), before.ocp_a, self.set_ocp),
        ):
            if requested is not None:
                continue
            if actual is None:
                logger.error("START refused: missing old %s register readback", key)
                return False
            target = round(current + margin, 2)
            protection_request = OutputRequest(
                voltage_v=request.voltage_v,
                current_a=request.current_a,
                ovp_v=target if key == "ovp" else None,
                ocp_a=target if key == "ocp" else None,
                recipe_voltage_ceiling_v=request.recipe_voltage_ceiling_v,
            )
            if target <= 0 or not self._safety_supervisor.preflight(
                protection_request, before
            ).allowed:
                logger.error("START refused: calculated %s protection violates safety envelope", key)
                return False
            replacements.append((key, target, setter))

        if not replacements:
            return True

        live = await self.get_all_live()
        snap = snapshot_from_live(live, require_programming_freshness=True)
        if snap is None or snap.output_on or not self._safety_supervisor.preflight(request, snap).allowed:
            logger.error("START refused: retained protection programming lacks fresh OFF preflight")
            return False

        for key, target, setter in replacements:
            actual = canonical_programmed_readback(live, key)
            if actual is None:
                logger.error("START refused: %s V2 readback missing", key)
                return False
            if abs(actual - target) <= policy.protection_readback_tolerance:
                continue
            try:
                if not await setter(target):
                    logger.error("START refused: cannot reprogram old %s=%.2f to %.2f",
                                 key, actual, target)
                    return False
            except Exception as exc:
                logger.error("START refused: %s protection programming failed: %s",
                             key, type(exc).__name__)
                return False
            logger.info("START programmed %s protection=%.2f while Output OFF", key, target)

        deadline = time.monotonic() + 10.0
        while True:
            live = await self.get_all_live()
            snap = snapshot_from_live(live, require_programming_freshness=True)
            if snap is None or snap.output_on or not self._safety_supervisor.preflight(request, snap).allowed:
                logger.error("START refused: physical OFF/preflight lost during protection programming")
                return False
            if all(
                (value := canonical_programmed_readback(live, key)) is not None
                and abs(value - target) <= policy.protection_readback_tolerance
                for key, target, _ in replacements
            ):
                return True
            if time.monotonic() >= deadline:
                logger.error("START refused: OVP/OCP did not reach bounded targets in readback window")
                return False
            await asyncio.sleep(0.25)

    async def _switch_service(self, service: str, entity_id: Optional[str] = None) -> bool:
        if self._uses_physical_backend:
            try:
                if service == "turn_on":
                    await self._physical_backend.enable_output()
                elif service == "turn_off":
                    await self._physical_backend.disable_output()
                else:
                    return False
                return True
            except Exception as ex:
                logger.error("physical connector %s failed: %s", service, ex)
                return False
        if not self.base_url or not self.token:
            return False
        eid = entity_id or ENTITY_MAP["switch"]
        url = f"{self.base_url}/api/services/switch/{service}"
        payload = {"entity_id": eid}
        try:
            session = await self._ensure_session()
            async with session.post(url, json=payload) as resp:
                ok = resp.status in (200, 201)
                if not ok:
                    logger.error("HA %s %s: status %d", service, eid, resp.status)
                return ok
        except Exception as ex:
            logger.error("HA %s %s: %s", service, eid, ex)
            return False

    async def turn_on(self, entity_id: Optional[str] = None) -> bool:
        """Fail-closed enable after complete programming transaction + readback."""
        request = self._recent_programming_request()
        if request is None:
            logger.error("HA turn_on blocked: no fresh complete OVP/OCP/V/I programming transaction")
            return False

        before = snapshot_from_live(
            await self.get_all_live(),
            require_programming_freshness=True,
        )
        if before is None:
            logger.error("HA turn_on blocked: required live telemetry is invalid/stale")
            self._clear_programming_state()
            return False
        decision = self._safety_supervisor.preflight(request, before)
        if not decision.allowed:
            logger.error("HA turn_on blocked by safety preflight: %s", decision.detail)
            self._clear_programming_state()
            return False
        # Old RD6018 OVP/OCP registers persist across sessions. Retire only
        # limits not explicitly requested by this recipe, while Output is OFF.
        # Without this, a previous 1.32 A OCP can trip a fresh 6 A START.
        if not await self._retire_unrequested_protection_limits(request, before):
            self._clear_programming_state()
            return False
        coordinator = SafeOutputCoordinator(self, self._safety_supervisor)
        _programmed, verified = await coordinator.confirm_programmed_readback(request)
        if not verified.allowed:
            logger.error("HA turn_on blocked by setpoint readback: %s", verified.detail)
            self._clear_programming_state()
            return False

        enabled = await self._switch_service("turn_on", entity_id)
        if not enabled:
            self._clear_programming_state()
            return False

        final = None
        for attempt in range(OUTPUT_VERIFY_RETRIES):
            if attempt:
                await asyncio.sleep(OUTPUT_VERIFY_DELAY_SEC)
            final = snapshot_from_live(
                await self.get_all_live(),
                require_programming_freshness=True,
            )
            if final is not None and final.output_on:
                break

        final_decision = (
            self._safety_supervisor.verify_live_output(request, final)
            if final is not None
            else None
        )
        if final_decision is None or not final_decision.allowed:
            detail = "telemetry invalid/stale" if final_decision is None else final_decision.detail
            logger.error("HA turn_on post-enable verification failed (%s); forcing output OFF", detail)
            await self._switch_service("turn_off", entity_id)
            self._clear_programming_state()
            return False

        self._clear_programming_state()
        return True

    async def verify_live_programming(
        self,
        *,
        voltage_v: float,
        current_a: float,
        ovp_v: Optional[float] = None,
        ocp_a: Optional[float] = None,
        recipe_voltage_ceiling_v: float,
    ) -> bool:
        """Verify final programmed V/I and any explicitly requested limits.

        Physical protection trip status and measured voltage/current envelope
        remain mandatory regardless of whether protection-register readback was
        requested by this transaction.
        """
        request = OutputRequest(
            voltage_v=float(voltage_v),
            current_a=float(current_a),
            ovp_v=float(ovp_v) if ovp_v is not None else None,
            ocp_a=float(ocp_a) if ocp_a is not None else None,
            recipe_voltage_ceiling_v=float(recipe_voltage_ceiling_v),
        )
        coordinator = SafeOutputCoordinator(self, self._safety_supervisor)
        programmed, readback = await coordinator.confirm_programmed_readback(request)
        if not readback.allowed or programmed is None:
            logger.error("Final programmed readback rejected: %s", readback.detail)
            return False
        live_decision = self._safety_supervisor.verify_live_output(request, programmed)
        if not live_decision.allowed:
            logger.error("Final live output verification rejected: %s", live_decision.detail)
            return False
        return True

    async def turn_off(self, entity_id: Optional[str] = None) -> bool:
        self._clear_programming_state()
        requested = await self._switch_service("turn_off", entity_id)
        if not requested:
            return False
        return await self.wait_for_output_off()

    async def wait_for_output_off(
        self,
        *,
        timeout_s: float = OUTPUT_OFF_VERIFY_TIMEOUT_SEC,
        poll_interval_s: float = OUTPUT_OFF_VERIFY_DELAY_SEC,
    ) -> bool:
        """Poll one authoritative OFF readback after a single STOP write."""
        loop = asyncio.get_running_loop()
        deadline = loop.time() + max(0.0, float(timeout_s))
        interval = max(0.01, float(poll_interval_s))
        while True:
            try:
                live = await self.get_all_live()
                code = live.get("output_state_code_v2")
                if code not in (None, "", "unknown", "unavailable"):
                    try:
                        if float(code) == 0.0:
                            return True
                    except (TypeError, ValueError):
                        pass
                elif str(live.get("switch", "")).strip().lower() == "off":
                    # Compatibility for older fixtures without the V2 register.
                    return True
            except Exception as exc:
                logger.warning("Output OFF readback failed: %s", exc)

            now = loop.time()
            if now >= deadline:
                return False
            await asyncio.sleep(min(interval, max(0.0, deadline - now)))

    async def safe_enable_output(
        self,
        *,
        voltage_v: float,
        current_a: float,
        ovp_v: Optional[float] = None,
        ocp_a: Optional[float] = None,
        recipe_voltage_ceiling_v: float,
        policy: Optional[SafetyPolicy] = None,
        readback_delay_s: float = 0.0,
    ) -> EnableResult:
        supervisor = SafetySupervisor(policy or self._safety_supervisor.policy)
        coordinator = SafeOutputCoordinator(self, supervisor, readback_delay_s=readback_delay_s)
        return await coordinator.enable(
            OutputRequest(
                voltage_v=float(voltage_v),
                current_a=float(current_a),
                ovp_v=float(ovp_v) if ovp_v is not None else None,
                ocp_a=float(ocp_a) if ocp_a is not None else None,
                recipe_voltage_ceiling_v=float(recipe_voltage_ceiling_v),
            )
        )

    async def _fetch_all_states_bulk(self) -> Optional[Dict[str, Any]]:
        if self._uses_physical_backend:
            return None
        if not self.base_url or not self.token:
            return None
        try:
            session = await self._ensure_session()
            async with session.get(f"{self.base_url}/api/states") as resp:
                if resp.status != 200:
                    return None
                data = await resp.json()
                return {e["entity_id"]: e for e in data}
        except Exception as ex:
            logger.warning("HA bulk /api/states failed: %s", ex)
            return None

    @staticmethod
    def _parse_entity_state(ent: Dict[str, Any]) -> Tuple[Any, str]:
        state = ent.get("state")
        if state is None or state == "":
            return state, "unknown"
        if str(state).lower() in ("unavailable", "unknown"):
            return state, str(state).lower()
        try:
            return float(state), "ok"
        except (ValueError, TypeError):
            return state, "ok"

    @staticmethod
    def _live_keys() -> List[str]:
        # One authoritative list: all mapped RD entities are available to diagnostics.
        return list(ENTITY_MAP.keys())

    async def get_all_live(self) -> Dict[str, Any]:
        """Return values plus source freshness metadata; prefer corrected V2 sensors."""
        if self._uses_physical_backend:
            return dict(canonicalize_live(await self._physical_backend.get_all_live()))
        keys = self._live_keys()
        result: Dict[str, Any] = {}
        meta: Dict[str, Any] = {}
        bulk = await self._fetch_all_states_bulk()

        if bulk is not None:
            for key in keys:
                eid = ENTITY_MAP.get(key)
                if not eid:
                    continue
                ent = bulk.get(eid)
                if ent is None:
                    result[key] = None
                    meta[key] = {
                        "entity_id": eid,
                        "status": "missing",
                        "last_reported": None,
                        "last_updated": None,
                        "last_changed": None,
                        "age_s": None,
                    }
                    continue
                state, status = self._parse_entity_state(ent)
                result[key] = state
                meta[key] = self._entity_metadata(eid, ent, status)
            result["_meta"] = meta
            return dict(canonicalize_live(result))

        # Fallback uses concurrent per-entity GETs so a bulk-endpoint failure cannot
        # serialize dozens of 10s request timeouts and stall the runtime safety loop.
        now_iso = datetime.now(timezone.utc).isoformat()
        key_entities = [
            (key, ENTITY_MAP.get(key))
            for key in keys
            if ENTITY_MAP.get(key)
        ]
        states = await self.get_states([eid for _, eid in key_entities if eid is not None])
        for key, eid in key_entities:
            assert eid is not None
            state, attrs = states.get(eid, (None, {}))
            result[key] = state
            status = "ok" if state not in (None, "unknown", "unavailable", "") else "unknown"
            metadata = self._entity_metadata(
                eid,
                {
                    "last_reported": attrs.get("_ha_last_reported"),
                    "last_updated": attrs.get("_ha_last_updated"),
                    "last_changed": attrs.get("_ha_last_changed"),
                },
                status,
            )
            metadata["fetched_at"] = now_iso
            meta[key] = metadata
        result["_meta"] = meta
        return dict(canonicalize_live(result))

    async def get_entities_status(self) -> List[Dict[str, Any]]:
        if self._uses_physical_backend:
            live = await self.get_all_live()
            return [{"key": key, "entity_id": key, "state": value, "status": "ok" if value is not None else "unknown", "unit": "", "friendly_name": key} for key, value in live.items() if key != "_meta"]
        if not self.base_url or not self.token:
            return []
        bulk = await self._fetch_all_states_bulk()
        result: List[Dict[str, Any]] = []
        for key, entity_id in ENTITY_MAP.items():
            entry: Dict[str, Any] = {
                "key": key,
                "entity_id": entity_id,
                "state": None,
                "status": "error",
                "unit": "",
                "friendly_name": entity_id.split(".")[-1].replace("_", " "),
            }
            ent = bulk.get(entity_id) if bulk else None
            if ent is not None:
                state = ent.get("state")
                attrs = ent.get("attributes", {})
                entry["state"] = state
                entry["unit"] = attrs.get("unit_of_measurement", "")
                entry["friendly_name"] = attrs.get("friendly_name", entry["friendly_name"])
                if state is None or state == "":
                    entry["status"] = "unknown"
                elif str(state).lower() in ("unavailable", "unknown"):
                    entry["status"] = str(state).lower()
                else:
                    entry["status"] = "ok"
            else:
                try:
                    session = await self._ensure_session()
                    async with session.get(f"{self.base_url}/api/states/{entity_id}") as resp:
                        if resp.status != 200:
                            entry["status"] = "error"
                            entry["state"] = f"HTTP {resp.status}"
                        else:
                            data = await resp.json()
                            state = data.get("state")
                            attrs = data.get("attributes", {})
                            entry["state"] = state
                            entry["unit"] = attrs.get("unit_of_measurement", "")
                            entry["friendly_name"] = attrs.get("friendly_name", entry["friendly_name"])
                            if state is None or state == "":
                                entry["status"] = "unknown"
                            elif str(state).lower() in ("unavailable", "unknown"):
                                entry["status"] = str(state).lower()
                            else:
                                entry["status"] = "ok"
                except Exception as ex:
                    entry["status"] = "error"
                    entry["state"] = str(ex)[:50]
            result.append(entry)
        return result
