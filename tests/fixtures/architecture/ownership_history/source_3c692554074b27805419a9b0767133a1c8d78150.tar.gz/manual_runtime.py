from __future__ import annotations

import asyncio
import json
import math
import os
import sqlite3
import time
from dataclasses import dataclass
from functools import wraps
from typing import Any, Optional

from manual_mode import (
    MANUAL_DEFAULT_MAIN_TAIL_CURRENT_A,
    MANUAL_POLL_SEC,
    ManualChargeRequest,
    ManualUIIntent,
    ManualSessionManager,
    ManualSessionState,
)
from battery_registry import get_battery
from runtime.charge.evidence.first_stage import tail_current_threshold_a
from rd6018_telemetry import as_bool, finite_float
from application.execution_intent.models import ExecutionIntent, SafetyContext
from application.execution_port import get_or_create_execution_port


MANUAL_REACH_EPS = 0.02


def _serialized_manual_normal_action(operation):
    """Protect Manual state/preflight/enable with the same app execution owner.

    Urgent verified OFF/Edge lease containment must remain independently
    callable; this decorator is for normal Manual lifecycle actions only.
    """
    @wraps(operation)
    async def wrapped(self, *args, **kwargs):
        port = get_or_create_execution_port(self.app)
        lock = port._guard_owner_lock
        if lock is None:
            raise RuntimeError("Manual requires canonical application execution lock")
        async with lock:
            return await operation(self, *args, **kwargs)
    return wrapped


@dataclass(frozen=True)
class ManualUIResult:
    accepted: bool
    request: Optional[ManualChargeRequest] = None
    reason: str = ""


class ProductionManualUIRoute:
    """Typed Manual UI boundary with one explicit session owner."""

    def __init__(self, manager: "ProductionManualSessionManager") -> None:
        self.manager = manager

    async def discard_interrupted(self) -> bool:
        """Discard an interrupted Manual session through the verified-OFF owner."""
        if self.manager.state is not ManualSessionState.INTERRUPTED:
            return False
        return await self.manager.stop("interrupted_manual_discarded")

    async def submit_request(
        self,
        request: ManualChargeRequest,
        *,
        chat_id: int,
        user_id: int,
        reach_voltage_v: Optional[float] = None,
        reach_current_a: Optional[float] = None,
        replace_active: bool = False,
    ) -> ManualUIResult:
        """Single application entry for all parsed Manual START intents."""
        try:
            if replace_active:
                accepted = await self.manager.replace(
                    request,
                    reach_voltage_v=reach_voltage_v,
                    reach_current_a=reach_current_a,
                )
            else:
                if reach_voltage_v is None and reach_current_a is None:
                    accepted = await self.manager.start(request)
                else:
                    accepted = await self.manager.start(
                        request,
                        reach_voltage_v=reach_voltage_v,
                        reach_current_a=reach_current_a,
                    )
        except (RuntimeError, ValueError) as exc:
            return ManualUIResult(False, request, str(exc))
        if not accepted:
            return ManualUIResult(False, request, "safe_enable_failed")
        self.manager.app.last_chat_id = chat_id
        self.manager.app.last_user_id = user_id
        return ManualUIResult(True, request, "started")

    async def submit(self, intent: ManualUIIntent) -> ManualUIResult:
        try:
            request = intent.to_request()
            return await self.submit_request(
                request, chat_id=intent.chat_id, user_id=intent.user_id
            )
        except (RuntimeError, ValueError) as exc:
            return ManualUIResult(False, locals().get("request"), str(exc))


def _finite_optional(value: Any) -> Optional[float]:
    result = finite_float(value)
    return float(result) if result is not None else None


def _crossed(previous: Optional[float], current: float, target: float) -> bool:
    """Return true when a sampled signal reached or crossed an operator target."""
    if abs(float(current) - float(target)) <= MANUAL_REACH_EPS:
        return True
    if previous is None:
        return False
    lo = min(float(previous), float(current)) - MANUAL_REACH_EPS
    hi = max(float(previous), float(current)) + MANUAL_REACH_EPS
    return lo <= float(target) <= hi


class ProductionManualSessionManager(ManualSessionManager):
    """Production Manual authority with legacy-entry compatibility.

    The old quick ``V I third`` syntax described the third value as "reach this V/I",
    not as a one-sided threshold. Keeping that distinction avoids the unsafe shortcut
    of encoding an equality as both >= and <=. Exact-reach state is persisted next to
    the normal Manual request and is reset across Cooling because an OFF interval breaks
    continuity between samples.

    The legacy persistent ``Manual OFF`` overlay remains an independent kill-condition
    system. When it fires during a managed Manual session, the manager owns the stop so
    software state cannot remain ACTIVE after another runtime path has turned Output off.

    A failed/unconfirmed OFF is special: the session deliberately remains in ARMING
    containment instead of becoming an inactive FAILED session. That keeps the runtime
    safety guard authoritative until physical OFF can actually be proved.
    """

    def __init__(self, app: Any, *, session_file: str = "manual_session_v2.json") -> None:
        self.reach_voltage_v: Optional[float] = None
        self.reach_current_a: Optional[float] = None
        self._previous_voltage_v: Optional[float] = None
        self._previous_current_a: Optional[float] = None
        super().__init__(app, session_file=session_file)

    def _document(self) -> dict[str, Any]:
        document = super()._document()
        document["reach_voltage_v"] = self.reach_voltage_v
        document["reach_current_a"] = self.reach_current_a
        return document

    def _restore_as_interrupted(self) -> None:
        saved_reach_v: Optional[float] = None
        saved_reach_i: Optional[float] = None
        if os.path.exists(self.session_file):
            try:
                with open(self.session_file, "r", encoding="utf-8") as handle:
                    raw = json.load(handle)
                saved_reach_v = _finite_optional(raw.get("reach_voltage_v"))
                saved_reach_i = _finite_optional(raw.get("reach_current_a"))
            except (OSError, json.JSONDecodeError, TypeError):
                pass
        super()._restore_as_interrupted()
        self.reach_voltage_v = saved_reach_v
        self.reach_current_a = saved_reach_i
        if self.state is ManualSessionState.INTERRUPTED:
            self._persist()

    @staticmethod
    def _validate_reach(value: Optional[float], *, ceiling: float, name: str) -> Optional[float]:
        if value is None:
            return None
        result = float(value)
        if not math.isfinite(result) or result < 0 or result > float(ceiling):
            raise ValueError(f"{name} reach target is outside the manual safety envelope")
        return result

    @staticmethod
    def _off_unconfirmed_detail(value: Any) -> bool:
        text = str(value or "").strip().lower().replace("_", " ")
        return "output off was not confirmed" in text or "output off unconfirmed" in text

    def _preserve_containment_after_denied_enable(self, context: str) -> None:
        """Keep authority if a denied safe-enable could not prove physical OFF."""
        if self.state is not ManualSessionState.FAILED:
            return
        if not self._off_unconfirmed_detail(self.stop_reason):
            return
        self.state = ManualSessionState.ARMING
        if "output_off_unconfirmed" not in self.stop_reason:
            self.stop_reason = f"{context}:{self.stop_reason}:output_off_unconfirmed"
        self.cooling_started_at = None
        self._persist()

    async def _disable_via_execution_port(self, reason: str) -> bool:
        identity = self.identity_integration.identity
        intent = ExecutionIntent(
            requested_voltage_v=0.0,
            requested_current_a=0.0,
            requested_mode="MANUAL_DISABLE",
            source_decision_id=f"manual_disable:{getattr(identity, 'trace_id', 'legacy')}",
            safety_context=SafetyContext(verification_state="REQUIRED", lease_state="V2_PHYSICAL_OWNER"),
        )
        return (await self.execution_port.disable(intent, identity=identity, reason=reason)).verified

    async def _contain_enable_exception(self, context: str, exc: Exception) -> bool:
        confirmed_off = False
        try:
            confirmed_off = await self._disable_via_execution_port(context)
        except Exception:
            confirmed_off = False
        self.stop_reason = f"{context}:{type(exc).__name__}"
        if confirmed_off:
            self.state = ManualSessionState.FAILED
        else:
            self.state = ManualSessionState.ARMING
            self.stop_reason += ":output_off_unconfirmed"
        self.cooling_started_at = None
        self._persist()
        return False

    @_serialized_manual_normal_action
    async def start(
        self,
        request: ManualChargeRequest,
        *,
        reach_voltage_v: Optional[float] = None,
        reach_current_a: Optional[float] = None,
    ) -> bool:
        from runtime.safety.variables import MAX_STAGE_CURRENT_A
        from config import MAX_MANUAL_VOLTAGE

        reach_v = self._validate_reach(
            reach_voltage_v,
            ceiling=float(MAX_MANUAL_VOLTAGE),
            name="voltage",
        )
        reach_i = self._validate_reach(
            reach_current_a,
            ceiling=float(MAX_STAGE_CURRENT_A.default),
            name="current",
        )
        self.reach_voltage_v = reach_v
        self.reach_current_a = reach_i
        self.main_tail_current_threshold_a = await self._resolve_main_tail_threshold(request)
        self._previous_voltage_v = None
        self._previous_current_a = None
        try:
            enabled = await super().start(request)
        except Exception as exc:
            return await self._contain_enable_exception("manual_start_exception", exc)
        if not enabled:
            self._preserve_containment_after_denied_enable("manual_start_denied")
        return enabled

    async def _resolve_main_tail_threshold(self, request: ManualChargeRequest) -> float:
        if not request.battery_id:
            return MANUAL_DEFAULT_MAIN_TAIL_CURRENT_A
        try:
            record = await get_battery(request.battery_id)
            if record is not None:
                return float(
                    tail_current_threshold_a(
                        record.identity.chemistry,
                        float(record.identity.nominal_capacity_ah),
                    )
                )
        except (AttributeError, TypeError, ValueError, sqlite3.OperationalError):
            pass
        return MANUAL_DEFAULT_MAIN_TAIL_CURRENT_A

    async def _retire_runner(self) -> None:
        task = self._task
        self._task = None
        if task is None or task.done() or task is asyncio.current_task():
            return
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

    @_serialized_manual_normal_action
    async def replace(
        self,
        request: ManualChargeRequest,
        *,
        reach_voltage_v: Optional[float] = None,
        reach_current_a: Optional[float] = None,
    ) -> bool:
        """Safely replace an active Manual program through verified OFF -> fresh ON."""
        if bool(getattr(self.app.charge_controller, "is_active", False)):
            raise RuntimeError("automatic charge controller is active")
        if self.is_active:
            if not await self.stop("manual_reconfigure"):
                return False
        await self._retire_runner()
        return await self.start(
            request,
            reach_voltage_v=reach_voltage_v,
            reach_current_a=reach_current_a,
        )

    async def stop(self, reason: str = "operator_stop") -> bool:
        self.stop_reason = str(reason)
        confirmed = False
        try:
            confirmed = await self._disable_via_execution_port(self.stop_reason)
        except Exception:
            confirmed = False
        if confirmed:
            self._transition_state(ManualSessionState.STOPPED, self.stop_reason)
            self._previous_voltage_v = None
            self._previous_current_a = None
        else:
            self.stop_reason = f"{reason}:output_off_unconfirmed"
            self._transition_state(ManualSessionState.ARMING, self.stop_reason)
        self.cooling_started_at = None
        self._persist()
        return confirmed

    async def _enter_cooling(self) -> None:
        self._previous_voltage_v = None
        self._previous_current_a = None
        await super()._enter_cooling()
        if (
            self.state is ManualSessionState.FAILED
            and self.stop_reason == "cooling_output_off_unconfirmed"
        ):
            self.state = ManualSessionState.ARMING
            self._persist()

    @_serialized_manual_normal_action
    async def _resume_after_cooling(self) -> None:
        try:
            await super()._resume_after_cooling()
        except Exception as exc:
            await self._contain_enable_exception("manual_cooling_resume_exception", exc)
        else:
            self._preserve_containment_after_denied_enable("manual_cooling_resume_denied")
        self._previous_voltage_v = None
        self._previous_current_a = None

    def _reach_reason(self, voltage: float, current: float) -> Optional[str]:
        if self.reach_voltage_v is not None and _crossed(
            self._previous_voltage_v,
            voltage,
            self.reach_voltage_v,
        ):
            return "manual_voltage_reached"
        if self.reach_current_a is not None and _crossed(
            self._previous_current_a,
            current,
            self.reach_current_a,
        ):
            return "manual_current_reached"
        return None

    def _persisted_manual_off_reason(
        self,
        *,
        voltage: float,
        current: float,
        now: float,
    ) -> Optional[str]:
        """Mirror the persistent V1 Manual-OFF overlay inside managed Manual state."""
        v_ge = _finite_optional(getattr(self.app, "manual_off_voltage", None))
        v_le = _finite_optional(getattr(self.app, "manual_off_voltage_le", None))
        i_le = _finite_optional(getattr(self.app, "manual_off_current", None))
        i_ge = _finite_optional(getattr(self.app, "manual_off_current_ge", None))
        time_sec = _finite_optional(getattr(self.app, "manual_off_time_sec", None))
        start_time = _finite_optional(getattr(self.app, "manual_off_start_time", None))

        if v_ge is not None and v_le is not None and abs(v_ge - v_le) < 0.01:
            if _crossed(self._previous_voltage_v, voltage, v_ge):
                return "manual_off_voltage_reached"
        else:
            if v_ge is not None and voltage >= v_ge:
                return "manual_off_voltage_ge"
            if v_le is not None and voltage <= v_le:
                return "manual_off_voltage_le"

        if i_le is not None and i_ge is not None and abs(i_le - i_ge) < 0.01:
            if _crossed(self._previous_current_a, current, i_le):
                return "manual_off_current_reached"
        else:
            if i_le is not None and current <= i_le:
                return "manual_off_current_le"
            if i_ge is not None and current >= i_ge:
                return "manual_off_current_ge"

        if (
            time_sec is not None
            and time_sec > 0
            and start_time is not None
            and start_time > 0
            and now - start_time >= time_sec
        ):
            return "manual_off_timer"
        return None

    async def observe_once(self) -> None:
        if not self.is_active or self.request is None:
            return

        live = await self.app.hass.get_all_live()
        voltage = finite_float(live.get("battery_voltage"))
        current = finite_float(live.get("current"))
        if voltage is not None and current is not None and self.state is not ManualSessionState.COOLING:
            now = time.time()
            reason = self._reach_reason(float(voltage), float(current))
            legacy_manual_off_fired = False
            if reason is None:
                reason = self._persisted_manual_off_reason(
                    voltage=float(voltage),
                    current=float(current),
                    now=now,
                )
                legacy_manual_off_fired = reason is not None
            if reason is not None:
                confirmed_off = await self.stop(reason)
                if legacy_manual_off_fired and confirmed_off:
                    clear = getattr(self.app, "_clear_manual_off", None)
                    if callable(clear):
                        clear()
                return

            output_on = as_bool(live.get("switch"))
            if self.state is ManualSessionState.ACTIVE and output_on is False:
                self.state = ManualSessionState.FAILED
                self.stop_reason = "manual_output_off_unexpected"
                self._persist()
                return

            self._previous_voltage_v = float(voltage)
            self._previous_current_a = float(current)

        await super().observe_once()

    async def _run(self) -> None:
        try:
            while self.is_active:
                await self.observe_once()
                if not self.is_active:
                    break
                await asyncio.sleep(MANUAL_POLL_SEC)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self.stop_reason = f"manual_runtime_error:{type(exc).__name__}"
            confirmed_off = False
            try:
                confirmed_off = await self._disable_via_execution_port(self.stop_reason)
            except Exception:
                confirmed_off = False
            if confirmed_off:
                self.state = ManualSessionState.FAILED
            else:
                self.state = ManualSessionState.ARMING
                self.stop_reason += ":output_off_unconfirmed"
            self.cooling_started_at = None
            self._persist()
