from __future__ import annotations

import html
import math
import time
from typing import Any

from aiogram import F
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

import operator_hmi as hmi
import telegram_panel
from operator_confirmation import ConfirmationStore
from rd_hands_off_release import _active_session_token, _auto_active, _manual_active
from application.intents import OperatorIntent, OperatorIntentKind
from runtime.safety.runtime_guard import OutputOffNotConfirmed
from charging_log import log_verified_auto_stop


STOP_CONFIRM_CALLBACK = "operator_managed_stop"
STOP_EXECUTE_CALLBACK = "operator_managed_stop_execute"
STOP_CANCEL_CALLBACK = "operator_managed_stop_cancel"


async def _route_stop_intent(app: Any, call: Any) -> bool:
    """Pass STOP through the application boundary before old confirmation logic."""
    interface = getattr(app, "operator_interface", None)
    submit = getattr(interface, "submit_intent", None)
    if not callable(submit):
        return True
    user = str(getattr(getattr(call, "from_user", None), "id", "0"))
    result = await submit(OperatorIntent(OperatorIntentKind.STOP_CHARGE, "telegram", user))
    if getattr(result, "status", None) == "rejected":
        await call.answer("Остановка пока недоступна", show_alert=True)
        return False
    return True


def _replace_legacy_power_toggle(
    markup: InlineKeyboardMarkup,
    state: hmi.OperatorHmiState,
) -> InlineKeyboardMarkup:
    """Give the semantic HMI a stop-only callback, never a legacy ON/OFF toggle."""
    if state.authority not in {hmi.HmiAuthority.AUTO, hmi.HmiAuthority.MANUAL}:
        return markup
    rows = []
    for row in markup.inline_keyboard:
        replaced = []
        for button in row:
            if str(getattr(button, "callback_data", "") or "") == "power_toggle":
                replaced.append(
                    InlineKeyboardButton(
                        text=str(getattr(button, "text", "") or "🛑 Остановить заряд"),
                        callback_data=STOP_CONFIRM_CALLBACK,
                    )
                )
            else:
                replaced.append(button)
        rows.append(replaced)
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _session_label(token: str) -> str:
    if token.startswith("manual"):
        return "Manual"
    if token.startswith("auto"):
        return "AUTO"
    return "managed"


def _orphan_retirement(app: Any):
    from application.controller_session_retirement import _ControllerSessionRetirement
    return _ControllerSessionRetirement(app)


def _orphan_stop_already_retired(retirement: Any, expected_token: str) -> bool:
    """A stale STOP succeeds only for the exact durably retired session."""
    try:
        document = retirement._document()
    except (OSError, ValueError, TypeError, AttributeError):
        return False
    return (isinstance(document, dict)
            and document.get("owner") == "runtime.charge.persistence"
            and document.get("state") == "retired"
            and document.get("retirement_kind") == "operator_recovery_clearance"
            and document.get("output_intent") == "verified_off"
            and isinstance(document.get("verified_off_transaction_id"), str)
            and bool(document["verified_off_transaction_id"].strip())
            and isinstance(document.get("session_id"), str)
            and isinstance(document.get("battery_id"), str)
            and expected_token.startswith("orphan-main:" + document["session_id"] + ":"
                                          + document["battery_id"] + ":"))


def _orphan_stop_token(app: Any) -> str | None:
    binding = _orphan_retirement(app).orphan_binding()
    if binding is None:
        return None
    return "orphan-main:" + binding["session_id"] + ":" + binding["battery_id"] + ":" + binding["document_sha256"]


async def _stop_orphan_main_guard(app: Any, expected_token: str) -> tuple[bool, str]:
    from application.operator_recovery_clearance import VerifiedOffEvidence
    from application.execution_port import get_or_create_execution_port
    import math
    import time

    retirement = _orphan_retirement(app)
    binding = retirement.orphan_binding()
    if binding is None:
        if _orphan_stop_already_retired(retirement, expected_token):
            return True, "Сессия уже завершена; повторный STOP не требуется."
        return False, "Persisted MAIN session is absent or has changed."
    token = "orphan-main:" + binding["session_id"] + ":" + binding["battery_id"] + ":" + binding["document_sha256"]
    if token != expected_token:
        return False, "Подтверждение устарело: persisted session изменилась."
    port = get_or_create_execution_port(app)
    lock = getattr(port, "_guard_owner_lock", None)
    if lock is None:
        return False, "Canonical execution lock is unavailable."
    async with lock:
        if _active_session_token(app) is not None:
            return False, "Управляемая сессия стала активной; orphan STOP отменён."
        controller = app.charge_controller
        if getattr(controller, "current_stage", controller.STAGE_IDLE) != controller.STAGE_IDLE:
            return False, "Controller session became active; orphan STOP отменён."
        if not retirement.validate(binding):
            if _orphan_stop_already_retired(retirement, expected_token):
                return True, "Сессия уже завершена; повторный STOP не требуется."
            return False, "Persisted session identity changed; STOP отменён до команды."
        try:
            evidence = await port.request_verified_off_evidence()
        except Exception as exc:
            return False, f"Fresh Native verified OFF evidence unavailable: {type(exc).__name__}."
        now = time.monotonic()
        if (not isinstance(evidence, VerifiedOffEvidence)
                or not evidence.transaction_id.strip()
                or not isinstance(evidence.issued_monotonic, (int, float))
                or not math.isfinite(evidence.issued_monotonic)
                or evidence.issued_monotonic > now or now - evidence.issued_monotonic > 30.0):
            return False, "Fresh Native verified OFF evidence unavailable; session retained."
        retired = retirement.retire(binding["session_id"], binding=binding, off_evidence=evidence)
        if retired is None:
            return False, "Persisted session identity changed before durable retirement."
        try:
            retirement.finalize(binding["session_id"])
        except Exception:
            return False, "Durable retirement committed; guarded restore cleanup failed."
        return True, "Orphan MAIN Guard retired durably after fresh Native Output OFF proof."


async def _stop_exact_session(app: Any, expected_token: str) -> tuple[bool, str]:
    """Stop only the session for which the operator confirmed destructive action.

    The confirmation callback is deliberately not a power toggle. If the managed
    owner changes before execution, no actuator command is issued. Manual is retired
    by its own runtime manager; AUTO uses the existing verified hard-stop path.
    """
    current = _active_session_token(app)
    if current is None:
        if expected_token.startswith("orphan-main:"):
            return await _stop_orphan_main_guard(app, expected_token)
        return False, "Управляемая сессия уже не активна или ownership неоднозначен."
    if current != expected_token:
        return False, "Подтверждение устарело: активная сессия изменилась. Команда не выполнена."

    if expected_token.startswith("manual"):
        manager = getattr(app, "manual_session_manager", None)
        if manager is None or not _manual_active(app):
            return False, "Manual-сессия уже изменилась. Команда не выполнена."
        try:
            confirmed = bool(await manager.stop("operator_stop"))
        except Exception as exc:
            return False, f"Output OFF для Manual не подтверждён: {type(exc).__name__}: {exc}"
        if not confirmed:
            return False, "Output OFF для Manual не подтверждён; runtime остаётся в containment."
        retire = getattr(manager, "_retire_runner", None)
        if callable(retire):
            await retire()
        clear = getattr(app, "_clear_manual_off", None)
        if callable(clear):
            clear()
        return True, "Manual остановлен; Output OFF подтверждён."

    if expected_token.startswith("auto"):
        if not _auto_active(app):
            return False, "AUTO-сессия уже изменилась. Команда не выполнена."
        hard_stop = getattr(app, "_hard_stop_charge", None)
        if not callable(hard_stop):
            return False, "AUTO stop недоступен: verified hard-stop path не установлен."
        stop_started_at = time.monotonic()
        try:
            await hard_stop()
        except (OutputOffNotConfirmed, RuntimeError) as exc:
            # Existing hard-stop raises RuntimeError when its verified OFF
            # transaction returns False, not only OutputOffNotConfirmed.
            # Only that exact refusal is eligible for independent Native
            # reconciliation; unrelated runtime errors remain failures.
            off_unverified = (isinstance(exc, OutputOffNotConfirmed)
                              or str(exc) == "STOP refused: physical Output OFF not verified")
            if (off_unverified and await _retire_auto_after_unconfirmed_off(
                    app, expected_token=expected_token,
                    stop_started_at=stop_started_at)):
                return True, (
                    "AUTO-сессия завершена по свежим Native R18/OFF и I=0; "
                    "неподтверждённая команда OFF остаётся в containment: "
                    f"{type(exc).__name__}: {exc}"
                )
            return False, f"AUTO stop не завершён: {type(exc).__name__}: {exc}"
        except Exception as exc:
            return False, f"AUTO stop не завершён: {type(exc).__name__}: {exc}"
        if _auto_active(app):
            return False, "Output stop вернулся без ошибки, но AUTO authority остался активен."
        clear = getattr(app, "_clear_manual_off", None)
        if callable(clear):
            clear()
        try:
            log_verified_auto_stop(expected_token)
        except Exception:
            # History failure must not undo a physically verified safe STOP.
            import logging
            logging.getLogger("rd6018.operator_stop").exception("Verified STOP history append failed")
        return True, "AUTO остановлен; Output OFF подтверждён."

    return False, "Неизвестный managed owner; команда не выполнена."


async def _retire_auto_after_unconfirmed_off(
    app: Any, *, expected_token: str, stop_started_at: float,
) -> bool:
    """Retire only the same AUTO session after new, typed Native OFF evidence.

    A cached switch/Telegram/HA reading is never a STOP receipt. This
    fallback does not reset a fault latch, lift quarantine or enable Output.
    """
    from rd6018_telemetry import telemetry_freshness

    hass = getattr(app, "hass", None)
    get_live = getattr(hass, "get_all_live", None)
    if not callable(get_live):
        return False
    try:
        live = await get_live()
    except Exception:
        return False
    if not isinstance(live, dict) or _active_session_token(app) != expected_token:
        return False
    metadata = live.get("_meta")
    if not isinstance(metadata, dict):
        return False
    for key in ("output_state_code_v2", "current"):
        item = metadata.get(key)
        if not isinstance(item, dict):
            return False
        timestamp = item.get("subscription_timestamp_monotonic")
        age = item.get("age_s")
        if (item.get("source") != "esp_native_api"
                or item.get("native_type") != "SensorState"
                or item.get("status") != "ok"
                or not isinstance(timestamp, (float, int))
                or isinstance(timestamp, bool)
                or not math.isfinite(timestamp)
                or timestamp <= stop_started_at
                or timestamp > time.monotonic()
                or not isinstance(age, (float, int))
                or isinstance(age, bool)
                or not math.isfinite(age)
                or not 0 <= age <= 8.0):
            return False
    if not telemetry_freshness(
            live, ("output_state_code_v2", "current"), max_age_s=8.0).valid:
        return False
    try:
        output_code = float(live["output_state_code_v2"])
        current = float(live["current"])
    except (TypeError, ValueError, KeyError, OverflowError):
        return False
    if (not math.isfinite(output_code) or output_code != 0.0
            or not math.isfinite(current) or abs(current) > 0.05):
        return False
    # No asynchronous work after the last owner-identity check.
    if _active_session_token(app) != expected_token:
        return False
    controller = getattr(app, "charge_controller", None)
    stop = getattr(controller, "stop", None)
    if not callable(stop):
        return False
    stop(clear_session=True)
    clear = getattr(app, "_clear_manual_off", None)
    if callable(clear):
        clear()
    return not _auto_active(app)


def install_operator_managed_stop(app: Any) -> None:
    """Replace the legacy dual-purpose power toggle with exact-session L4 Stop."""
    if bool(getattr(app, "_operator_managed_stop_installed", False)):
        return

    confirmations = ConfirmationStore()
    app._operator_managed_stop_confirmations = confirmations

    base_keyboard = hmi.build_operator_keyboard

    def stop_only_keyboard(
        app_arg: Any,
        state: hmi.OperatorHmiState,
        *,
        actions: Any = None,
    ) -> InlineKeyboardMarkup:
        base = (
            base_keyboard(app_arg, state, actions=actions)
            if actions is not None
            else base_keyboard(app_arg, state)
        )
        # Logical action views may be rendered without a hydrated HMI state.
        # They must not be coupled to the orphan-session STOP affordance.
        if state is None:
            return base
        if (state.authority not in {hmi.HmiAuthority.AUTO, hmi.HmiAuthority.MANUAL}
                and _active_session_token(app_arg) is None
                and _orphan_stop_token(app_arg) is not None):
            # An orphan persisted MAIN Guard has no live AUTO ownership, but
            # must remain stoppable from the operator's existing STOP control.
            rows = [list(row) for row in base.inline_keyboard]
            rows.append([InlineKeyboardButton(
                text="🛑 Завершить сохранённую сессию",
                callback_data=STOP_CONFIRM_CALLBACK,
            )])
            return InlineKeyboardMarkup(inline_keyboard=rows)
        if actions is not None:
            return base
        return _replace_legacy_power_toggle(base, state)

    hmi.build_operator_keyboard = stop_only_keyboard

    # The terminal-panel middleware is already installed before the final HMI. Teach
    # it that Stop confirmation is an L4 workspace and execute/cancel are terminal.
    telegram_panel._WORKSPACE_CALLBACKS.add(STOP_CONFIRM_CALLBACK)
    telegram_panel._TERMINAL_CALLBACKS.update(
        {STOP_EXECUTE_CALLBACK, STOP_CANCEL_CALLBACK}
    )

    async def _restore_text_panel_after_stop(call: Any) -> None:
        """Close the stop prompt and leave one current text panel."""
        user_id = call.from_user.id if call.from_user else 0
        chat_id = call.message.chat.id
        try:
            await app.bot.delete_message(chat_id, call.message.message_id)
        except Exception:
            pass
        retire = getattr(app, "_retire_graph_workspace_for_user", None)
        if callable(retire):
            await retire(chat_id, user_id)
        manager = getattr(app, "terminal_panel_manager", None)
        restore = getattr(manager, "ensure_text_last", None)
        if callable(restore):
            await restore(chat_id, user_id)

    @app.router.callback_query(F.data == STOP_CONFIRM_CALLBACK)
    async def _managed_stop_confirm(call: Any) -> None:
        if not await app._check_chat_and_respond(call):
            return
        token = _active_session_token(app)
        if token is not None and not await _route_stop_intent(app, call):
            return
        if token is None:
            # Persisted-only STOP has no active charge intent to route; the
            # checked orphan path below owns exact-session retirement.
            token = _orphan_stop_token(app)
            if token is None:
                await call.answer("Нет активной сессии или подтверждённого orphan MAIN Guard", show_alert=True)
                return
        if not confirmations.issue_for_call(call, token):
            await call.answer(
                "Не удалось привязать подтверждение к текущему чату",
                show_alert=True,
            )
            return
        await call.answer()
        label = "orphan persisted MAIN Guard" if token.startswith("orphan-main:") else _session_label(token)
        await call.message.answer(
            "<b>Остановить заряд?</b>\n\n"
            f"Будет остановлена только подтверждённая запись сессии <b>{html.escape(label)}</b>. "
            "Команда выполняет verified Output OFF и не может включить выход. "
            "Подтверждение действительно ограниченное время и только в этом чате.",
            parse_mode=app.ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="🛑 ОСТАНОВИТЬ",
                            callback_data=STOP_EXECUTE_CALLBACK,
                        )
                    ],
                    [
                        InlineKeyboardButton(
                            text="Продолжить заряд",
                            callback_data=STOP_CANCEL_CALLBACK,
                        )
                    ],
                ]
            ),
        )

    @app.router.callback_query(F.data == STOP_CANCEL_CALLBACK)
    async def _managed_stop_cancel(call: Any) -> None:
        if not await app._check_chat_and_respond(call):
            return
        confirmations.cancel_for_call(call)
        await call.answer("Заряд продолжается")

    @app.router.callback_query(F.data == STOP_EXECUTE_CALLBACK)
    async def _managed_stop_execute(call: Any) -> None:
        if not await app._check_chat_and_respond(call):
            return
        expected = confirmations.consume_for_call(call)
        if not expected:
            await call.answer(
                "Подтверждение отсутствует, истекло или уже использовано",
                show_alert=True,
            )
            return

        current = _active_session_token(app)
        if current != expected and not (current is None and expected.startswith("orphan-main:")):
            await call.answer(
                "Сессия изменилась — остановка отменена",
                show_alert=True,
            )
            return

        await call.answer()
        ok, detail = await _stop_exact_session(app, expected)
        await _restore_text_panel_after_stop(call)
        if ok:
            await call.message.answer(
                f"<b>🛑 Заряд остановлен.</b> {html.escape(detail)}",
                parse_mode=app.ParseMode.HTML,
            )
        else:
            await call.message.answer(
                f"⚠️ <b>Остановка не подтверждена.</b> {html.escape(detail)}",
                parse_mode=app.ParseMode.HTML,
            )

    app._operator_managed_stop_installed = True
