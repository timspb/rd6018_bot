from __future__ import annotations

import asyncio
import logging
import time
from datetime import datetime, timedelta
from typing import Any

from aiogram import F
from aiogram.filters import Command
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

import production_bot_ui
from battery_diagnostics_store import init_battery_diagnostics_store
from battery_registry import init_battery_registry, upsert_battery as registry_upsert_battery
from charge_controller import ManagedChargeController
from production_controller import configure_production_charge_host, create_production_charge_host
from manual_runtime import ProductionManualSessionManager, ProductionManualUIRoute
from manual_text import install_manual_text
from pb_domain import ChargeIntent
from runtime.safety.managed_guard import install_managed_runtime_safety
from runtime.ui.telegram.charge import CHARGE_CALLBACK_DATA
from runtime.ui.telegram.details import HOME_CALLBACK_DATA
from runtime.ui.telegram.off_conditions import OFF_CALLBACK_DATA
from telegram_panel import install_panel_last
from battery_input import parse_battery_spec
from sg_ui import install_sg_ui, sg_menu_button
from ui_polish import build_operator_dashboard_keyboard, install_dashboard_polish
from application.execution_port import get_or_create_execution_port
from application.session_recovery_guard import SessionRecoveryGuard
from runtime.journal.recovery_quarantine import RecoveryQuarantineJournal, default_journal_path
from application.operator_recovery_clearance import (
    OperatorRecoveryClearanceService,
)
from runtime.ui.telegram.recovery_clearance import TelegramRecoveryAuthority, install_recovery_clearance_route
from application.intents import OperatorIntent, OperatorIntentKind
from application.production_start_execution_port import ProductionStartExecutionPort
from application.production_start_runner import ProductionStartRunner
from application.production_start_route import ProductionStartRouteAdapter
from application.start_transaction_runner import StartTransactionRunner, build_start_event_context
from application.start_transaction_adapter import StartTransactionAdapter
from application.controller_session_retirement import _ControllerSessionRetirement

logger = logging.getLogger("rd6018")


def _operator_intent_keyboard(prefix: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="Обычный", callback_data=f"{prefix}_normal"),
                InlineKeyboardButton(text="Восстановление", callback_data=f"{prefix}_recovery"),
            ],
            [
                InlineKeyboardButton(text="Кондиционирование", callback_data=f"{prefix}_conditioning"),
                InlineKeyboardButton(text="Диагностика", callback_data=f"{prefix}_diagnostic"),
            ],
            [InlineKeyboardButton(text="⬅ К программам", callback_data=CHARGE_CALLBACK_DATA)],
        ]
    )


def _operator_preview_keyboard(start_callback: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="▶ Запустить программу", callback_data=start_callback)],
            [InlineKeyboardButton(text="⬅ Изменить", callback_data=CHARGE_CALLBACK_DATA)],
        ]
    )


def _operator_modes_text() -> str:
    return (
        "<b>Программа заряда</b>\n\n"
        "Рекомендуемый путь — выбрать сохранённый аккумулятор: его химия, ёмкость и история "
        "будут привязаны к одной физической АКБ. Для разового запуска можно выбрать химию ниже.\n\n"
        "<b>Цель программы</b>\n"
        "Обычный — штатный полный автоматический заряд; recovery/Mix выполняются только по критериям.\n"
        "Восстановление — тот же безопасный контур с явной восстановительной целью и диагностикой.\n"
        "Кондиционирование — сервисная программа внутри разрешённого профилем envelope.\n"
        "Диагностика — наблюдение/проверка без автоматического Recovery/Mix.\n\n"
        "В CV окончание оценивается по Imin→ΔI; в CC — по Vmax→ΔV."
    )


def _operator_modes_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🔋 Мои аккумуляторы", callback_data="v2_batteries")],
            [
                InlineKeyboardButton(text="Ca/Ca", callback_data="v2_profile_caca"),
                InlineKeyboardButton(text="EFB", callback_data="v2_profile_efb"),
                InlineKeyboardButton(text="AGM", callback_data="v2_profile_agm"),
            ],
            [
                InlineKeyboardButton(text="＋ Добавить АКБ", callback_data="v2_battery_add"),
                sg_menu_button(),
            ],
            [
                InlineKeyboardButton(text="Ручной режим", callback_data="v2_manual_choose"),
                InlineKeyboardButton(text="Условие OFF", callback_data=OFF_CALLBACK_DATA),
            ],
            [InlineKeyboardButton(text="⬅ К панели", callback_data=HOME_CALLBACK_DATA)],
        ]
    )


async def _managed_aware_charge_monitor_poll(app: Any) -> None:
    live = await app.hass.get_all_live()
    output_on = str(live.get("switch", "")).lower() == "on"
    battery_v = app._safe_float(live.get("battery_voltage"))
    current_a = app._safe_float(live.get("current"))
    now = datetime.now()
    if not output_on:
        app.zero_current_since = None
        return
    manual = getattr(app, "manual_session_manager", None)
    manual_active = bool(manual is not None and manual.is_active)
    if app.charge_controller.is_active or manual_active:
        app.zero_current_since = None
        return
    if current_a <= 0.0:
        if app.zero_current_since is None:
            app.zero_current_since = now
        elif (now - app.zero_current_since).total_seconds() >= app.ZERO_CURRENT_THRESHOLD_MINUTES * 60:
            if not app.last_idle_alert_at or (now - app.last_idle_alert_at) >= app.IDLE_ALERT_COOLDOWN:
                msg = "⚠️ Выход включен, но потребление отсутствует. Не забудьте выключить прибор."
                app.logger.info("Charge monitor (idle): %s", msg)
                app.last_idle_alert_at = now
                app._charge_notify(msg)
    else:
        app.zero_current_since = None
    if battery_v >= 13.5 and current_a < 0.1:
        cooldown = app.STORAGE_ALERT_COOLDOWN if battery_v < 14.0 else app.CHARGE_ALERT_COOLDOWN
        if app.last_charge_alert_at and (now - app.last_charge_alert_at) < cooldown:
            return
        msg = f"⚠️ Заряд завершён или аккумулятор почти полон. Ток упал до {current_a:.2f}А при напряжении {battery_v:.2f}В."
        app.logger.info("Charge monitor (unmanaged): %s", msg)
        app.last_charge_alert_at = now
        app._charge_notify(msg)


def _install_managed_charge_monitor_guard(app: Any) -> None:
    if getattr(app, "_managed_charge_monitor_guard_installed", False):
        return
    async def managed_aware_charge_monitor() -> None:
        while True:
            await asyncio.sleep(15 * 60)
            try:
                await _managed_aware_charge_monitor_poll(app)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                app.logger.error("charge_monitor (network/error): %s", exc)
                await asyncio.sleep(60)
    app.charge_monitor = managed_aware_charge_monitor
    app._managed_charge_monitor_guard_installed = True


def install_production(app: Any, *, install_ui: bool = True) -> None:
    if type(app.charge_controller) is ManagedChargeController:
        configure_production_charge_host(app.charge_controller)
    else:
        app.charge_controller = create_production_charge_host(app.hass, notify_cb=app._charge_notify)
    # Restore the durable interlock before constructing the canonical port.
    # This happens during composition, before lifecycle startup can restore.
    if not getattr(app, "_recovery_quarantine_journal_configured", False):
        journal = RecoveryQuarantineJournal(default_journal_path(), app)
        prior_guard = getattr(app, "session_recovery_guard", None)
        loaded_state = journal.load()
        if (not loaded_state.quarantined and isinstance(prior_guard, SessionRecoveryGuard)
                and prior_guard.quarantined):
            journal.persist(prior_guard.state.reason or "unknown")
            loaded_state = prior_guard.state
        app.recovery_quarantine_journal = journal
        app.session_recovery_guard = SessionRecoveryGuard(
            persist_incident=journal.persist, durable=True, initial_state=loaded_state
        )
        app._recovery_quarantine_journal_configured = True
    get_or_create_execution_port(app)
    if install_ui and not getattr(app, "_recovery_clearance_service_installed", False):
        authority = TelegramRecoveryAuthority()
        service = OperatorRecoveryClearanceService(
            execution_port=app.execution_port,
            journal=app.recovery_quarantine_journal,
            operator_authority=authority,
            session_retirement=_ControllerSessionRetirement(app),
        )
        install_recovery_clearance_route(app, service=service,
                                         journal=app.recovery_quarantine_journal,
                                         authority=authority)
        app.operator_recovery_clearance = service
        app._recovery_clearance_service_installed = True
    if not isinstance(getattr(app, "manual_session_manager", None), ProductionManualSessionManager):
        app.manual_session_manager = ProductionManualSessionManager(app)
    app.manual_ui_route = ProductionManualUIRoute(app.manual_session_manager)
    install_managed_runtime_safety(app)
    _install_managed_charge_monitor_guard(app)
    install_manual_text(app)
    if not install_ui:
        return

    async def _upsert_from_ui(identity, lifecycle) -> None:
        await init_battery_registry()
        await registry_upsert_battery(identity, lifecycle, updated_at=time.time())

    production_bot_ui.upsert_battery = _upsert_from_ui
    production_bot_ui.parse_battery_spec = parse_battery_spec
    original_safe_answer = production_bot_ui._safe_answer

    async def _safe_answer_operator(event, text: str, *, reply_markup=None) -> None:
        if "ID | AGM/EFB/Ca/Ca | Ah | Производитель | Модель" in text:
            text = text.replace("Одним сообщением:", "Одним сообщением — через пробелы или запятые:")
            text = text.replace("ID | AGM/EFB/Ca/Ca | Ah | Производитель | Модель", "ID AGM/EFB/Ca/Ca Ah Производитель Модель")
            text = text.replace("varta70 | AGM | 70 | Varta | Silver Dynamic AGM", "varta70 AGM 70 Varta Silver Dynamic AGM")
            text += "\n\nЗапятые и старый разделитель | тоже поддерживаются."
        replacements = {
            "🧭 V2 controller": "Контроллер заряда",
            "Stage:": "Этап:",
            "Выберите intent. Высоковольтный этап доступен только Recovery/Conditioning.": (
                "Выберите цель программы. Обычный/Восстановление/Кондиционирование могут использовать "
                "стандартный recovery/Mix по критериям; Диагностика автоматический HV не включает."
            ),
            "Preview устарел": "Предпросмотр устарел",
            "auto-profile": "автоматической программы",
        }
        for old, new in replacements.items():
            text = text.replace(old, new)
        await original_safe_answer(event, text, reply_markup=reply_markup)

    production_bot_ui._safe_answer = _safe_answer_operator
    production_bot_ui._intent_keyboard = _operator_intent_keyboard
    production_bot_ui._preview_keyboard = _operator_preview_keyboard
    # Telegram START reaches the existing V2 owner only after StartPreflightService
    # and the transactional ExecutionPort checks have passed.
    v3_transaction_adapter = StartTransactionAdapter()
    v3_runner_adapter = StartTransactionRunner(app, event_factory=build_start_event_context)
    v3_production_runner = ProductionStartRunner(
        transaction_adapter=v3_transaction_adapter,
        transaction_runner=v3_runner_adapter,
    )
    v3_start_port = ProductionStartExecutionPort(
        transaction_adapter=v3_transaction_adapter,
        production_runner=v3_production_runner,
    )
    app._v3_production_start_route = ProductionStartRouteAdapter(
        app,
        port=v3_start_port,
    )

    @app.router.callback_query(F.data == "v2_battery_start")
    async def _battery_start_route(call: Any) -> None:
        if not await app._check_chat_and_respond(call):
            return
        # Callback queries expire while the transactional preflight and native
        # lease acknowledgement are in flight. Acknowledge exactly once here;
        # deliver the durable result through the source message below.
        await call.answer()
        message = getattr(call, "message", None)

        async def _send_result(text: str) -> None:
            answer = getattr(message, "answer", None)
            if not callable(answer):
                logger.error("START result could not be delivered: callback has no source message")
                return
            try:
                await answer(text)
            except Exception:
                logger.exception("START result message delivery failed")

        user_id = call.from_user.id if call.from_user else 0
        pending = production_bot_ui._pending_start.get(user_id)
        if pending is None:
            await _send_result("Предпросмотр устарел — выберите АКБ заново")
            return
        intent = OperatorIntent(
            OperatorIntentKind.START_CHARGE,
            "telegram",
            str(user_id),
            {
                "profile": pending.profile,
                "capacity_ah": pending.capacity_ah,
                "battery_identity": None,
                "battery_id": pending.battery_id,
                "intent": pending.intent,
                "condition": pending.condition,
                "user_recipe_id": pending.recipe_id,
                "user_recipe_version": pending.recipe_version,
                "native_recipe_name": pending.native_recipe_name,
                "native_recipe_version": pending.native_recipe_version,
            },
        )
        result = await app._v3_production_start_route.submit(intent)
        if not result.accepted:
            await _send_result(f"START отклонён: {result.reason}")
            return
        await _send_result(production_bot_ui.format_start_feedback(result))

    production_bot_ui.install_ui_support(app)
    install_sg_ui(app)
    install_dashboard_polish(app, production_bot_ui)
    app._selected_program_for_user = production_bot_ui.selected_program_for_user
    app._charge_modes_text = _operator_modes_text
    app._build_charge_modes_keyboard = _operator_modes_keyboard

    def _build_operator_dashboard(is_on: bool, user_id: int, *, back_to_dashboard: bool = False) -> InlineKeyboardMarkup:
        return build_operator_dashboard_keyboard(app, is_on, user_id, back_to_dashboard=back_to_dashboard)

    app._build_dashboard_keyboard = _build_operator_dashboard
    installed_handle_ah = app.handle_ah_input

    async def _handle_ah_conservative(message, profile: str, user_id: int) -> None:
        production_bot_ui._pending_intent.setdefault(user_id, ChargeIntent.NORMAL)
        await installed_handle_ah(message, profile, user_id)

    app.handle_ah_input = _handle_ah_conservative
    install_panel_last(app)


async def init_production_storage() -> None:
    await init_battery_registry()
    await init_battery_diagnostics_store()
