from __future__ import annotations

import html
import hashlib
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Dict, Optional

from aiogram import F
from aiogram.exceptions import TelegramBadRequest
from aiogram.enums import ParseMode
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from battery_registry import BatteryRecord, upsert_battery
from pb_domain import (
    BatteryChemistry,
    BatteryCondition,
    BatteryIdentity,
    BatteryLifecycle,
    ChargeIntent,
)
from battery_catalog import list_batteries
from ui_support import (
    battery_button_label,
    build_program_preview,
    format_active_evidence,
    format_battery_card,
    intent_label,
    profile_for_chemistry,
)
from application.intents import OperatorIntent, OperatorIntentKind
from runtime.charge.profiles.manual import has_manual_profile
from runtime.ui.telegram.charge import CHARGE_CALLBACK_DATA
from runtime.ui.telegram.details import HOME_CALLBACK_DATA

async def _ack_callback(call: Any, *args: Any, **kwargs: Any) -> None:
    """Expired Telegram callback acknowledgement must not abort navigation."""
    try:
        await call.answer(*args, **kwargs)
    except TelegramBadRequest as exc:
        reason = str(exc).lower()
        if "query is too old" not in reason and "query id is invalid" not in reason:
            raise


MANUAL_PROFILE_PATH = Path(__file__).resolve().parent / "config" / "charge" / "manual.yaml"


@dataclass(frozen=True)
class PendingStart:
    profile: str
    capacity_ah: float
    intent: ChargeIntent
    battery_id: str
    condition: BatteryCondition
    recipe_id: str | None = None
    recipe_version: int | None = None
    native_recipe_name: str | None = None
    native_recipe_version: int | None = None


_pending_profile: Dict[int, str] = {}
_pending_intent: Dict[int, ChargeIntent] = {}
_pending_start: Dict[int, PendingStart] = {}
_battery_pages: Dict[int, list[BatteryRecord]] = {}
_selected_battery: Dict[int, BatteryRecord] = {}
_new_battery_input: set[int] = set()
_installed = False


def _battery_callback_token(battery_id: str) -> str:
    """Return a short deterministic identity token safe for Telegram callbacks."""
    return hashlib.sha256(str(battery_id).encode("utf-8")).hexdigest()[:12]


def _battery_callback_data(record: BatteryRecord) -> str:
    return f"v2_battery_id_{_battery_callback_token(record.identity.battery_id)}"


def _battery_rows(records: list[BatteryRecord]) -> list[list[InlineKeyboardButton]]:
    return [
        [InlineKeyboardButton(text=battery_button_label(record), callback_data=_battery_callback_data(record))]
        for record in records
    ]


async def _resolve_battery_callback(raw: str, user_id: int) -> Optional[BatteryRecord]:
    """Resolve durable callbacks first; retain old page indexes for compatibility."""
    if raw.startswith("id_"):
        token = raw[3:]
        records = await list_batteries(limit=200)
        return next(
            (
                record
                for record in records
                if profile_for_chemistry(record.identity.chemistry)
                and _battery_callback_token(record.identity.battery_id) == token
            ),
            None,
        )
    if not raw.isdigit():
        return None
    idx = int(raw)
    records = _battery_pages.get(user_id) or []
    if idx < 0 or idx >= len(records):
        records = [r for r in await list_batteries(limit=200) if profile_for_chemistry(r.identity.chemistry)]
        _battery_pages[user_id] = records
    return records[idx] if 0 <= idx < len(records) else None


def selected_battery_for_user(user_id: int) -> Optional[BatteryRecord]:
    return _selected_battery.get(int(user_id))


def selected_program_for_user(user_id: int) -> Optional[str]:
    """Return the process-local pending selection for operator presentation."""
    user_id = int(user_id)
    pending = _pending_start.get(user_id)
    if pending is not None:
        return f"{pending.profile} {pending.capacity_ah:g} Ah · {intent_label(pending.intent)}"
    profile = _pending_profile.get(user_id)
    if profile:
        return f"{profile} · ожидается ёмкость АКБ"
    record = _selected_battery.get(user_id)
    if record is not None:
        return f"{record.identity.chemistry.value} {record.identity.nominal_capacity_ah:g} Ah · выбрана АКБ"
    return None


def _clear_pending_program_state(app: Any, user_id: int) -> None:
    """Drop only the selection wizard state after START was accepted."""
    user_id = int(user_id)
    _pending_start.pop(user_id, None)
    _pending_profile.pop(user_id, None)
    _pending_intent.pop(user_id, None)
    awaiting = getattr(app, "awaiting_ah", None)
    if isinstance(awaiting, dict):
        awaiting.pop(user_id, None)


def format_start_feedback(result: Any) -> str:
    """Describe the route result without confusing ACTIVE with DRY_RUN."""
    trace = str(getattr(result, "trace_id", ""))[:8]
    if not bool(getattr(result, "accepted", False)):
        return f"START отклонён: {getattr(result, 'reason', 'unknown')}"

    port_result = getattr(result, "port_result", None)
    mode = getattr(getattr(port_result, "mode", None), "value", "")
    if mode == "active":
        execution = getattr(port_result, "execution_result", None)
        status = getattr(getattr(execution, "status", None), "value", "accepted")
        return f"✅ ACTIVE START {status}: {getattr(result, 'reason', 'accepted')} ({trace})"
    if mode == "dry_run":
        return f"✅ START preflight PASS; DRY_RUN, заряд не запускался ({trace})"
    if mode:
        return f"✅ START {mode.upper()}: {getattr(result, 'reason', 'accepted')} ({trace})"
    return f"✅ START принят: {getattr(result, 'reason', 'accepted')} ({trace})"


def _intent_keyboard(prefix: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="⚡ Обычный", callback_data=f"{prefix}_normal"),
                InlineKeyboardButton(text="🛠 Recovery", callback_data=f"{prefix}_recovery"),
            ],
            [
                InlineKeyboardButton(text="🔄 Condition", callback_data=f"{prefix}_conditioning"),
                InlineKeyboardButton(text="🔬 Диагностика", callback_data=f"{prefix}_diagnostic"),
            ],
            [InlineKeyboardButton(text="⬅️ Режимы", callback_data=CHARGE_CALLBACK_DATA)],
        ]
    )


def _preview_keyboard(start_callback: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="▶️ Запустить", callback_data=start_callback)],
            [InlineKeyboardButton(text="⬅️ Режимы", callback_data=CHARGE_CALLBACK_DATA)],
        ]
    )


def _recipe_preview_keyboard(app: Any, start_callback: str) -> InlineKeyboardMarkup:
    original = _preview_keyboard(start_callback)
    catalog = getattr(app, '_user_recipe_catalog', None)
    if catalog is None:
        return original
    rows = list(original.inline_keyboard)
    choices = []
    for name in catalog.active_recipes():
        versions = catalog.library.versions(name)
        if not versions:
            continue
        version = versions[-1]
        data = f'v2_recipe_pick:{name}:{version}'
        if len(data.encode('utf-8')) <= 64:
            choices.append(InlineKeyboardButton(text=f'Рецепт {name} v{version}', callback_data=data))
    # Saved native recipe copies reuse the same pending START transaction.
    from runtime.charge.programs.native_recipe_draft_library import NativeRecipeDraftLibrary
    native_store = NativeRecipeDraftLibrary(catalog.library.root.parent / "native_recipe_drafts")
    for name in native_store.list_drafts():
        versions = native_store.versions(name)
        if not versions:
            continue
        version = versions[-1]
        data = f"v2_native_pick:{name}:{version}"
        if len(data.encode("utf-8")) <= 64:
            choices.append(InlineKeyboardButton(
                text=f"Штатная копия {name} v{version}", callback_data=data,
            ))
    if choices:
        rows[1:1] = [[choice] for choice in choices[:24]]
    else:
        rows.insert(1, [InlineKeyboardButton(text='Создать рецепт', callback_data='recipes:create')])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _parse_intent(value: str) -> ChargeIntent:
    return ChargeIntent(str(value).strip().lower())


def _parse_chemistry(value: str) -> BatteryChemistry:
    raw = str(value).strip().lower().replace(" ", "").replace("-", "_")
    aliases = {
        "agm": BatteryChemistry.AGM,
        "efb": BatteryChemistry.EFB,
        "ca": BatteryChemistry.CA_CA,
        "caca": BatteryChemistry.CA_CA,
        "ca/ca": BatteryChemistry.CA_CA,
        "ca_ca": BatteryChemistry.CA_CA,
        "flooded": BatteryChemistry.FLOODED,
        "liquid": BatteryChemistry.FLOODED,
    }
    try:
        return aliases[raw]
    except KeyError as exc:
        raise ValueError("тип должен быть AGM, EFB, Ca/Ca или Flooded") from exc


def parse_battery_spec(text: str) -> tuple[BatteryIdentity, BatteryLifecycle]:
    """Parse one-line registry input: ID | chemistry | Ah | manufacturer | model."""
    parts = [part.strip() for part in str(text or "").split("|")]
    if len(parts) < 3:
        raise ValueError("формат: ID | AGM/EFB/Ca/Ca | Ah | производитель | модель")
    battery_id = parts[0]
    if not battery_id or len(battery_id) > 64:
        raise ValueError("ID обязателен и должен быть короче 65 символов")
    chemistry = _parse_chemistry(parts[1])
    try:
        capacity = float(parts[2].replace(",", "."))
    except ValueError as exc:
        raise ValueError("ёмкость Ah должна быть числом") from exc
    if capacity <= 0 or capacity > 1000:
        raise ValueError("ёмкость должна быть в диапазоне 0..1000 Ah")
    manufacturer = parts[3] if len(parts) >= 4 else ""
    model = parts[4] if len(parts) >= 5 else ""
    identity = BatteryIdentity(
        battery_id=battery_id,
        chemistry=chemistry,
        nominal_capacity_ah=capacity,
        manufacturer=manufacturer,
        model=model,
    )
    return identity, BatteryLifecycle(condition=BatteryCondition.UNKNOWN)


def _profile_from_callback(data: str) -> Optional[str]:
    return {
        "v2_profile_caca": "Ca/Ca",
        "v2_profile_efb": "EFB",
        "v2_profile_agm": "AGM",
    }.get(data)


async def _safe_answer(event: Any, text: str, *, reply_markup=None) -> None:
    message = event.message if hasattr(event, "message") and event.message is not None else event
    await message.answer(text, parse_mode=ParseMode.HTML, reply_markup=reply_markup)


async def _route_profile_intent(app: Any, call: Any, profile: str) -> bool:
    interface = getattr(app, "operator_interface", None)
    submit = getattr(interface, "submit_intent", None)
    if not callable(submit):
        return True
    user = str(getattr(getattr(call, "from_user", None), "id", "0"))
    result = await submit(
        OperatorIntent(OperatorIntentKind.SELECT_CHARGE_PROFILE, "telegram", user, {"profile": profile})
    )
    if getattr(result, "status", None) == "rejected":
        await _ack_callback(call, "Профиль недоступен", show_alert=True)
        return False
    return True


def install_ui_support(app: Any) -> None:
    """Install the Telegram operator presentation/workflow over the runtime substrate.

    This installer owns presentation and callback composition only. Physical execution
    is submitted through the canonical production start route.
    """
    global _installed
    if _installed:
        return
    _installed = True

    original_dashboard_keyboard = app._build_dashboard_keyboard
    original_progress = app._format_stage_progress_line
    original_handle_ah = app.handle_ah_input
    original_handle_dialog = app.handle_dialog_mode

    def build_dashboard_keyboard(is_on: bool, user_id: int, *, back_to_dashboard: bool = False):
        markup = original_dashboard_keyboard(is_on, user_id, back_to_dashboard=back_to_dashboard)
        rows = list(markup.inline_keyboard)
        insert_at = max(0, len(rows) - (2 if back_to_dashboard else 1))
        return InlineKeyboardMarkup(inline_keyboard=rows)

    def charge_modes_text() -> str:
        return (
            "<b>🧭 Программа заряда</b>\n\n"
            "Сначала выберите химию или сохранённую физическую батарею, затем <b>intent</b>.\n\n"
            "⚡ Normal — полный штатный AUTO; Recovery/Mix включаются только по критериям стратегии.\n"
            "🛠 Recovery — восстановительный intent с HV только в разрешённом recipe/diagnostic envelope.\n"
            "🔄 Conditioning — сервисный режим в recipe envelope.\n"
            "🔬 Diagnostic — без автоматической HV-эскалации.\n\n"
            "В CV финиш оценивается по <b>Imin→ΔI</b>, в CC — по <b>Vmax→ΔV</b>."
        )

    def build_charge_modes_keyboard() -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(text="🟦 Ca/Ca", callback_data="v2_profile_caca"),
                    InlineKeyboardButton(text="🟧 EFB", callback_data="v2_profile_efb"),
                    InlineKeyboardButton(text="🟥 AGM", callback_data="v2_profile_agm"),
                ],
                [
                    InlineKeyboardButton(text="🔋 Мои АКБ", callback_data="v2_batteries"),
                    InlineKeyboardButton(text="➕ АКБ", callback_data="v2_battery_add"),
                ],
                [
                    InlineKeyboardButton(text="🛠 Ручной MAIN → MIX", callback_data="v2_manual_choose"),
                ],
                [InlineKeyboardButton(text="⬅️ Назад", callback_data=HOME_CALLBACK_DATA)],
            ]
        )

    def format_stage_progress_line(live: Dict[str, Any]) -> str:
        if app.charge_controller.is_active and app.charge_controller.current_stage in {
            app.charge_controller.STAGE_MAIN,
            app.charge_controller.STAGE_MIX,
        }:
            try:
                snap = app.charge_controller.ui_support_snapshot()
                compact = format_active_evidence(
                    snap,
                    voltage_v=app._safe_float(live.get("battery_voltage")),
                    current_a=app._safe_float(live.get("current")),
                    temp_c=app._safe_float(live.get("temp_ext")),
                )
                return compact
            except Exception:
                pass
        return original_progress(live)

    async def handle_ah_input(message: Any, profile: str, user_id: int) -> None:
        intent = _pending_intent.pop(user_id, ChargeIntent.RECOVERY)
        try:
            capacity = float((message.text or "").strip().replace(",", "."))
        except ValueError:
            await original_handle_ah(message, profile, user_id)
            return
        if capacity < 1 or capacity > 500:
            await original_handle_ah(message, profile, user_id)
            return
        app.awaiting_ah.pop(user_id, None)
        pending = PendingStart(
            profile=profile,
            capacity_ah=capacity,
            intent=intent,
            battery_id=f"adhoc:{profile}:{capacity:g}:{user_id}",
            condition=BatteryCondition.UNKNOWN,
        )
        _pending_start[user_id] = pending
        preview = build_program_preview(
            profile=profile,
            capacity_ah=capacity,
            intent=intent,
            condition=BatteryCondition.UNKNOWN,
            battery_id=pending.battery_id,
        )
        await message.answer(
            preview.text,
            parse_mode=ParseMode.HTML,
            reply_markup=_preview_keyboard("v2_quick_start"),
        )

    async def handle_dialog_mode(message: Any) -> None:
        user_id = message.from_user.id if message.from_user else 0
        if user_id not in _new_battery_input:
            await original_handle_dialog(message)
            return
        try:
            identity, lifecycle = parse_battery_spec(message.text or "")
            await upsert_battery(identity, lifecycle)
        except Exception as exc:
            await message.answer(
                f"❌ {html.escape(str(exc))}\n\n"
                "Формат: <code>ID | AGM/EFB/Ca/Ca | Ah | Производитель | Модель</code>",
                parse_mode=ParseMode.HTML,
            )
            return
        _new_battery_input.discard(user_id)
        records = await list_batteries(limit=50)
        created = next((item for item in records if item.identity.battery_id == identity.battery_id), None)
        visible_records = [
            item for item in records if profile_for_chemistry(item.identity.chemistry)
        ]
        _battery_pages[user_id] = visible_records
        rows = _battery_rows(visible_records)
        rows.append([InlineKeyboardButton(text="➕ Добавить АКБ", callback_data="v2_battery_add")])
        rows.append([InlineKeyboardButton(text="⬅️ Режимы", callback_data=CHARGE_CALLBACK_DATA)])
        text = (
            (format_battery_card(created) if created else f"✅ АКБ <code>{html.escape(identity.battery_id)}</code> сохранена.")
            + "\n\n<b>Выберите сохранённую АКБ:</b>"
        )
        await message.answer(
            text,
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup(inline_keyboard=rows),
        )

    app._build_dashboard_keyboard = build_dashboard_keyboard
    app._charge_modes_text = charge_modes_text
    app._build_charge_modes_keyboard = build_charge_modes_keyboard
    app._format_stage_progress_line = format_stage_progress_line
    app.handle_ah_input = handle_ah_input
    app.handle_dialog_mode = handle_dialog_mode

    @app.router.callback_query(F.data == "v2_status")
    async def status_handler(call: Any) -> None:
        if not await app._check_chat_and_respond(call):
            return
        await _ack_callback(call, )
        live = await app.hass.get_all_live()
        snap = app.charge_controller.ui_support_snapshot()
        text = format_active_evidence(
            snap,
            voltage_v=app._safe_float(live.get("battery_voltage")),
            current_a=app._safe_float(live.get("current")),
            temp_c=app._safe_float(live.get("temp_ext")),
        )
        await _safe_answer(
            call,
            f"<b>🧭 Контроллер заряда</b>\n\n{text}\n\n"
            f"Stage: <code>{html.escape(app.charge_controller.current_stage)}</code>",
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[[InlineKeyboardButton(text="⬅️ Дашборд", callback_data=HOME_CALLBACK_DATA)]]
            ),
        )

    @app.router.callback_query(F.data == "v2_batteries")
    async def batteries_handler(call: Any) -> None:
        if not await app._check_chat_and_respond(call):
            return
        await _ack_callback(call, )
        user_id = call.from_user.id if call.from_user else 0
        records = [r for r in await list_batteries(limit=20) if profile_for_chemistry(r.identity.chemistry)]
        _battery_pages[user_id] = records
        if not records:
            await _safe_answer(
                call,
                "<b>🔋 Реестр АКБ пуст.</b>\nДобавьте физическую батарею или используйте быстрый профиль.",
                reply_markup=InlineKeyboardMarkup(
                    inline_keyboard=[
                        [InlineKeyboardButton(text="➕ Добавить АКБ", callback_data="v2_battery_add")],
                        [InlineKeyboardButton(text="⬅️ Режимы", callback_data=CHARGE_CALLBACK_DATA)],
                    ]
                ),
            )
            return
        rows = _battery_rows(records)
        rows.append([InlineKeyboardButton(text="➕ Добавить АКБ", callback_data="v2_battery_add")])
        rows.append([InlineKeyboardButton(text="⬅️ Режимы", callback_data=CHARGE_CALLBACK_DATA)])
        await _safe_answer(
            call,
            "<b>🔋 Физические аккумуляторы</b>\nВыберите батарею:",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=rows),
        )

    app._batteries_handler = batteries_handler

    @app.router.callback_query(F.data == "v2_battery_add")
    async def battery_add_handler(call: Any) -> None:
        if not await app._check_chat_and_respond(call):
            return
        await _ack_callback(call, )
        user_id = call.from_user.id if call.from_user else 0
        _new_battery_input.add(user_id)
        await _safe_answer(
            call,
            "<b>➕ Добавление АКБ</b>\n\n"
            "Одним сообщением:\n"
            "<code>ID | AGM/EFB/Ca/Ca | Ah | Производитель | Модель</code>\n\n"
            "Например:\n<code>varta70 | AGM | 70 | Varta | Silver Dynamic AGM</code>",
        )

    app._battery_add_handler = battery_add_handler

    @app.router.callback_query(
        F.data.startswith("v2_battery_")
        & ~F.data.in_({"v2_battery_add", "v2_battery_start"})
    )
    async def battery_select_handler(call: Any) -> None:
        if not await app._check_chat_and_respond(call):
            return
        await _ack_callback(call, )
        user_id = call.from_user.id if call.from_user else 0
        raw = (call.data or "").replace("v2_battery_", "", 1)
        if raw.startswith("id_"):
            record = await _resolve_battery_callback(raw, user_id)
            if record is None:
                await _safe_answer(
                    call,
                    "<b>Список АКБ устарел.</b> Откройте раздел АКБ заново.",
                    reply_markup=InlineKeyboardMarkup(
                        inline_keyboard=[
                            [InlineKeyboardButton(text="🔄 АКБ", callback_data="v2_batteries")],
                            [InlineKeyboardButton(text="⬅️ Режимы", callback_data=CHARGE_CALLBACK_DATA)],
                        ]
                    ),
                )
                return
            records = [record]
            idx = 0
        elif raw.isdigit():
            idx = int(raw)
            records = _battery_pages.get(user_id) or []
            if idx < 0 or idx >= len(records):
                records = [r for r in await list_batteries(limit=200) if profile_for_chemistry(r.identity.chemistry)]
                _battery_pages[user_id] = records
        else:
            return
        if idx < 0 or idx >= len(records):
            await _safe_answer(
                call,
                "<b>Список АКБ устарел.</b> Откройте раздел АКБ заново.",
                reply_markup=InlineKeyboardMarkup(
                    inline_keyboard=[
                        [InlineKeyboardButton(text="🔄 АКБ", callback_data="v2_batteries")],
                        [InlineKeyboardButton(text="⬅️ Режимы", callback_data=CHARGE_CALLBACK_DATA)],
                    ]
                ),
            )
            return
        record = records[idx]
        _selected_battery[user_id] = record
        manual_button = []
        if has_manual_profile(MANUAL_PROFILE_PATH, record.identity.battery_id):
            manual_button = [[InlineKeyboardButton(
                text="▶️ Запустить сохранённый Manual",
                callback_data="v2_battery_manual",
            )]]
        await _safe_answer(
            call,
            f"{format_battery_card(record)}\n\n<b>Что делаем?</b>",
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=manual_button + _intent_keyboard("v2_bat_intent").inline_keyboard
            ),
        )
    async def _select_quick_profile(call: Any, profile: str) -> None:
        if not await app._check_chat_and_respond(call):
            return
        await _ack_callback(call, )
        if profile not in {"Ca/Ca", "EFB", "AGM"}:
            await _ack_callback(call, "Неизвестный профиль", show_alert=True)
            return
        if not await _route_profile_intent(app, call, profile):
            return
        user_id = call.from_user.id if call.from_user else 0
        _pending_profile[user_id] = profile
        await _safe_answer(
            call,
            f"<b>{html.escape(profile)}</b>\nВыберите intent. Normal — полный штатный AUTO; стандартный Recovery/Mix используется только по критериям стратегии.",
            reply_markup=_intent_keyboard("v2_quick_intent"),
        )

    app._select_quick_profile = _select_quick_profile

    @app.router.callback_query(F.data.startswith("v2_profile_"))
    async def quick_profile_handler(call: Any) -> None:
        profile = _profile_from_callback(call.data or "")
        if not profile:
            return
        await _select_quick_profile(call, profile)

    @app.router.callback_query(F.data.startswith("v2_quick_intent_"))
    async def quick_intent_handler(call: Any) -> None:
        if not await app._check_chat_and_respond(call):
            return
        await _ack_callback(call, )
        user_id = call.from_user.id if call.from_user else 0
        profile = _pending_profile.get(user_id)
        if not profile:
            await _ack_callback(call, "Сначала выберите профиль", show_alert=True)
            return
        intent = _parse_intent((call.data or "").replace("v2_quick_intent_", "", 1))
        _pending_intent[user_id] = intent
        app.awaiting_ah[user_id] = profile
        await _safe_answer(
            call,
            f"{html.escape(intent_label(intent))} · <b>{html.escape(profile)}</b>\n\nВведите ёмкость АКБ в Ah. После ввода покажу программу перед запуском.",
        )

    @app.router.callback_query(F.data == "v2_quick_start")
    async def quick_start_handler(call: Any) -> None:
        trace = getattr(app, "logger", None)
        if trace is not None:
            trace.info("QUICK_START_TRACE enter")
        if not await app._check_chat_and_respond(call):
            if trace is not None:
                trace.info("QUICK_START_TRACE chat_guard=DENY")
            return
        if trace is not None:
            trace.info("QUICK_START_TRACE chat_guard=PASS")
        await _ack_callback(call, )
        user_id = call.from_user.id if call.from_user else 0
        message = getattr(call, "message", None)
        if trace is not None:
            trace.info("QUICK_START_TRACE user_state user_id=%s", user_id)
        pending = _pending_start.get(user_id)
        if trace is not None:
            if pending is None:
                trace.info("QUICK_START_TRACE pending=MISS")
            else:
                trace.info(
                    "QUICK_START_TRACE pending=FOUND profile=%s intent=%s capacity_ah=%s battery_id=%s",
                    pending.profile,
                    pending.intent.value,
                    pending.capacity_ah,
                    pending.battery_id,
                )
        if pending is None:
            await _ack_callback(call, "Preview устарел — выберите режим заново", show_alert=True)
            return
        route = getattr(app, "_v3_production_start_route", None)
        if trace is not None:
            trace.info("QUICK_START_TRACE route=%s", "FOUND" if route is not None else "MISSING")
        if route is None:
            await _ack_callback(call, "START route is not installed", show_alert=True)
            return
        intent = OperatorIntent(
            OperatorIntentKind.START_CHARGE,
            "telegram",
            str(user_id),
            {
                "profile": pending.profile,
                "capacity_ah": pending.capacity_ah,
                "battery_identity": None,
                "battery_id": pending.battery_id,
                "intent": pending.intent,
                "condition": pending.condition,
            },
        )
        if trace is not None:
            trace.info(
                "QUICK_START_TRACE request profile=%s intent=%s capacity_ah=%s",
                pending.profile,
                pending.intent.value,
                pending.capacity_ah,
            )
        try:
            result = await route.submit(intent)
        except Exception as exc:
            if trace is not None:
                trace.info("QUICK_START_TRACE route=EXCEPTION type=%s", type(exc).__name__)
            raise
        if trace is not None:
            trace.info(
                "QUICK_START_TRACE result accepted=%s reason=%s mode=%s",
                result.accepted,
                result.reason,
                getattr(getattr(result.port_result, "mode", None), "value", None),
            )
        if not result.accepted:
            if message is not None:
                await message.answer(format_start_feedback(result), parse_mode=None)
            if trace is not None:
                trace.info("QUICK_START_TRACE response=REJECTED")
            return
        _clear_pending_program_state(app, user_id)
        if trace is not None:
            trace.info("QUICK_START_TRACE pending=CLEARED after_route=PASS")
        # Do not render a panel before the START result. The terminal
        # navigation middleware publishes the authoritative graph/control
        # panel once, after this handler has delivered feedback.
        # The route owns preflight and transactional safety; the callback only
        # submits the operator intent and never touches hardware directly.
        # The callback was acknowledged before the transactional START.  That
        # transaction can outlive Telegram's callback-query window; send its
        # result as a chat message instead of answering an expired query.
        if message is not None:
            await message.answer(format_start_feedback(result), parse_mode=None)
        if trace is not None:
            trace.info("QUICK_START_TRACE response=ACCEPTED")

    @app.router.callback_query(F.data.startswith("v2_native_pick:"))
    async def pick_native_recipe_handler(call: Any) -> None:
        if not await app._check_chat_and_respond(call):
            return
        user_id = call.from_user.id if call.from_user else 0
        pending = _pending_start.get(user_id)
        catalog = getattr(app, "_user_recipe_catalog", None)
        if pending is None or catalog is None:
            await _ack_callback(call, "Нет ожидающего START", show_alert=True)
            return
        try:
            _, name, version_text = str(call.data).split(":")
            version = int(version_text)
            from runtime.charge.programs.native_recipe_draft_library import NativeRecipeDraftLibrary
            from runtime.charge.programs.native_recipe_session import select_native_recipe_version
            library = NativeRecipeDraftLibrary(catalog.library.root.parent / "native_recipe_drafts")
            selected = select_native_recipe_version(
                library, name, version, profile=pending.profile, intent=pending.intent,
            )
        except (ValueError, KeyError, OSError, FileNotFoundError) as exc:
            await _ack_callback(call, str(exc)[:180], show_alert=True)
            return
        _pending_start[user_id] = replace(
            pending, recipe_id=None, recipe_version=None,
            native_recipe_name=name, native_recipe_version=version,
        )
        await _ack_callback(call)
        await _safe_answer(
            call, f"Выбрана копия {name} v{version} ({selected.profile} · {selected.intent}). "
                  "START применит закреплённую версию.",
            reply_markup=_preview_keyboard("v2_battery_start"),
        )

    @app.router.callback_query(F.data.startswith("v2_recipe_pick:"))
    async def pick_recipe_handler(call: Any) -> None:
        if not await app._check_chat_and_respond(call):
            return
        user_id = call.from_user.id if call.from_user else 0
        pending = _pending_start.get(user_id)
        catalog = getattr(app, "_user_recipe_catalog", None)
        if pending is None or catalog is None:
            await _ack_callback(call, "Сначала выберите АКБ и режим", show_alert=True)
            return
        try:
            _, name, version_text = str(call.data).split(":")
            version = int(version_text)
            if name not in catalog.active_recipes():
                raise ValueError("Рецепт архивирован")
            recipe = catalog.library.load(name, version)
            from runtime.charge.programs.recipe_preflight import inspect_recipe
            report = inspect_recipe(recipe)
            if not report.admissible_structure:
                raise ValueError("; ".join(report.problems))
        except (ValueError, OSError) as exc:
            await _ack_callback(call, str(exc)[:180], show_alert=True)
            return
        _pending_start[user_id] = replace(
            pending, recipe_id=name, recipe_version=version,
            native_recipe_name=None, native_recipe_version=None,
        )
        await _ack_callback(call)
        await _safe_answer(call, f"Выбран {name} v{version}. START запустит этот рецепт.",
                           reply_markup=_preview_keyboard("v2_battery_start"))

    @app.router.callback_query(F.data.startswith("v2_bat_intent_"))
    async def battery_intent_handler(call: Any) -> None:
        if not await app._check_chat_and_respond(call):
            return
        await _ack_callback(call, )
        user_id = call.from_user.id if call.from_user else 0
        record = _selected_battery.get(user_id)
        if record is None:
            await _ack_callback(call, "Сначала выберите АКБ", show_alert=True)
            return
        profile = profile_for_chemistry(record.identity.chemistry)
        if profile is None:
            await _ack_callback(call, "Для этой химии пока нет auto-profile", show_alert=True)
            return
        intent = _parse_intent((call.data or "").replace("v2_bat_intent_", "", 1))
        pending = PendingStart(
            profile=profile,
            capacity_ah=record.identity.nominal_capacity_ah,
            intent=intent,
            battery_id=record.identity.battery_id,
            condition=record.lifecycle.condition,
        )
        _pending_start[user_id] = pending
        preview = build_program_preview(
            profile=profile,
            capacity_ah=pending.capacity_ah,
            intent=intent,
            condition=pending.condition,
            battery_id=pending.battery_id,
        )
        await _safe_answer(
            call,
            f"{format_battery_card(record)}\n\n{preview.text}",
            reply_markup=_recipe_preview_keyboard(app, "v2_battery_start"),
        )
