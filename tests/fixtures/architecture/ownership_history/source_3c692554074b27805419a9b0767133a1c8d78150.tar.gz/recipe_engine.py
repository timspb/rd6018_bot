from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

from pb_domain import BatteryChemistry, BatteryCondition, ChargeContext, ChargeIntent
from runtime.safety.variables import MAX_STAGE_CURRENT_A


@dataclass(frozen=True)
class ChemistryPolicy:
    normal_voltage_ceiling_v: float
    recovery_voltage_ceiling_v: float
    expert_voltage_ceiling_v: float
    main_current_c_max: float
    hv_current_c_max: float


@dataclass(frozen=True)
class RecipeEnvelope:
    recipe_id: str
    chemistry: BatteryChemistry
    intent: ChargeIntent
    condition: BatteryCondition
    voltage_ceiling_v: float
    main_current_limit_a: float
    hv_current_limit_a: float
    expert_authorized: bool
    rationale: str

    def allows_voltage(self, target_v: float) -> bool:
        return float(target_v) <= self.voltage_ceiling_v + 1e-9


# Generic Pb HV stages implemented by this controller never request more than 0.03C:
# intermediate Recovery/Desulfation is ~0.02C and final Mix is ~0.03C. The envelope is
# an authorization maximum, not speculative headroom, so it must not silently permit
# a future generic 0.05C HV target. Manual/Custom has separate explicit authority.
POLICIES: Dict[BatteryChemistry, ChemistryPolicy] = {
    BatteryChemistry.AGM: ChemistryPolicy(15.0, 16.3, 16.3, 0.10, 0.03),
    # No generic manufacturer-backed EFB automatic/conditioning profile above 16.5 V
    # was found. 17.5 V remains the global Manual/custom outer ceiling, not an EFB
    # chemistry entitlement. A future >16.5 V EFB recipe must be model-specific and
    # backed by an explicit manufacturer document rather than this generic policy.
    BatteryChemistry.EFB: ChemistryPolicy(14.8, 16.5, 16.5, 0.10, 0.03),
    BatteryChemistry.CA_CA: ChemistryPolicy(14.7, 16.5, 16.5, 0.10, 0.03),
    BatteryChemistry.FLOODED: ChemistryPolicy(14.8, 16.5, 16.5, 0.10, 0.03),
    BatteryChemistry.CUSTOM: ChemistryPolicy(16.6, 16.6, 17.5, 0.20, 0.20),
}


def _clamp_current(capacity_ah: float, c_rate: float, hardware_max_a: float) -> float:
    return min(float(hardware_max_a), max(0.0, float(capacity_ah) * float(c_rate)))


def select_recipe_envelope(
    context: ChargeContext,
    *,
    expert_high_voltage: bool = False,
    custom_voltage_ceiling_v: Optional[float] = None,
    hardware_max_current_a: float = float(MAX_STAGE_CURRENT_A.default),
) -> RecipeEnvelope:
    """Select the allowed target envelope; stage logic chooses actual setpoints.

    NORMAL intentionally preserves the accepted V1 full automatic charge chain, which
    includes bounded recovery/final Mix. DIAGNOSTIC is the explicit no-automatic-HV
    intent and therefore keeps the normal/Main voltage ceiling.

    `expert_high_voltage` may only enlarge a chemistry envelope when the corresponding
    ChemistryPolicy actually defines a higher expert ceiling. Supplying the flag is not
    itself permission to exceed a chemistry's documented recovery ceiling.
    """
    policy = POLICIES[context.identity.chemistry]
    chemistry = context.identity.chemistry
    intent = context.intent
    expert_extension_available = (
        policy.expert_voltage_ceiling_v > policy.recovery_voltage_ceiling_v + 1e-9
    )
    expert_extension_used = False

    if chemistry == BatteryChemistry.CUSTOM and custom_voltage_ceiling_v is not None:
        requested = float(custom_voltage_ceiling_v)
        hard = (
            policy.expert_voltage_ceiling_v
            if expert_high_voltage
            else policy.normal_voltage_ceiling_v
        )
        ceiling = min(requested, hard)
        expert_extension_used = bool(
            expert_high_voltage
            and ceiling > policy.normal_voltage_ceiling_v + 1e-9
        )
        rationale = (
            f"Custom operator ceiling {requested:.2f}V, bounded by "
            f"{hard:.2f}V policy envelope."
        )
    elif intent == ChargeIntent.DIAGNOSTIC:
        ceiling = policy.normal_voltage_ceiling_v
        rationale = "Diagnostic envelope; automatic recovery/Mix high voltage is disabled."
    elif intent == ChargeIntent.NORMAL:
        ceiling = policy.recovery_voltage_ceiling_v
        rationale = "V1-compatible normal automatic envelope including bounded recovery/Mix."
    elif intent == ChargeIntent.RECOVERY:
        ceiling = policy.recovery_voltage_ceiling_v
        rationale = "Recovery envelope explicitly selected by operator/workflow."
    elif intent == ChargeIntent.CONDITIONING:
        if expert_high_voltage and expert_extension_available:
            ceiling = policy.expert_voltage_ceiling_v
            expert_extension_used = True
            rationale = "Expert conditioning envelope explicitly authorized."
        elif expert_high_voltage:
            ceiling = policy.recovery_voltage_ceiling_v
            rationale = (
                "Expert flag supplied, but this chemistry has no generic expert extension; "
                "standard recovery ceiling remains authoritative."
            )
        else:
            ceiling = policy.recovery_voltage_ceiling_v
            rationale = "Conditioning within the standard recovery envelope."
    else:
        ceiling = policy.normal_voltage_ceiling_v
        rationale = "Conservative fallback envelope."

    if context.condition == BatteryCondition.REHYDRATED:
        rationale += " Battery is marked rehydrated; longitudinal cycle evidence is required."
    elif context.condition == BatteryCondition.DRY_SUSPECTED:
        rationale += " Dryness is suspected; high-voltage behavior must be interpreted with wetting state."

    return RecipeEnvelope(
        recipe_id=f"{chemistry.value}:{intent.value}",
        chemistry=chemistry,
        intent=intent,
        condition=context.condition,
        voltage_ceiling_v=ceiling,
        main_current_limit_a=_clamp_current(
            context.identity.nominal_capacity_ah,
            policy.main_current_c_max,
            hardware_max_current_a,
        ),
        hv_current_limit_a=_clamp_current(
            context.identity.nominal_capacity_ah,
            policy.hv_current_c_max,
            hardware_max_current_a,
        ),
        expert_authorized=expert_extension_used,
        rationale=rationale,
    )
