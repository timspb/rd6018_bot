"""Runtime mechanics for authoritative MIX and final SAFE_WAIT.

This adapter preserves accepted common safety/bookkeeping behavior without
entering the historical ChargeController.tick(). MIX/final completion decisions
remain in modular strategy owners.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, Optional

from runtime.charge.runtime.variables import (
    HISTORY_SAMPLE_INTERVAL_S,
    OPERATOR_REPORT_INTERVAL_S,
    STAGE_CLOCK_SANITY_MAX_HOURS,
)
from runtime.charge.strategy.mix_variables import mix_max_active_seconds
from runtime.safety.communication_variables import (
    LINK_LOSS_INITIAL_NOTICE_COUNT,
    LINK_LOSS_NOTICE_INTERVAL_S,
)
from runtime.safety.thermal_variables import (
    BATTERY_TEMP_CRITICAL_C,
    BATTERY_TEMP_PAUSE_C,
    BATTERY_TEMP_WARNING_C,
)
from runtime.safety.voltage_variables import PB_PROFILE_WARNING_VOLTAGE_V


logger = logging.getLogger("rd6018.charge.mix_runtime")


def apply_mix_authority_tick(
    host: Any, *, record: Any, timestamp_s: float,
    voltage: float, current: float, temp: float, ah: float,
    is_cv: bool, is_cc: bool, actions: Dict[str, Any],
) -> Any:
    """Own MIX evidence projection, transition decision, and effect dispatch."""
    from runtime.charge.decisions import AuthorityAction, AuthorityDecision
    from runtime.charge.evidence.mix_observation import (
        apply_mix_evidence_mirror, build_mix_evidence_mirror,
    )
    from runtime.charge.runtime.final_safe_wait_entry import apply_mix_completion_to_safe_wait
    from runtime.charge.runtime.mix_finish_hold import (
        apply_mix_finish_hold_effect, build_mix_finish_hold_effect,
    )
    from runtime.charge.runtime.stop_diagnose import apply_stop_and_diagnose
    from runtime.charge.strategy.mix import decide_mix_transition
    from runtime.charge.strategy.mix_variables import mix_finish_hold_seconds

    from runtime.charge.programs.native_recipe_session import native_target_parameters
    pinned_mix = native_target_parameters(host, "MIX_POLICY")
    finish_hold_s = float(
        pinned_mix.get("finish_hold_hours", mix_finish_hold_seconds() / 3600.0)
    ) * 3600.0
    metrics = record.analysis.metrics
    mirror = build_mix_evidence_mirror(
        is_cv=bool(is_cv), is_cc=bool(is_cc),
        current_min_a=metrics.current_min_a, voltage_max_v=metrics.voltage_max_v,
    )
    apply_mix_evidence_mirror(host, mirror)
    decision = decide_mix_transition(
        profile=host.battery_type,
        policy_decision=record.decision.decision,
        active_elapsed_s=max(0.0, timestamp_s - host.stage_start_time),
        authority_limit_s=mix_max_active_seconds(host.battery_type),
        finish_hold_started_at=host.finish_timer_start,
        now_s=timestamp_s,
        finish_hold_s=finish_hold_s,
    )
    if decision.action == AuthorityAction.START_FINISH_HOLD:
        effect = build_mix_finish_hold_effect(
            now_s=timestamp_s, is_cc=bool(is_cc), is_cv=bool(is_cv),
            voltage_max_v=metrics.voltage_max_v,
            delta_voltage_from_max_v=metrics.delta_voltage_from_max_v,
            current_min_a=metrics.current_min_a,
            delta_current_from_min_a=metrics.delta_current_from_min_a,
            session_id=host._v2_trace_session_id,
            hold_seconds=finish_hold_s,
            current_reversal_threshold_a=metrics.reversal_threshold_a,
            voltage_reversal_threshold_v=metrics.voltage_reversal_threshold_v,
        )
        apply_mix_finish_hold_effect(host, effect, actions)
        logger.info(
            "CHARGE_EVIDENCE kind=delta event=hold_start mode=%s hold_seconds=%.1f timestamp=%.3f",
            effect.mode or "unknown", finish_hold_s, timestamp_s,
        )
    elif decision.action == AuthorityAction.COMPLETE_TO_SAFE_WAIT:
        storage_v, storage_i = host._storage_target()
        if not apply_mix_completion_to_safe_wait(
            host, now_s=timestamp_s, voltage_v=voltage, current_a=current,
            temperature_c=temp, ah=ah, reason=decision.reason,
            target_voltage_v=storage_v, target_current_a=storage_i, actions=actions,
        ):
            reason = "final_safe_wait_entry_session_identity_invalid"
            apply_stop_and_diagnose(
                host, actions=actions, now=timestamp_s, voltage=voltage,
                current=current, temp=temp, ah=ah, reason=reason,
            )
            return AuthorityDecision(AuthorityAction.STOP_AND_DIAGNOSE, reason)
    elif decision.action == AuthorityAction.STOP_AND_DIAGNOSE:
        logger.info(
            "CHARGE_EVIDENCE kind=stop event=diagnose reason=%s owner=v2 timestamp=%.3f",
            decision.reason, timestamp_s,
        )
        apply_stop_and_diagnose(
            host, actions=actions, now=timestamp_s, voltage=voltage,
            current=current, temp=temp, ah=ah, reason=decision.reason,
        )
    return decision


def _output_is_known(value: Any) -> bool:
    return value is not None and str(value).lower() not in {
        "unavailable",
        "unknown",
        "",
    }


def _output_is_on(value: Any) -> bool:
    return value is True or str(value).lower() == "on"


def _phase_log(phase: str, voltage: float, current: float, temp: float) -> None:
    try:
        from time_utils import format_time_user_tz

        stamp = format_time_user_tz()
    except Exception:
        stamp = "-"
    logger.info(
        "%s | %-12s | %5.2fВ | %5.2fА | %5.1f°C",
        stamp,
        phase,
        voltage,
        current,
        temp,
    )


async def run_authoritative_mix_scaffold(
    host: Any,
    *,
    stage_before: str,
    voltage: float,
    current: float,
    temp_ext: Optional[float],
    is_cv: bool,
    ah: float,
    output_is_on: Optional[Any],
    manual_off_active: bool,
    is_cc: Optional[bool],
    manual_active: bool,
    report_limit_s: float,
    now_s: Optional[float] = None,
) -> Dict[str, Any]:
    """Run common safety/bookkeeping without historical stage transitions."""

    actions: Dict[str, Any] = {}
    resolved_is_cc = not bool(is_cv) if is_cc is None else bool(is_cc)
    host.is_cv = bool(is_cv)
    host.is_cc = resolved_is_cc
    now = float(time.time() if now_s is None else now_s)
    host.last_update_time = now

    if temp_ext is None or temp_ext in ("unavailable", "unknown", ""):
        host._was_unavailable = True
        host._link_lost_at = now
        actions["emergency_stop"] = True
        actions["log_event"] = "EMERGENCY_UNAVAILABLE"
        if host._last_known_output_on:
            should_notify = (
                host._link_loss_notice_count < int(LINK_LOSS_INITIAL_NOTICE_COUNT.default)
                or now - host._link_loss_last_notice_at
                >= float(LINK_LOSS_NOTICE_INTERVAL_S.default)
            )
            if should_notify:
                host._link_loss_notice_count += 1
                host._link_loss_last_notice_at = now
                msg = "⚠️ Связь потеряна во время заряда!"
                actions["notify"] = msg
                host.notify(msg)
            if host.is_active:
                host.stop(clear_session=False)
        else:
            host.stop(clear_session=False)
        return actions

    try:
        temp = float(temp_ext)
    except (ValueError, TypeError):
        msg = (
            "🔴 <b>АВАРИЯ:</b> Некорректные данные датчика температуры. "
            "Заряд остановлен в целях безопасности."
        )
        actions.update(
            emergency_stop=True,
            full_reset=True,
            notify=msg,
            log_event="EMERGENCY_TEMP_INVALID",
        )
        host.notify(msg)
        return actions

    critical = float(BATTERY_TEMP_CRITICAL_C.default)
    pause = float(BATTERY_TEMP_PAUSE_C.default)
    warning = float(BATTERY_TEMP_WARNING_C.default)

    if temp >= critical:
        msg = (
            "🔴 <b>КРИТИЧЕСКИЙ ПЕРЕГРЕВ в режиме!</b>\n"
            f"Температура: {temp:.1f}°C (критическая: {critical:.1f}°C)\n"
            "Заряд экстренно остановлен и сброшен!"
        )
        actions.update(
            emergency_stop=True,
            full_reset=True,
            notify=msg,
            log_event=f"EMERGENCY_TEMP_CRITICAL: {temp:.1f}°C >= {critical:.1f}°C",
        )
        host.notify(msg)
        return actions

    if temp >= pause:
        actions["log_event_end"] = host._make_log_event_end(
            now,
            ah,
            voltage,
            current,
            temp,
            f"T≥{pause:g}°C ({temp:.1f}°C)",
        )
        cooling_target_v, cooling_target_i = host._get_current_targets(temp)
        previous_stage = host.current_stage
        host.current_stage = host.STAGE_COOLING
        host._clear_restored_targets()
        host.stage_start_time = now
        host._stage_start_ah = ah
        host._cooling_from_stage = previous_stage
        host._cooling_target_v = cooling_target_v
        host._cooling_target_i = cooling_target_i
        msg = (
            "🌡 <b>ПЕРЕГРЕВ - ПАУЗА ЗАРЯДА!</b>\n"
            f"Температура: {temp:.1f}°C (лимит: {pause:g}°C)\n"
            f"Выход отключен. Ожидание охлаждения до {warning:g}°C."
        )
        actions.update(turn_off=True, notify=msg, log_event="START")
        host.notify(msg)
        return actions

    host._mark_stage_sample(voltage, current, temp, ah)

    if _output_is_known(output_is_on):
        host._last_known_output_on = _output_is_on(output_is_on)
    if host._was_unavailable:
        host._link_loss_notice_count = 0
        host._link_loss_last_notice_at = 0.0
        host._link_lost_at = 0.0
    host._was_unavailable = False

    host._analytics_history.append((now, voltage, current, ah, temp))
    if now - host._last_v_i_history_time >= float(HISTORY_SAMPLE_INTERVAL_S.default):
        host.v_history.append((now, voltage))
        host.i_history.append((now, current))
        host._last_v_i_history_time = now

    elapsed_check = now - host.stage_start_time
    if elapsed_check < 0 or elapsed_check > float(STAGE_CLOCK_SANITY_MAX_HOURS.default) * 3600.0:
        host.stage_start_time = now
        elapsed_check = 0.0
        logger.warning("mix runtime: stage_start_time corrected (elapsed invalid)")

    if host.emergency_hv_disconnect:
        host.notify(
            "🔴 <b>АВАРИЙНОЕ ОТКЛЮЧЕНИЕ:</b> "
            "Потеряна связь с контроллером при высоком напряжении (>15В)!"
        )
        host.emergency_hv_disconnect = False

    if temp >= warning and not host._temp_warning_alerted:
        host._temp_warning_alerted = True
        host._pending_log_event = "WARNING_35C"
        host.notify(
            f"⚠️ Внимание: Температура АКБ поднялась до {temp:.1f}°C. "
            f"При {pause:g}°C заряд будет приостановлен."
        )

    if voltage > float(PB_PROFILE_WARNING_VOLTAGE_V.default) and not manual_active:
        actions["notify"] = f"<b>⚠️ Напряжение</b> {voltage:.2f}V превышает лимит!"

    if host._pending_log_event:
        actions["log_event"] = host._pending_log_event
        host._pending_log_event = None

    elapsed = max(0.0, now - host.stage_start_time)
    if now - host._last_log_time >= float(HISTORY_SAMPLE_INTERVAL_S.default):
        _phase_log(host.current_stage, voltage, current, temp)
        host._last_log_time = now

    if not manual_off_active and now - host._last_hourly_report >= float(
        OPERATOR_REPORT_INTERVAL_S.default
    ):
        host._last_hourly_report = now
        max_seconds = max(0.0, float(report_limit_s))
        report = (
            f"⏳ Прошло {elapsed / 3600.0:.1f}ч из {max_seconds / 3600.0:.0f} лимита этапа. "
            f"Ток: {current:.2f} А, T: {temp:.1f}°C, Ah: {ah:.2f}."
        )
        if "notify" not in actions or not actions["notify"]:
            actions["notify"] = report
        else:
            host.notify(report)

    if is_cv:
        if host._cv_since is None:
            host._cv_since = now
    else:
        host._cv_since = None

    if host._stage_start_ah == 0:
        host._stage_start_ah = ah
        if "log_event" not in actions:
            actions["log_event"] = (
                f"START | Емкость: {host.ah_capacity}Ah | profile={host.battery_type}"
            )

    return actions


__all__ = ["run_authoritative_mix_scaffold"]
