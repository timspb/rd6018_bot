"""Mix policy and regulation-specific CC/CV exit policies."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from ..intent import ChargeIntent
from ..measurements import Measurements
from recovery_policy import RecoveryDecision
from runtime.charge.decisions import AuthorityAction, AuthorityDecision
from runtime.charge.strategy.mix_variables import (
    AGM_MIX_VOLTAGE_V,
    CA_MIX_VOLTAGE_V,
    EFB_MIX_VOLTAGE_V,
    MIX_CURRENT_C_RATE,
    MIX_MIN_CURRENT_A,
    mix_finish_hold_seconds,
    mix_max_active_seconds,
)


@dataclass
class MixAuthorityState:
    active_seconds: float = 0.0
    session_id: str | None = None
    exhausted: bool = False
    started_at: float | None = None
    last_timestamp: float | None = None


@dataclass
class MixCurrentContainmentState:
    """State for the delayed CV-Mix current-setpoint containment."""

    enabled: bool = False
    activated_at: Optional[float] = None
    fixed_limit: Optional[float] = None
    last_recalculation: Optional[float] = None
    reduction_count: int = 0


@dataclass
class MixExitRuntimeState:
    phase: str = "unarmed"
    observed_vmax: Optional[float] = None
    observed_imin: Optional[float] = None
    confirmation_count: int = 0
    last_confirmation_at: Optional[float] = None
    hold_started_at: Optional[float] = None
    containment: MixCurrentContainmentState = field(default_factory=MixCurrentContainmentState)


@dataclass(frozen=True)
class CCMixExitConfig:
    vmax_voltage: float
    delta_voltage: float
    confirmations_required: int
    hold_seconds: float
    target_voltage: float
    target_current: float
    active_stage: str = "mix"
    hold_stage: str = "mix_hold"
    completed_stage: str = "done"
    confirmation_interval_seconds: float = 0.0

    def __post_init__(self) -> None:
        if min(self.vmax_voltage, self.delta_voltage, self.target_voltage, self.target_current) <= 0:
            raise ValueError("CC Mix recipe values must be positive")
        if self.confirmations_required <= 0 or self.hold_seconds < 0 or self.confirmation_interval_seconds < 0:
            raise ValueError("CC Mix timing configuration is invalid")


@dataclass(frozen=True)
class CVMixExitConfig:
    imin_current: float
    delta_current: float
    confirmations_required: int
    hold_seconds: float
    target_voltage: float
    target_current: float
    active_stage: str = "mix"
    hold_stage: str = "mix_hold"
    completed_stage: str = "done"
    confirmation_interval_seconds: float = 0.0
    containment_start_seconds: float = 30 * 60
    containment_recalc_seconds: float = 10 * 60
    containment_headroom_a: float = 0.4

    def __post_init__(self) -> None:
        if min(self.imin_current, self.delta_current, self.target_voltage, self.target_current) <= 0:
            raise ValueError("CV Mix recipe values must be positive")
        if (
            self.confirmations_required <= 0
            or self.hold_seconds < 0
            or self.confirmation_interval_seconds < 0
            or self.containment_start_seconds < 0
            or self.containment_recalc_seconds <= 0
            or self.containment_headroom_a < 0
        ):
            raise ValueError("CV Mix timing configuration is invalid")


class CCMixExitPolicy:
    def __init__(self, config: CCMixExitConfig, state: MixExitRuntimeState | None = None) -> None:
        self.config, self.state = config, state or MixExitRuntimeState()

    def evaluate(self, measurements: Measurements, *, current_limit_clipped: bool = False) -> ChargeIntent:
        if measurements.voltage is None or measurements.current is None:
            return ChargeIntent(None, None, "stopped", True, "MIX_CC_EVIDENCE_INVALID")
        if current_limit_clipped and self.state.phase in {"unarmed", "tracking"}:
            # A forced CC segment contaminates the voltage maximum too. Require
            # a fresh, UNCLIPPED Vmax before interpreting subsequent voltage sag.
            self.state.phase = "unarmed"
            self.state.observed_vmax = None
            self.state.confirmation_count = 0
            self.state.last_confirmation_at = None
            return self._active("MIX_CC_DELTA_CENSORED_CURRENT_LIMIT")
        if self.state.phase == "unarmed":
            if measurements.voltage < self.config.vmax_voltage:
                return self._active("MIX_CC_WAIT_VMAX")
            self.state.observed_vmax = measurements.voltage
            self.state.phase = "tracking"
            return self._active("MIX_CC_VMAX_CONFIRMED")
        if self.state.phase == "tracking":
            delta_present = (self.state.observed_vmax is not None
                             and measurements.voltage <= self.state.observed_vmax - self.config.delta_voltage)
            _confirm_spaced(self.state, delta_present, measurements.time,
                            self.config.confirmation_interval_seconds)
            if self.state.confirmation_count >= self.config.confirmations_required:
                self.state.phase = "hold"
                self.state.hold_started_at = measurements.time
                return self._active("MIX_CC_DELTA_CONFIRMED")
            return self._active("MIX_CC_DELTA_WAIT")
        if self.state.phase == "hold":
            if measurements.time is not None and self.state.hold_started_at is not None and measurements.time - self.state.hold_started_at >= self.config.hold_seconds:
                self.state.phase = "complete"
                return ChargeIntent(self.config.target_voltage, self.config.target_current, self.config.completed_stage, True, "MIX_CC_HOLD_COMPLETE")
            return self._active("MIX_CC_HOLD")
        return ChargeIntent(None, None, "stopped", True, "MIX_CC_STOP")

    def _active(self, reason: str) -> ChargeIntent:
        return ChargeIntent(self.config.target_voltage, self.config.target_current, self.config.active_stage, False, reason)


class CVMixExitPolicy:
    def __init__(self, config: CVMixExitConfig, state: MixExitRuntimeState | None = None) -> None:
        self.config, self.state = config, state or MixExitRuntimeState()

    def evaluate(self, measurements: Measurements) -> ChargeIntent:
        if measurements.voltage is None or measurements.current is None:
            return ChargeIntent(None, None, "stopped", True, "MIX_CV_EVIDENCE_INVALID")
        if self.state.phase == "unarmed":
            if measurements.current > self.config.imin_current:
                return self._active("MIX_CV_WAIT_IMIN")
            self.state.observed_imin = measurements.current
            self.state.phase = "tracking"
            return self._active("MIX_CV_IMIN_CONFIRMED")
        if self.state.phase == "tracking":
            delta_present = (self.state.observed_imin is not None
                             and measurements.current >= self.state.observed_imin + self.config.delta_current)
            _confirm_spaced(self.state, delta_present, measurements.time,
                            self.config.confirmation_interval_seconds)
            if self.state.confirmation_count >= self.config.confirmations_required:
                self.state.phase = "hold"
                self.state.hold_started_at = measurements.time
                return self._active("MIX_CV_DELTA_CONFIRMED")
            return self._active("MIX_CV_DELTA_WAIT")
        if self.state.phase == "hold":
            if measurements.time is not None and self.state.hold_started_at is not None and measurements.time - self.state.hold_started_at >= self.config.hold_seconds:
                self.state.phase = "complete"
                return ChargeIntent(self.config.target_voltage, self.config.target_current, self.config.completed_stage, True, "MIX_CV_HOLD_COMPLETE")
            return self._active("MIX_CV_HOLD")
        return ChargeIntent(None, None, "stopped", True, "MIX_CV_STOP")

    def _active(self, reason: str) -> ChargeIntent:
        return ChargeIntent(self.config.target_voltage, self.config.target_current, self.config.active_stage, False, reason)


def _confirm_spaced(state: MixExitRuntimeState, delta_present: bool,
                    now: float | None, interval: float) -> None:
    if not delta_present or now is None:
        state.confirmation_count = 0
        state.last_confirmation_at = None
        return
    if state.last_confirmation_at is None or now - state.last_confirmation_at >= interval:
        state.confirmation_count += 1
        state.last_confirmation_at = now


@dataclass(frozen=True)
class MixPolicyConfig:
    active_authority_seconds: float
    cc: CCMixExitConfig
    cv: CVMixExitConfig
    session_id: str | None = None

    def __post_init__(self) -> None:
        if self.active_authority_seconds < 0:
            raise ValueError("Mix active authority duration must not be negative")


class MixPolicy:
    def __init__(self, config: MixPolicyConfig, authority: MixAuthorityState | None = None) -> None:
        self.config = config
        self.cc = CCMixExitPolicy(config.cc)
        self.cv = CVMixExitPolicy(config.cv)
        self.authority = authority or MixAuthorityState(session_id=config.session_id)

    def evaluate(
        self, mode: str, measurements: Measurements, *, current_limit_clipped: bool = False
    ) -> ChargeIntent:
        self._account_authority(measurements)
        if self.authority.exhausted:
            return ChargeIntent(None, None, "stopped", True, "MIX_TIMEOUT")
        if mode == "CC":
            return self.cc.evaluate(measurements, current_limit_clipped=current_limit_clipped)
        if mode == "CV":
            intent = self.cv.evaluate(measurements)
            return self._apply_cv_containment(intent, measurements)
        raise ValueError("Mix mode must be CC or CV")

    def _apply_cv_containment(self, intent: ChargeIntent, measurements: Measurements) -> ChargeIntent:
        """Cap the V3 CV Mix current intent without touching any actuator.

        The cap is anchored to confirmed Imin and therefore cannot follow a
        rising measured current.  It is eligible only after the configured
        elapsed Mix time and is refreshed on the configured cadence.  A
        refresh can only lower the already-issued domain setpoint.
        """
        containment = self.cv.state.containment
        if self.cv.state.phase in {"hold", "complete"}:
            # Delta is sticky. Keep any already-issued cap, without advancing
            # containment bookkeeping or re-expanding to the recipe target.
            if containment.fixed_limit is not None and intent.target_current is not None:
                return self._with_current(intent, containment.fixed_limit)
            return intent
        if (
            intent.completed
            or
            intent.target_current is None
            or self.authority.started_at is None
            or measurements.time is None
            or self.cv.state.observed_imin is None
        ):
            return intent
        elapsed = measurements.time - self.authority.started_at
        if elapsed < self.cv.config.containment_start_seconds:
            return intent
        last = containment.last_recalculation
        if last is not None and measurements.time - last < self.cv.config.containment_recalc_seconds:
            if containment.fixed_limit is None:
                return intent
            return self._with_current(intent, containment.fixed_limit)

        candidate = self.cv.state.observed_imin + self.cv.config.delta_current + self.cv.config.containment_headroom_a
        candidate = min(candidate, self.cv.config.target_current)
        previous = containment.fixed_limit
        setpoint = candidate if previous is None else min(previous, candidate)
        if previous is not None and setpoint < previous:
            containment.reduction_count += 1
        containment.enabled = True
        containment.activated_at = containment.activated_at or measurements.time
        containment.fixed_limit = setpoint
        containment.last_recalculation = measurements.time
        return self._with_current(intent, setpoint)

    @staticmethod
    def _with_current(intent: ChargeIntent, current: float) -> ChargeIntent:
        return ChargeIntent(
            intent.target_voltage,
            current,
            intent.next_stage,
            intent.completed,
            intent.reason,
        )

    def _account_authority(self, measurements: Measurements) -> None:
        if self.authority.started_at is None and measurements.time is not None:
            self.authority.started_at = measurements.time
            self.authority.last_timestamp = measurements.time
        elif measurements.time is not None and self.authority.last_timestamp is not None:
            self.authority.active_seconds += max(0.0, measurements.time - self.authority.last_timestamp)
            self.authority.last_timestamp = measurements.time
        if self.authority.active_seconds >= self.config.active_authority_seconds:
            self.authority.exhausted = True


@dataclass(frozen=True)
class MixTarget:
    """Canonical automatic MIX V/I target before temperature/envelope bounding."""

    voltage_v: float
    current_a: float


def select_mix_target(*, profile: str, capacity_ah: float,
                      base_voltage_v: float | None = None,
                      current_c_rate: float | None = None) -> MixTarget:
    # Import lazily: runtime.safety.__init__ imports the charge battery/strategy
    # graph, so a module-level safety import would create a package cycle.
    from runtime.safety.variables import MAX_STAGE_CURRENT_A

    if str(profile) == "AGM":
        voltage = float(AGM_MIX_VOLTAGE_V.default)
    elif str(profile) == "EFB":
        voltage = float(EFB_MIX_VOLTAGE_V.default)
    else:
        voltage = float(CA_MIX_VOLTAGE_V.default)
    if base_voltage_v is not None:
        voltage = float(base_voltage_v)
    capacity = max(1.0, float(capacity_ah))
    current = max(
        float(MIX_MIN_CURRENT_A.default),
        capacity * float(MIX_CURRENT_C_RATE.default if current_c_rate is None else current_c_rate),
    )
    current = min(current, float(MAX_STAGE_CURRENT_A.default))
    return MixTarget(voltage_v=voltage, current_a=current)


def _unsafe_policy_decision(decision: RecoveryDecision) -> bool:
    return decision in {
        RecoveryDecision.HOLD_OUTPUT_OFF,
        RecoveryDecision.PAUSE_THERMAL,
        RecoveryDecision.REST_AND_DIAGNOSE,
    }


def decide_mix_transition(
    *,
    profile: str,
    policy_decision: RecoveryDecision,
    active_elapsed_s: float,
    finish_hold_started_at: Optional[float],
    now_s: float,
    authority_limit_s: Optional[float] = None,
    finish_hold_s: Optional[float] = None,
) -> AuthorityDecision:
    """Canonical automatic MIX stage transition decision.

    The existing MixPolicy classes above remain the lower-level reusable
    CC/CV policy API. This function owns the production stage edge from active
    MIX through the sticky finish hold to final SAFE_WAIT.
    """

    if _unsafe_policy_decision(policy_decision):
        return AuthorityDecision(
            AuthorityAction.STOP_AND_DIAGNOSE,
            f"policy_{policy_decision.value}",
        )
    if finish_hold_started_at is not None:
        held = max(0.0, float(now_s) - float(finish_hold_started_at))
        required_hold = (
            mix_finish_hold_seconds()
            if finish_hold_s is None
            else max(0.0, float(finish_hold_s))
        )
        if held >= required_hold:
            return AuthorityDecision(
                AuthorityAction.COMPLETE_TO_SAFE_WAIT,
                "confirmed_delta_finish_hold_complete",
            )
        return AuthorityDecision(
            AuthorityAction.CONTINUE,
            "confirmed_delta_finish_hold_running",
        )
    if policy_decision == RecoveryDecision.FINISH_STAGE:
        return AuthorityDecision(
            AuthorityAction.START_FINISH_HOLD,
            "mode_specific_end_of_charge_evidence_confirmed",
        )
    limit = (
        mix_max_active_seconds(profile)
        if authority_limit_s is None
        else max(0.0, float(authority_limit_s))
    )
    if max(0.0, float(active_elapsed_s)) >= limit:
        return AuthorityDecision(
            AuthorityAction.STOP_AND_DIAGNOSE,
            "MIX_TIMEOUT",
        )
    return AuthorityDecision(
        AuthorityAction.CONTINUE,
        "mix_observation_continues",
    )