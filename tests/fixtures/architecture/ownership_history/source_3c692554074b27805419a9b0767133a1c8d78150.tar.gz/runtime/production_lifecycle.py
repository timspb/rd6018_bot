"""Lifecycle orchestration for the preserved V2 runtime.

This module owns only startup/shutdown sequencing and Telegram polling
coordination.  The supplied application object remains the owner of V2
controller, session, safety, persistence, and physical semantics.
"""

from __future__ import annotations

import asyncio
from typing import Any

from application.execution_port import get_or_create_execution_port
from runtime.background import start_background_tasks
from runtime.safety.watchdog_runtime import run_safety_watchdogs
from rd6018_telemetry import as_bool

SHUTDOWN_SESSION_LOCK_TIMEOUT_S = 5.0


class ProductionRuntimeLifecycle:
    """Run the existing V2 lifecycle through an explicit orchestration seam."""

    def __init__(self, app: Any, telegram_runtime: Any) -> None:
        self.app = app
        self.telegram_runtime = telegram_runtime
        self._background_tasks: tuple[asyncio.Task[object], ...] = ()

    async def _periodic_db_cleanup(self) -> None:
        while True:
            await asyncio.sleep(24 * 3600)
            try:
                from database import cleanup_old_records

                await cleanup_old_records()
            except Exception as ex:
                self.app.logger.error("Periodic DB cleanup failed: %s", ex)

    async def on_shutdown(self, dispatcher: Any) -> None:
        """Preserve the V2 shutdown order without owning domain semantics."""
        app = self.app
        app.logger.info("Shutting down gracefully...")
        for task in self._background_tasks:
            task.cancel()
        if self._background_tasks:
            done, pending = await asyncio.wait(self._background_tasks, timeout=5.0)
            for task in done:
                if not task.cancelled():
                    try:
                        task.result()
                    except Exception as ex:
                        app.logger.warning("Background task shutdown: %s", ex)
            if pending:
                app.logger.warning("Background tasks did not stop: %s",
                                   [task.get_coro().__qualname__ for task in pending])
        # Idle shutdown has no session mutation to serialize. Waiting for a
        # wedged START/STOP owner here previously hung systemd stop until SIGKILL.
        if app.charge_controller.is_active:
            try:
                async with asyncio.timeout(SHUTDOWN_SESSION_LOCK_TIMEOUT_S):
                    async with get_or_create_execution_port(app)._guard_owner_lock:
                        app.charge_controller._save_session(0.0, 0.0, 0.0)
            except TimeoutError:
                # Preserve the last durable session; never write outside the
                # owner lock or authorize an automatic output restart.
                app.logger.warning("Shutdown session save skipped: execution owner busy")
            except Exception as ex:
                app.logger.warning("Failed to save session on shutdown: %s", ex)
        app.logger.info("Closing physical connector on shutdown")
        try:
            async with asyncio.timeout(10.0):
                await app.hass.close()
        except Exception as ex:
            app.logger.warning("Physical connector shutdown incomplete: %s", type(ex).__name__)
        app.logger.info("Closing database on shutdown")
        try:
            from database import close_db
            async with asyncio.timeout(10.0):
                await close_db()
        except Exception as ex:
            app.logger.warning("Database shutdown incomplete: %s", type(ex).__name__)
        app.logger.info("Shutdown complete.")

    async def run(self) -> None:
        app = self.app
        execution_port = get_or_create_execution_port(app)
        await app.init_db()
        app.rotate_if_needed()
        self._background_tasks = start_background_tasks(self._periodic_db_cleanup)
        try:
            n = app.trim_log_older_than_days(30)
            if n > 0:
                app.logger.info("Trimmed %d old lines from charging_history.log", n)
        except Exception as ex:
            app.logger.warning("trim_log_older_than_days at startup: %s", ex)

        app._load_manual_off_state()
        app._load_operator_pause_state()

        # Preserve the existing V2 restore probe.  Production wraps this call in
        # the startup authority reconciliation before any automatic continuation.
        # Serialize startup journal/controller restore and subsequent physical
        # setpoints under the same owner as runtime tick and START.
        async with execution_port._guard_owner_lock:
            if not execution_port.session_recovery_guard.may_run_automatic_control():
                app.logger.error("Startup session restore blocked by durable recovery quarantine: %s",
                                 execution_port.session_recovery_guard.state.reason)
            else:
                try:
                    live = await app.hass.get_all_live()
                    battery_v = app._safe_float(live.get("battery_voltage"))
                    current = app._safe_float(live.get("current"))
                    ah = app._safe_float(live.get("ah"))
                    ovp_triggered = as_bool(live.get("ovp_triggered")) is True
                    ocp_triggered = as_bool(live.get("ocp_triggered")) is True
                    input_voltage = app._safe_float(live.get("input_voltage"), 0.0)
                    controller = app.charge_controller
                    ok, msg = controller.try_restore_session(
                        battery_v,
                        current,
                        ah,
                        output_is_on=(str(live.get("switch", "")).lower() == "on"),
                        is_cv=as_bool(live.get("is_cv")) is True,
                        is_cc=as_bool(live.get("is_cc")) is True,
                    )
                    if ok and msg:
                        app._apply_restore_time_corrections(controller, live)
                        app.last_checkpoint_time = app.time.time()
                        temp_ext = app._safe_float(live.get("temp_ext"))
                        allow_turn_on = (
                            app._restore_allows_auto_enable(controller)
                            and not ovp_triggered
                            and not ocp_triggered
                            and input_voltage >= app.MIN_INPUT_VOLTAGE
                        )
                        if app._operator_pause_active():
                            app.logger.info("Auto-resume skipped: operator pause is active")
                        elif allow_turn_on:
                            if controller.current_stage == controller.STAGE_SAFE_WAIT:
                                uv, ui = controller._safe_wait_target_v, controller._safe_wait_target_i
                                await app._apply_phase_protection(uv, ui)
                                await execution_port.program_voltage(uv)
                                await execution_port.program_current(app._cap_current(ui))
                                await execution_port.request_verified_off()
                            else:
                                uv, ui = controller._get_target_v_i(temp_ext)
                                await app._apply_phase_protection(uv, ui)
                                await execution_port.program_voltage(uv)
                                await execution_port.program_current(app._cap_current(ui))
                                await execution_port.request_verified_on()
                            app.log_event(controller.current_stage, battery_v, current, temp_ext, ah, "RESTORE")
                            app._charge_notify(msg)
                            app.logger.info("Session restored: %s", controller.current_stage)
                        else:
                            app.logger.info(
                                "Auto-resume skipped: ovp=%s ocp=%s input_v=%.0f",
                                ovp_triggered,
                                ocp_triggered,
                                input_voltage,
                            )
                except Exception as ex:
                    app.logger.warning("Auto-resume check failed: %s", ex)

        app.dp.include_router(app.router)
        await app.configure_commands(self.telegram_runtime)
        self._background_tasks += start_background_tasks(
            app.data_logger,
            app.charge_monitor,
            lambda: run_safety_watchdogs(app),
        )
        app.logger.info("RD6018 bot starting")
        app.logger.info(
            "Если появится TelegramConflictError — запущен ещё один экземпляр бота. "
            "Остановите все кроме одного: pgrep -af 'bot.py' && kill <PID>"
        )
        try:
            await app.run_polling(self.telegram_runtime, shutdown_handler=self.on_shutdown)
        finally:
            await app.hass.close()
            app.logger.info("RD6018 bot stopped")
