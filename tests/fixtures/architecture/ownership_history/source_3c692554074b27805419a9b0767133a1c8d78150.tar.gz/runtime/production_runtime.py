"""
bot.py — RD6018 Ultimate Telegram Controller (Async Edition).
Дашборд: один автообновляемый message с графиком, метриками и кнопками.
"""
import asyncio
import inspect
import json
import logging
import math
import os
import re
import sys
import time

import aiohttp
from datetime import datetime, timedelta
from typing import Dict, Optional, Union, Any

from aiogram import Dispatcher, F
from aiogram.enums import ParseMode
from aiogram.types import (
    BufferedInputFile,
    CallbackQuery,
    InputMediaPhoto,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)
from aiogram.filters import Command
from telegram.runtime import configure_commands, create_telegram_runtime, run_polling
from runtime.production_lifecycle import ProductionRuntimeLifecycle
from runtime.ui.telegram.analysis import ANALYSIS_CALLBACK_DATA
from runtime.ui.telegram.charge import CHARGE_CALLBACK_DATA
from runtime.ui.telegram.custom import CUSTOM_CANCEL_CALLBACK_DATA
from runtime.ui.telegram.details import DETAILS_CALLBACK_DATA, HOME_CALLBACK_DATA
from runtime.ui.telegram.journal import JOURNAL_CALLBACK_DATA
from runtime.ui.telegram.off_conditions import OFF_CALLBACK_DATA
from operator_managed_stop import STOP_CONFIRM_CALLBACK

from ai_engine import ask_deepseek, format_ai_snapshot, format_recent_events
from ai_system_prompt import AI_CONSULTANT_SYSTEM_PROMPT
from runtime.charge.strategy.exit_variables import (
    MIX_CC_DELTA_V_EXIT_V,
    MIX_CV_DELTA_I_EXIT_A,
)
from runtime.charge.persistence import (
    paused_done_resume_is_authorized,
    restore_allows_auto_enable,
)
from runtime.charge.link_session_recovery import (
    RecoveryAction,
    RecoveryAuthorizationInput,
    RecoveryRoute,
    RecoveryRouteInput,
    authorize_recovery_action,
    choose_recovery_route,
)
from runtime.charge.strategy.main_guard_shadow import MainGuardShadow
from application.main_guard_runtime import execute_due_main_guard
from application.charge_session_tick import run_charge_session_tick
from runtime.charge.strategy.main_guard_admission import (
    admit_main_guard_shadow, read_canonical_session,
)
from runtime.charge.persistence import SESSION_FILE
from runtime.safety.variables import (
    HIGH_V_FAST_TIMEOUT_S,
    HIGH_V_THRESHOLD_V,
    MAX_STAGE_CURRENT_A,
    PROTECTION_OCP_MARGIN_A,
    PROTECTION_OVP_MARGIN_V,
    WATCHDOG_TIMEOUT_S,
)
from runtime.safety.live_protection import evaluate_live_protection
from charging_log import clear_event_logs, get_recent_events, log_checkpoint, log_event, log_stage_end, rotate_if_needed, trim_log_older_than_days
from production_controller import create_production_charge_host
from config import (
    ALLOWED_CHAT_IDS,
    NOTIFY_CHAT_ID,
    DEEPSEEK_API_KEY,
    DEEPSEEK_BASE_URL,
    ENTITY_MAP,
    MIN_INPUT_VOLTAGE,
    TEMP_INT_PRECRITICAL,
    TG_TOKEN,
)
from application.execution_port import get_or_create_execution_port
from application.controller_action_execution import execute_controller_action_batch
from application.session_recovery_service import SessionRecoveryService
from runtime.safety.voltage_variables import PB_AUTOMATIC_TARGET_CEILING_V
from database import add_record, cleanup_old_records, get_graph_data_with_temp, get_logs_data, get_raw_history, init_db
from hass_api import HassClient
from rd6018_telemetry import as_bool, telemetry_freshness, finite_float
from runtime.charge.evidence.temperature_source_journal import TemperatureSourceJournalObserver
from runtime.charge.evidence.mix_progress_journal import mix_progress_event
from time_utils import format_time_user_tz
import html
from application.intents import OperatorIntent, OperatorIntentKind
from pb_domain import BatteryCondition, ChargeIntent
from manual_mode import ManualUIIntent

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s: %(name)s - %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("rd6018")
# Keep third-party libraries at INFO; capture detailed RD6018 diagnostics only.
logger.setLevel(logging.DEBUG)

# Production chemistry never grants or denies authority from PSU input voltage.
# Vin remains telemetry/health context only.  Keep the historical symbol because
# the runtime still contains compatibility-shaped comparisons, but make those
# comparisons statically inert instead of mutating the module at composition time.
MIN_INPUT_VOLTAGE = float("-inf")
_v2_vin_psu_health_only = True

# Stable module-level compatibility values; semantic ownership lives in V3 VariableSpec modules.
DELTA_I_EXIT = float(MIX_CV_DELTA_I_EXIT_A.default)
DELTA_V_EXIT = float(MIX_CC_DELTA_V_EXIT_V.default)
HIGH_V_FAST_TIMEOUT = float(HIGH_V_FAST_TIMEOUT_S.default)
HIGH_V_THRESHOLD = float(HIGH_V_THRESHOLD_V.default)
MAX_STAGE_CURRENT = float(MAX_STAGE_CURRENT_A.default)
WATCHDOG_TIMEOUT = float(WATCHDOG_TIMEOUT_S.default)
OVP_OFFSET = float(PROTECTION_OVP_MARGIN_V.default)
OCP_OFFSET = float(PROTECTION_OCP_MARGIN_A.default)


def _canonical_bool(live: Dict[str, Any], key: str) -> bool:
    """Consume a canonical telemetry boolean without string reinterpretation."""
    return as_bool(live.get(key)) is True


def _is_physical_transport_error(exc: BaseException) -> bool:
    """Identify an edge-link failure without classifying safety faults as network loss."""
    # A bare TimeoutError is ambiguous: it can be a local safety verification
    # timeout rather than an ESPHome transport failure. Only transport-specific
    # exception classes are classified here.
    if isinstance(exc, (ConnectionError, aiohttp.ClientError)):
        return True
    text = str(exc).lower()
    return any(
        marker in text
        for marker in (
            "not connected to rd6018-controller",
            "connection refused",
            "connection reset",
            "connection closed",
            "cannot connect",
            "clientconnector",
            "connection timeout",
            "request timeout",
            "transport outage",
        )
    )


def _is_recoverable_link_boundary_error(exc: BaseException) -> bool:
    """Preserve an active session when an accepted edge command loses readback."""
    text = str(exc).lower()
    return _is_physical_transport_error(exc) or (
        "off command accepted" in text
        and "switch state was not confirmed" in text
    )


def generate_chart(*args: Any, **kwargs: Any) -> Any:
    """Load the charting stack only when a chart is actually requested."""
    from graphing import generate_chart as _generate_chart

    return _generate_chart(*args, **kwargs)


class _DeferredHassClient:
    """A non-connecting handle used while the application module is imported.

    The production client is bound explicitly by ``initialize_runtime``.  Keeping
    this small handle preserves the existing composed V2 module surface without
    constructing a connector, loading physical configuration, or touching the
    network during import.
    """

    _VALUE_ATTRIBUTES = frozenset(
        {
            "base_url",
            "token",
            "_disable_tls_verify",
            "_session",
            "_physical_backend",
        }
    )

    def __init__(self) -> None:
        object.__setattr__(self, "_client", None)
        object.__setattr__(self, "_initializer", None)

    @property
    def is_bound(self) -> bool:
        return object.__getattribute__(self, "_client") is not None

    def bind(self, client: HassClient) -> None:
        if self.is_bound and object.__getattribute__(self, "_client") is not client:
            raise RuntimeError("HassClient is already bound to another runtime client")
        object.__setattr__(self, "_client", client)
        # ProductionComposition installs the managed guard before startup binds
        # this deferred handle. Rebind it to the live adapter so the internal
        # SafeOutputCoordinator path also crosses the guarded turn_on boundary.
        guard = object.__getattribute__(self, "__dict__").get("_runtime_safety_guard")
        bind_adapter = getattr(guard, "bind_adapter", None)
        if callable(bind_adapter):
            bind_adapter(client)
            bridge = getattr(guard, "_install_last_reported_metadata_bridge", None)
            if callable(bridge):
                bridge()

    def set_initializer(self, initializer: Any) -> None:
        object.__setattr__(self, "_initializer", initializer)

    def _ensure_bound(self) -> HassClient:
        client = object.__getattribute__(self, "_client")
        if client is None:
            initializer = object.__getattribute__(self, "_initializer")
            if callable(initializer):
                initializer()
                client = object.__getattribute__(self, "_client")
        if client is None:
            raise RuntimeError("HassClient runtime is not initialized")
        return client

    def __getattr__(self, name: str) -> Any:
        client = object.__getattribute__(self, "_client")
        if client is not None:
            return getattr(client, name)
        if name in self._VALUE_ATTRIBUTES:
            return None
        # Private composition markers are intentionally local to this deferred
        # handle.  They must not turn an import into a runtime initialization.
        if name.startswith("_"):
            return None

        async def deferred_call(*args: Any, **kwargs: Any) -> Any:
            bound = self._ensure_bound()
            result = getattr(bound, name)(*args, **kwargs)
            return await result if inspect.isawaitable(result) else result

        return deferred_call



if not TG_TOKEN:
    raise ValueError(
        "TG_TOKEN не задан. Укажите TG_TOKEN или TELEGRAM_BOT_TOKEN в .env"
    )

_telegram_runtime = create_telegram_runtime(TG_TOKEN)
bot = _telegram_runtime.bot
dp = _telegram_runtime.dispatcher
router = _telegram_runtime.router

hass = _DeferredHassClient()

# Executor для блокирующих операций (DeepSeek API)
def _charge_notify(msg: str, critical: bool = True) -> None:
    """Отправка уведомления в Telegram. critical=True — после него дашборд только по кнопке ОБНОВИТЬ; critical=False — сразу шлём дашборд последним сообщением."""
    global last_chat_id, last_notification_signature, last_notification_at
    if NOTIFY_CHAT_ID is not None:
        last_chat_id = NOTIFY_CHAT_ID
    elif last_chat_id is None and len(ALLOWED_CHAT_IDS) == 1 and ALLOWED_CHAT_IDS[0] > 0:
        last_chat_id = ALLOWED_CHAT_IDS[0]
    if last_chat_id and msg:
        enriched = msg
        if last_live_context and "📊 Факт:" not in msg:
            enriched = f"{msg}\n\n{last_live_context}"
        signature = msg.strip()
        now = time.time()
        if signature == last_notification_signature and now - last_notification_at < 5:
            return
        last_notification_signature = signature
        last_notification_at = now
        asyncio.create_task(_send_notify_safe(enriched, critical))


async def _send_notify_safe(msg: str, critical: bool = True) -> None:
    global last_chat_id, last_user_id
    try:
        safe_msg = msg
        if not any(tag in msg for tag in ['<b>', '<i>', '<code>']):
            safe_msg = html.escape(msg)
        safe_msg = safe_msg.replace('<hr>', '___________________').replace('<hr/>', '___________________').replace('<hr />', '___________________')
        safe_msg = safe_msg.replace('<br>', '\n').replace('<br/>', '\n').replace('<br />', '\n')
        await bot.send_message(last_chat_id, safe_msg, parse_mode=ParseMode.HTML)
        # The already installed PanelLast notification owner decides whether
        # and when to restore the one panel. Never publish a legacy text panel
        # from the notification transport.
    except Exception as ex:
        logger.error("charge notify failed: %s", ex)
        try:
            clean_msg = html.escape(msg).replace('<hr>', '---').replace('<hr/>', '---').replace('<hr />', '---')
            await bot.send_message(last_chat_id, clean_msg)
        except Exception as ex2:
            logger.error("fallback notify also failed: %s", ex2)


async def call_llm_analytics(data: dict) -> Optional[str]:
    """Запрос к DeepSeek для анализа телеметрии. Возвращает комментарий или None."""
    if not DEEPSEEK_API_KEY:
        return None
    data_str = json.dumps(data, ensure_ascii=False, indent=2)
    system_prompt = (
        "Ты — эксперт по свинцово-кислотным аккумуляторам. "
        "Анализируй телеметрию и давай краткий технический вердикт."
    )
    user_prompt = (
        f"Данные: {data_str}\n\n"
        "Оцени состояние АКБ, укажи на аномалии и дай прогноз окончания этапа одним предложением. "
        "Ответь на русском. Используй HTML: <b>жирный</b>, <i>курсив</i>."
    )
    url = f"{DEEPSEEK_BASE_URL.rstrip('/')}/v1/chat/completions"
    payload = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "max_tokens": 256,
        "temperature": 0.3,
    }
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                url,
                json=payload,
                headers={
                    "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
                    "Content-Type": "application/json",
                },
                timeout=aiohttp.ClientTimeout(total=15),
            ) as resp:
                if resp.status != 200:
                    logger.warning("DeepSeek analytics API %d", resp.status)
                    return None
                result = await resp.json()
                choices = result.get("choices", [])
                if not choices:
                    return None
                content = choices[0].get("message", {}).get("content", "").strip()
                return content if content else None
    except Exception as ex:
        logger.warning("call_llm_analytics: %s", ex)
        return None


charge_controller = create_production_charge_host(hass, notify_cb=_charge_notify)
_main_guard_shadow = MainGuardShadow()


def initialize_runtime() -> None:
    """Bind the physical client at application startup, never at import time."""
    if hass.is_bound:
        return
    hass.bind(HassClient.from_physical_config())


hass.set_initializer(initialize_runtime)


def _restore_allows_auto_enable(controller: Any) -> bool:
    """Apply canonical persisted Done/Storage auto-enable authority."""
    return restore_allows_auto_enable(controller)


def _is_chat_allowed(chat_id: int) -> bool:
    """Проверка доступа по ALLOWED_CHAT_IDS. Пустой список = доступ у всех."""
    if not ALLOWED_CHAT_IDS:
        return True
    return chat_id in ALLOWED_CHAT_IDS


async def _check_chat_and_respond(event: Union[Message, CallbackQuery]) -> bool:
    """
    Вернуть True, если чат разрешён. Иначе отправить «Доступ запрещён» и вернуть False.
    Вызывать в начале обработчиков.
    """
    chat_id = event.chat.id if isinstance(event, Message) else event.message.chat.id
    if _is_chat_allowed(chat_id):
        return True
    try:
        if isinstance(event, Message):
            await event.answer("Доступ запрещён.")
        else:
            await event.answer("Доступ запрещён.", show_alert=True)
    except Exception:
        pass
    return False


user_dashboard: Dict[int, int] = {}
chat_dashboard: Dict[int, int] = {}
user_chart_range: Dict[int, str] = {}
_action_debounce_until: Dict[str, float] = {}
last_chat_id: Optional[int] = None
last_user_id: Optional[int] = None
last_live_context: str = ""
last_notification_signature: str = ""
last_notification_at: float = 0.0
last_charge_alert_at: Optional[datetime] = None
last_idle_alert_at: Optional[datetime] = None
zero_current_since: Optional[datetime] = None
CHARGE_ALERT_COOLDOWN = timedelta(hours=1)
# В режиме хранения (V < 14В) алерт «заряд завершён» не чаще раза в час
STORAGE_ALERT_COOLDOWN = timedelta(hours=1)
IDLE_ALERT_COOLDOWN = timedelta(hours=1)
ZERO_CURRENT_THRESHOLD_MINUTES = 30
awaiting_ah: Dict[int, str] = {}
# FSM для ручного режима
custom_mode_state: Dict[int, str] = {}  # состояние диалога: "voltage", "current", "delta", "time_limit", "capacity"
custom_mode_data: Dict[int, Dict[str, float]] = {}  # накопленные данные пользователя
custom_mode_confirm: Dict[int, Dict[str, Any]] = {}  # данные для подтверждения опасных значений
last_ha_ok_time: float = 0.0
link_lost_alert_sent: bool = False  # флаг-блокировка однократного уведомления о потере связи
link_failure_streak: int = 0
LINK_FAILURE_NOTIFY_THRESHOLD = 3
soft_watchdog_outage_reported: bool = False
# Last-good telemetry can precede a detected disconnect by one 30s poll.
# Allow the full 300s loss window plus that observation margin; the
# independent 900s edge safety lease retains physical authority.
SOFT_WATCHDOG_TIMEOUT = 6 * 60
MIN_START_TEMP = 10.0  # °C — заряд не начинаем, если внешний датчик ниже
last_checkpoint_time: float = 0.0
_event_log_last_at: Dict[str, float] = {}

# Команда off: выключить по напряжению / току / таймеру (игнорируя режим, защита остаётся)
manual_off_voltage: Optional[float] = None    # выкл когда V >=
manual_off_voltage_le: Optional[float] = None  # выкл когда V <= (напр. спад в миксе)
manual_off_current: Optional[float] = None     # выкл когда I <=
manual_off_current_ge: Optional[float] = None  # выкл когда I >= (напр. рост от 1 А к 2 А)
manual_off_time_sec: Optional[float] = None
manual_off_start_time: float = 0.0

MANUAL_OFF_FILE = "manual_off_state.json"
OPERATOR_PAUSE_FILE = "operator_pause_state.json"
operator_pause_started_at: Optional[float] = None

CHART_RANGE_30M = "30m"
CHART_RANGE_2H = "2h"
CHART_RANGE_SESSION = "session"
CHART_RANGE_DEFAULT = CHART_RANGE_2H
CHART_RANGE_VALUES = {CHART_RANGE_30M, CHART_RANGE_2H, CHART_RANGE_SESSION}


def _operator_pause_active() -> bool:
    return operator_pause_started_at is not None


def _save_operator_pause_state() -> None:
    if operator_pause_started_at is None:
        try:
            if os.path.exists(OPERATOR_PAUSE_FILE):
                os.remove(OPERATOR_PAUSE_FILE)
        except OSError:
            pass
        return
    try:
        with open(OPERATOR_PAUSE_FILE, "w", encoding="utf-8") as f:
            json.dump({"started_at": operator_pause_started_at}, f)
    except OSError as ex:
        logger.warning("Could not save operator pause state: %s", ex)


def _load_operator_pause_state() -> None:
    global operator_pause_started_at
    if not os.path.exists(OPERATOR_PAUSE_FILE):
        return
    try:
        with open(OPERATOR_PAUSE_FILE, "r", encoding="utf-8") as f:
            raw = json.load(f)
        started_at = float(raw.get("started_at"))
        if started_at > 0:
            operator_pause_started_at = started_at
            logger.info("Operator pause restored from %s", OPERATOR_PAUSE_FILE)
    except (OSError, TypeError, ValueError, json.JSONDecodeError):
        logger.warning("Ignoring invalid operator pause state")


def _clear_operator_pause() -> None:
    global operator_pause_started_at
    operator_pause_started_at = None
    _save_operator_pause_state()


def _shift_operator_pause_clocks(pause_seconds: float) -> None:
    """Freeze controller deadlines and evidence clocks during an operator pause."""
    if pause_seconds <= 0:
        return
    for name in (
        "stage_start_time",
        "total_start_time",
        "finish_timer_start",
        "_first_stage_hold_since",
        "_stuck_current_since",
        "_safe_wait_start",
        "_blanking_until",
        "_delta_monitor_after",
        "_cv_since",
        "_v2_trace_started_at",
    ):
        value = getattr(charge_controller, name, None)
        if isinstance(value, (int, float)) and value > 0:
            setattr(charge_controller, name, float(value) + pause_seconds)
    main_sample_evidence = getattr(charge_controller, "_main_sample_evidence", None)
    if main_sample_evidence is not None:
        main_sample_evidence.shift_clock(pause_seconds)


def _save_manual_off_state() -> None:
    """Сохранить условие «off» в файл (переживёт перезапуск бота)."""
    if not _has_manual_off_condition():
        try:
            if os.path.exists(MANUAL_OFF_FILE):
                os.remove(MANUAL_OFF_FILE)
        except OSError:
            pass
        return
    data = {
        "voltage_ge": manual_off_voltage,
        "voltage_le": manual_off_voltage_le,
        "current_le": manual_off_current,
        "current_ge": manual_off_current_ge,
        "time_sec": manual_off_time_sec,
        "start_time": manual_off_start_time,
    }
    try:
        with open(MANUAL_OFF_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
    except OSError as ex:
        logger.warning("Could not save manual_off state: %s", ex)


def _load_manual_off_state() -> None:
    """Восстановить условие «off» из файла после перезапуска бота."""
    global manual_off_voltage, manual_off_voltage_le, manual_off_current, manual_off_current_ge, manual_off_time_sec, manual_off_start_time
    if not os.path.exists(MANUAL_OFF_FILE):
        return
    try:
        with open(MANUAL_OFF_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError):
        return
    v_ge = data.get("voltage_ge")
    v_le = data.get("voltage_le")
    i_le = data.get("current_le")
    i_ge = data.get("current_ge")
    t_sec = data.get("time_sec")
    start = data.get("start_time")
    if v_ge is None and v_le is None and i_le is None and i_ge is None and t_sec is None:
        return
    manual_off_voltage = float(v_ge) if v_ge is not None else None
    manual_off_voltage_le = float(v_le) if v_le is not None else None
    manual_off_current = float(i_le) if i_le is not None else None
    manual_off_current_ge = float(i_ge) if i_ge is not None else None
    manual_off_time_sec = float(t_sec) if t_sec is not None else None
    try:
        manual_off_start_time = float(start) if start is not None else 0.0
    except (TypeError, ValueError):
        manual_off_start_time = 0.0
    logger.info("Manual off condition restored from %s", MANUAL_OFF_FILE)


def _parse_off_command(text: str) -> Optional[Dict[str, Any]]:
    """
    Парсит команду off с явными условиями:
    V>=16.4 / V<=13.2 — по напряжению (достигнет ≥ или снизится до ≤);
    I<=1.23 / I>=2 — по току (достигнет ≤ или достигнет ≥);
    2:23 — таймер.
    Без префикса: число 12–18 В → V>=, 0.1–12 А → I<= (как раньше).
    """
    t = (text or "").strip().replace(",", ".")
    if not t.lower().startswith("off "):
        return None
    rest = t[4:].strip().replace("\u2265", ">=").replace("\u2264", "<=")  # ≥ ≤
    if not rest:
        return None
    tokens = rest.lower().split()
    voltage_ge: Optional[float] = None
    voltage_le: Optional[float] = None
    current_le: Optional[float] = None
    current_ge: Optional[float] = None
    time_sec: Optional[float] = None
    parts: list = []

    for tok in tokens:
        if ":" in tok:
            try:
                comp = tok.split(":")
                if len(comp) == 2:
                    h, m = int(comp[0].strip()), int(comp[1].strip())
                    sec = h * 3600 + m * 60
                elif len(comp) == 3:
                    h, m, s = int(comp[0].strip()), int(comp[1].strip()), int(comp[2].strip())
                    sec = h * 3600 + m * 60 + s
                else:
                    continue
                if sec <= 0:
                    continue
                time_sec = (time_sec or 0) + sec
                parts.append(f"таймер {tok}")
            except (ValueError, IndexError):
                continue
        elif tok.startswith("v>="):
            try:
                voltage_ge = float(tok[3:].strip())
                if 0 <= voltage_ge <= 20:
                    parts.append(f"V≥{voltage_ge:.1f} В")
            except ValueError:
                continue
        elif tok.startswith("v<="):
            try:
                voltage_le = float(tok[3:].strip())
                if 0 <= voltage_le <= 20:
                    parts.append(f"V≤{voltage_le:.1f} В")
            except ValueError:
                continue
        elif tok.startswith("i>="):
            try:
                current_ge = float(tok[3:].strip())
                if 0 < current_ge <= MAX_STAGE_CURRENT:
                    parts.append(f"I≥{current_ge:.2f} А")
            except ValueError:
                continue
        elif tok.startswith("i<="):
            try:
                current_le = float(tok[3:].strip())
                if 0 < current_le <= MAX_STAGE_CURRENT:
                    parts.append(f"I≤{current_le:.2f} А")
            except ValueError:
                continue
        else:
            try:
                val = float(tok)
                if 12.0 <= val <= 18.0:
                    voltage_ge = val
                    parts.append(f"{val:.1f} В (V≥)")
                elif 0.1 <= val <= MAX_STAGE_CURRENT:
                    current_le = val
                    parts.append(f"{val:.2f} А (I≤)")
                else:
                    continue
            except ValueError:
                continue

    if voltage_ge is None and voltage_le is None and current_le is None and current_ge is None and time_sec is None:
        return None
    return {
        "voltage_ge": voltage_ge,
        "voltage_le": voltage_le,
        "current_le": current_le,
        "current_ge": current_ge,
        "time_sec": time_sec,
        "start_time": time.time(),
        "parts": parts,
    }


def _clear_manual_off() -> None:
    global manual_off_voltage, manual_off_voltage_le, manual_off_current, manual_off_current_ge, manual_off_time_sec, manual_off_start_time
    manual_off_voltage = None
    manual_off_voltage_le = None
    manual_off_current = None
    manual_off_current_ge = None
    manual_off_time_sec = None
    manual_off_start_time = 0.0
    _save_manual_off_state()


def _has_manual_off_condition() -> bool:
    return (
        manual_off_voltage is not None or manual_off_voltage_le is not None
        or manual_off_current is not None or manual_off_current_ge is not None
        or manual_off_time_sec is not None
    )


def _format_manual_off_for_dashboard() -> str:
    """Строка для дашборда: статус принудительного выключения и остаток времени до выкл."""
    global manual_off_voltage, manual_off_voltage_le, manual_off_current, manual_off_current_ge, manual_off_time_sec, manual_off_start_time
    if not _has_manual_off_condition():
        return ""
    parts = []
    # «Достигли» V: оба порога равны
    if (
        manual_off_voltage is not None
        and manual_off_voltage_le is not None
        and abs(manual_off_voltage - manual_off_voltage_le) < 0.01
    ):
        parts.append(f"при достижении V {manual_off_voltage:.2f} В")
    else:
        if manual_off_voltage is not None:
            parts.append(f"при V≥{manual_off_voltage:.1f} В")
        if manual_off_voltage_le is not None:
            parts.append(f"при V≤{manual_off_voltage_le:.1f} В")
    # «Достигли» I: оба порога равны
    if (
        manual_off_current is not None
        and manual_off_current_ge is not None
        and abs(manual_off_current - manual_off_current_ge) < 0.01
    ):
        parts.append(f"при достижении I {manual_off_current:.2f} А")
    else:
        if manual_off_current is not None:
            parts.append(f"при I≤{manual_off_current:.2f} А")
        if manual_off_current_ge is not None:
            parts.append(f"при I≥{manual_off_current_ge:.2f} А")
    remaining_sec = 0.0
    if manual_off_time_sec is not None:
        remaining_sec = manual_off_start_time + manual_off_time_sec - time.time()
        if remaining_sec <= 0:
            parts.append("таймер истёк")
        else:
            h = int(manual_off_time_sec // 3600)
            m = int((manual_off_time_sec % 3600) // 60)
            parts.append(f"таймер {h}:{m:02d}")
    line = "⏹ ВЫКЛ ПО УСЛОВИЮ: " + ", ".join(parts)
    if manual_off_time_sec is not None and remaining_sec > 0:
        h = int(remaining_sec // 3600)
        m = int((remaining_sec % 3600) // 60)
        line += f" | осталось до выкл: {h}:{m:02d}"
    return line


def _stage_label(raw_stage: str, short: bool = True) -> str:
    """Единый словарь названий этапов для краткого и полного интерфейса."""
    stage = (raw_stage or "").strip()
    mapping_short = {
        "Main Charge": "Основной",
        "Mix Mode": "MIX",
        "Десульфатация": "Десульф",
        "Безопасное ожидание": "Ожидание",
        "Остывание": "Остывание",
        "Idle": "Ожидание",
    }
    mapping_full = {
        "Main Charge": "Основной заряд",
        "Mix Mode": "Микс-режим",
        "Десульфатация": "Десульфатация",
        "Безопасное ожидание": "Безопасное ожидание",
        "Остывание": "Остывание",
        "Idle": "Ожидание",
    }
    mapping = mapping_short if short else mapping_full
    return mapping.get(stage, stage)


def _is_action_allowed(user_id: int, action: str, cooldown_sec: float = 1.2) -> bool:
    """Простой debounce для кнопок с риском двойного нажатия."""
    key = f"{user_id}:{action}"
    now = time.time()
    until = _action_debounce_until.get(key, 0.0)
    if now < until:
        return False
    _action_debounce_until[key] = now + cooldown_sec
    return True


def _chart_range_for_user(user_id: int) -> str:
    manual_mode = user_chart_range.get(user_id)
    if manual_mode in CHART_RANGE_VALUES:
        return manual_mode

    # Автоподбор по длительности активной сессии:
    # <2ч -> 30м, 2-8ч -> 2ч, >8ч -> сессия.
    if charge_controller.is_active and getattr(charge_controller, "total_start_time", 0):
        elapsed_sec = max(0.0, time.time() - float(charge_controller.total_start_time))
        if elapsed_sec < 2 * 3600:
            return CHART_RANGE_30M
        if elapsed_sec <= 8 * 3600:
            return CHART_RANGE_2H
        return CHART_RANGE_SESSION

    return CHART_RANGE_DEFAULT


def _chart_label(mode: str) -> str:
    labels = {
        CHART_RANGE_30M: "30м",
        CHART_RANGE_2H: "2ч",
        CHART_RANGE_SESSION: "Сессия",
    }
    return labels.get(mode, "2ч")


def _chart_query_params(user_id: int) -> tuple:
    mode = _chart_range_for_user(user_id)
    now = time.time()
    if mode == CHART_RANGE_30M:
        return mode, now - 30 * 60, 120
    if mode == CHART_RANGE_SESSION and charge_controller.is_active and getattr(charge_controller, "total_start_time", None):
        return mode, charge_controller.total_start_time, 500
    if mode == CHART_RANGE_SESSION:
        mode = CHART_RANGE_2H
    return mode, now - 2 * 3600, 300


def _build_dashboard_keyboard(is_on: bool, user_id: int, *, back_to_dashboard: bool = False) -> InlineKeyboardMarkup:
    main_btn_text = "🛑 СТОП" if is_on else "🚀 СТАРТ"
    chart_mode = _chart_range_for_user(user_id)
    chart_buttons = [
        InlineKeyboardButton(
            text=("● " if chart_mode == CHART_RANGE_30M else "") + "30м",
            callback_data=f"operator_graph_{CHART_RANGE_30M}",
        ),
        InlineKeyboardButton(
            text=("● " if chart_mode == CHART_RANGE_2H else "") + "2ч",
            callback_data=f"operator_graph_{CHART_RANGE_2H}",
        ),
        InlineKeyboardButton(
            text=("● " if chart_mode == CHART_RANGE_SESSION else "") + "Сессия",
            callback_data=f"operator_graph_{CHART_RANGE_SESSION}",
        ),
    ]
    rows = [
        chart_buttons,
        [
            InlineKeyboardButton(text="📝 Логи", callback_data=JOURNAL_CALLBACK_DATA),
            InlineKeyboardButton(text="📋 Полная инфо", callback_data=DETAILS_CALLBACK_DATA),
        ],
        [
            InlineKeyboardButton(text="🔄 Обновить", callback_data="operator_refresh"),
            InlineKeyboardButton(text="🧠 AI анализ", callback_data=ANALYSIS_CALLBACK_DATA),
        ],
        [
            InlineKeyboardButton(
                text=main_btn_text,
                callback_data=STOP_CONFIRM_CALLBACK if is_on else CHARGE_CALLBACK_DATA,
            ),
            InlineKeyboardButton(text="⚙️ Режимы", callback_data=CHARGE_CALLBACK_DATA),
        ],
    ]
    if back_to_dashboard:
        rows.append([InlineKeyboardButton(text="⬅️ К дашборду", callback_data=HOME_CALLBACK_DATA)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _apply_manual_off_preset(preset: str) -> str:
    """Apply one named operator OFF-condition preset without Telegram concerns."""

    global manual_off_voltage, manual_off_voltage_le
    global manual_off_current, manual_off_current_ge
    global manual_off_time_sec, manual_off_start_time

    manual_off_voltage = None
    manual_off_voltage_le = None
    manual_off_current = None
    manual_off_current_ge = None
    manual_off_time_sec = None
    manual_off_start_time = 0.0

    if preset == "time_2h":
        manual_off_time_sec = 2 * 3600
        manual_off_start_time = time.time()
        text = "✅ Preset применён: выключение через 2 часа."
    elif preset == "i_le_030":
        manual_off_current = 0.30
        text = "✅ Preset применён: выключение при I≤0.30 A."
    elif preset == "v_ge_162":
        manual_off_voltage = 16.2
        text = "✅ Preset применён: выключение при V≥16.2 V."
    elif preset == "clear":
        text = "✅ Условие выключения сброшено."
    else:
        raise ValueError("unknown_off_preset")

    _save_manual_off_state()
    return text


def _charge_modes_text() -> str:
    warning = (
        "⚠️ <b>ВНИМАНИЕ:</b> Эти режимы используют напряжение до 16.5В. "
        "Убедитесь, что АКБ отсоединена от бортовой сети автомобиля."
    )
    return f"<b>🚗 Авто</b>\n\n{warning}\n\nВыберите профиль заряда:"


def _build_charge_modes_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🟦 Ca/Ca", callback_data="v2_profile_caca"),
                InlineKeyboardButton(text="🟧 EFB", callback_data="v2_profile_efb"),
                InlineKeyboardButton(text="🟥 AGM", callback_data="v2_profile_agm"),
            ],
            [
                InlineKeyboardButton(text="🛠 Ручной режим", callback_data="v2_manual_choose"),
                InlineKeyboardButton(text="⏹ Off по условию", callback_data=OFF_CALLBACK_DATA),
            ],
            [InlineKeyboardButton(text="⬅️ Назад", callback_data=HOME_CALLBACK_DATA)],
        ]
    )


def _build_trend_summary(
    times: list,
    voltages: list,
    currents: list,
) -> str:
    """Сформировать краткую таблицу трендов для AI (напр. «10 мин назад: 13.2В | сейчас: 14.4В»)."""
    if not times or not voltages or not currents:
        return ""
    now = datetime.now()
    n = min(len(times), len(voltages), len(currents))
    indices = [0, max(1, n // 3), max(2, 2 * n // 3), n - 1] if n >= 4 else list(range(n))
    lines = []
    for i in indices:
        ts = times[i]
        v = voltages[i] if i < len(voltages) else 0.0
        c = currents[i] if i < len(currents) else 0.0
        try:
            dt = datetime.fromisoformat(str(ts).replace("Z", "+00:00")[:19])
            delta_min = int((now - dt).total_seconds() / 60)
            label = "сейчас" if delta_min < 1 else f"{delta_min} мин назад"
        except Exception:
            label = str(ts)[-8:] if len(str(ts)) >= 8 else "?"
        lines.append(f"{label}: {v:.2f}В, {c:.2f}А")
    return " | ".join(lines)


def _md_to_html(text: str) -> str:
    """Конвертировать **жирный** в <b>жирный</b> для Telegram HTML."""
    if not text:
        return text
    return re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", text)


def _sanitize_telegram_html(text: str) -> str:
    """Экранировать сырой HTML, оставляя только безопасные теги."""
    if not text:
        return text
    escaped = html.escape(text)
    allowed_tags = ("b", "i", "code", "pre")
    for tag in allowed_tags:
        escaped = escaped.replace(f"&lt;{tag}&gt;", f"<{tag}>")
        escaped = escaped.replace(f"&lt;/{tag}&gt;", f"</{tag}>")
    escaped = escaped.replace("&lt;br&gt;", "<br>")
    escaped = escaped.replace("&lt;br/&gt;", "<br/>")
    escaped = escaped.replace("&lt;br /&gt;", "<br />")
    return escaped


def _format_time(ts: str) -> str:
    """Преобразовать ISO timestamp в HH:MM:SS с пользовательским часовым поясом."""
    if not ts:
        return "?:?:?"
    try:
        dt = datetime.fromisoformat(str(ts).replace("Z", "+00:00")[:19])
        if dt.tzinfo is None:
            import pytz
            dt = dt.replace(tzinfo=pytz.UTC)
        return format_time_user_tz(dt)
    except Exception:
        return str(ts)[-8:] if len(str(ts)) >= 8 else "?:?:?"


def _safe_float(val, default: float = 0.0) -> float:
    if val is None or val in ("unknown", "unavailable", ""):
        return default
    try:
        return float(val)
    except (ValueError, TypeError):
        return default


def _cap_current(value: float) -> float:
    return min(MAX_STAGE_CURRENT, max(0.1, float(value)))


_temperature_source_observer = TemperatureSourceJournalObserver()


def _log_temperature_source_if_changed(live, *, stage, voltage, current, temperature, ah, session_id=None):
    """Observational, never a charging/safety decision."""
    _temperature_source_observer.record(
        live, stage=stage, voltage=voltage, current=current,
        temperature=temperature, ah=ah, session_id=session_id,
        log_event=log_event,
    )


def _should_skip_noisy_log_event(stage: str, event: str, now_ts: Optional[float] = None) -> bool:
    """
    Подавление шумных повторов в журнале.
    Сейчас ограничиваем поток EMERGENCY_UNAVAILABLE: не чаще 1 раза в 10 минут.
    """
    ev = (event or "").strip()
    if ev != "EMERGENCY_UNAVAILABLE":
        return False
    key = f"{stage}:{ev}"
    now_val = now_ts if now_ts is not None else time.time()
    last = _event_log_last_at.get(key, 0.0)
    if now_val - last < 600:
        return True
    _event_log_last_at[key] = now_val
    return False


def _runtime_execution_port():
    """Return the one app-scoped physical execution owner for this runtime module."""
    return get_or_create_execution_port(sys.modules[__name__])


async def _apply_phase_protection(uv: float, ui: float) -> None:
    """Compatibility helper delegated to the canonical execution owner."""
    await _runtime_execution_port().apply_phase_protection(
        target_voltage_v=float(uv),
        target_current_a=float(ui),
        ovp_offset_v=float(OVP_OFFSET),
        ocp_offset_a=float(OCP_OFFSET),
        max_stage_current_a=float(MAX_STAGE_CURRENT),
        has_ovp=bool(ENTITY_MAP.get("ovp")),
        has_ocp=bool(ENTITY_MAP.get("ocp")),
    )


OCP_STABILIZE_DELAY_SEC = 0.35


async def _apply_current_with_ocp(
    target_i: float,
    current_set_i: float,
    target_ocp_raw: Optional[float],
) -> None:
    """Compatibility helper delegated to the canonical execution owner."""
    await _runtime_execution_port().apply_current_with_ocp(
        target_current_a=float(target_i),
        current_set_a=float(current_set_i),
        target_ocp_a=target_ocp_raw,
        max_stage_current_a=float(MAX_STAGE_CURRENT),
        ocp_offset_a=float(OCP_OFFSET),
        has_ocp=bool(ENTITY_MAP.get("ocp")),
        stabilize_delay_s=float(OCP_STABILIZE_DELAY_SEC),
    )


async def _apply_current_with_startup_settle(
    target_i: float,
    current_set_i: float,
    target_ocp_raw: Optional[float],
    turn_on_requested: bool,
) -> Optional[float]:
    """Compatibility helper delegated to the canonical execution owner."""
    return await _runtime_execution_port().apply_current_with_startup_settle(
        target_current_a=float(target_i),
        current_set_a=float(current_set_i),
        target_ocp_a=target_ocp_raw,
        turn_on_requested=bool(turn_on_requested),
        max_stage_current_a=float(MAX_STAGE_CURRENT),
        ocp_offset_a=float(OCP_OFFSET),
        idle_safe_ocp_a=float(IDLE_SAFE_OCP),
        has_ocp=bool(ENTITY_MAP.get("ocp")),
        stabilize_delay_s=float(OCP_STABILIZE_DELAY_SEC),
    )


IDLE_SAFE_OVP = float(PB_AUTOMATIC_TARGET_CEILING_V.default) + OVP_OFFSET
# Hard cap for all charge stages.
IDLE_SAFE_OCP = MAX_STAGE_CURRENT


async def _apply_idle_protection() -> None:
    """Reset OVP/OCP through the canonical execution owner after full stop."""
    await _runtime_execution_port().reset_idle_protection(
        idle_safe_ovp_v=float(IDLE_SAFE_OVP),
        idle_safe_ocp_a=float(IDLE_SAFE_OCP),
        has_ovp=bool(ENTITY_MAP.get("ovp")),
        has_ocp=bool(ENTITY_MAP.get("ocp")),
    )


async def _apply_controller_output_actions(
    actions: Dict[str, Any],
    live: Dict[str, Any],
    *,
    battery_v: float,
    current: float,
    temp: float,
    ah: float,
) -> Optional[bool]:
    """Execute one controller batch through the single application execution owner.

    Stage-transition commit remains a controller/runtime concern. Physical
    ordering, startup settle, final V/I/OVP/OCP verification and forced OFF are
    owned by :class:`application.execution_port.ExecutionPort`.
    """
    return await execute_controller_action_batch(
        actions, live,
        execution_port=_runtime_execution_port(),
        controller=charge_controller,
        battery_v=battery_v,
        current=current,
        temp=temp,
        ah=ah,
        max_stage_current_a=MAX_STAGE_CURRENT,
        ocp_offset_a=OCP_OFFSET,
        idle_safe_ocp_a=IDLE_SAFE_OCP,
        stabilize_delay_s=OCP_STABILIZE_DELAY_SEC,
        recipe_voltage_ceiling_v=float(PB_AUTOMATIC_TARGET_CEILING_V.default),
        has_ovp=bool(ENTITY_MAP.get("ovp")),
        has_ocp=bool(ENTITY_MAP.get("ocp")),
        notify=_charge_notify,
        log_event=log_event,
        logger=logger,
    )


async def _hard_stop_charge(clear_session: bool = True) -> None:
    """Finish AUTO after verified OFF; STOP must never program OVP/OCP."""
    if not await _runtime_execution_port().request_verified_off():
        raise RuntimeError("STOP refused: physical Output OFF not verified")
    # No idle OVP/OCP reset: readback delays must not block session retirement.
    charge_controller.stop(clear_session=clear_session)
    _clear_operator_pause()


def _parse_uptime_to_elapsed_sec(uptime_raw) -> Optional[float]:
    """
    Преобразует uptime из HA в прошедшие секунды.
    Поддерживает: число (секунды), строку "8:36" (H:MM) или "8:36:00" (H:MM:SS), ISO-дату.
    """
    if uptime_raw is None or uptime_raw == "":
        return None
    if isinstance(uptime_raw, (int, float)):
        return float(uptime_raw)
    s = str(uptime_raw).strip()
    if not s:
        return None
    try:
        return float(s)
    except ValueError:
        pass
    # Формат таймера прибора: "8:36" (ч:мин), "8:36:00" (ч:мин:сек), "9:00" (минуты:секунды при < 1 ч)
    if ":" in s and "T" not in s and "-" not in s:
        parts = s.split(":")
        try:
            if len(parts) == 2:
                a, b = int(parts[0].strip()), int(parts[1].strip())
                if a == 0:
                    return b * 60  # "0:09" = 0 ч 9 мин
                if 1 <= a <= 59 and b == 0:
                    return a * 60  # "9:00" = 9 мин (таймер прибора часто MM:SS при < 1 ч)
                return a * 3600 + b * 60  # часы:минуты "8:36"
            if len(parts) == 3:
                h, m, sec = int(parts[0].strip()), int(parts[1].strip()), int(parts[2].strip())
                return h * 3600 + m * 60 + sec
        except (ValueError, IndexError):
            pass
    try:
        dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
        elapsed = time.time() - dt.timestamp()
        if elapsed < 0:
            return None  # дата в будущем — не использовать
        return elapsed
    except Exception:
        return None


# Макс. время (сек), при котором считаем uptime таймером заряда (иначе — время с включения прибора)
UPTIME_AS_CHARGE_TIMER_MAX_SEC = 24 * 3600
# Синхронизировать total_start_time с прибором только если расхождение не больше 5 мин (иначе не затирать новую сессию)
UPTIME_SYNC_MAX_DRIFT_SEC = 300


def _sync_total_start_from_uptime(
    charge_controller,
    live: Optional[Dict],
    *,
    max_drift_sec: int = UPTIME_SYNC_MAX_DRIFT_SEC,
    allow_init: bool = False,
) -> bool:
    """
    Синхронизирует total_start_time с uptime прибора только при малом расхождении.
    Возвращает True, если total_start_time был обновлён.
    """
    if not getattr(charge_controller, "is_active", False):
        return False
    uptime_raw = (live or {}).get("uptime")
    if uptime_raw is None:
        return False
    elapsed = _parse_uptime_to_elapsed_sec(uptime_raw)
    if elapsed is None or not (0 < elapsed <= UPTIME_AS_CHARGE_TIMER_MAX_SEC):
        return False

    now = time.time()
    total_start = float(getattr(charge_controller, "total_start_time", 0) or 0)
    if total_start > 0:
        our_elapsed = now - total_start
        if abs(our_elapsed - elapsed) > max_drift_sec:
            return False
    elif not allow_init:
        return False

    charge_controller.total_start_time = now - elapsed
    return True


def _format_uptime_display(uptime_raw) -> str:
    """
    Форматирование сущности sensor.rd_6018_uptime для отображения.
    Если приходит ISO-дата (момент старта заряда) — показываем «Старт: DD.MM HH:MM (прошло ЧЧ:ММ)».
    Иначе — сырое значение (число секунд или строка типа "8:36").
    """
    if uptime_raw is None or uptime_raw == "":
        return "—"
    s = str(uptime_raw).strip()
    if not s:
        return "—"
    # ISO datetime: 2026-02-12T14:38:56+00:00 — момент старта заряда
    if "T" in s and "-" in s:
        try:
            dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
            # Показываем старт в пользовательском часовом поясе, чтобы не было расхождения с "прошло".
            start_str = format_time_user_tz(dt, "%d.%m.%Y %H:%M")
            elapsed = _parse_uptime_to_elapsed_sec(uptime_raw)
            if elapsed is not None and 0 <= elapsed <= UPTIME_AS_CHARGE_TIMER_MAX_SEC:
                h, m = int(elapsed // 3600), int((elapsed % 3600) // 60)
                return f"Старт: {start_str} (прошло {h:02d}:{m:02d})"
            return f"Старт: {start_str}"
        except Exception:
            return s
    # Число или строка "8:36"
    elapsed = _parse_uptime_to_elapsed_sec(uptime_raw)
    if elapsed is not None and 0 <= elapsed <= UPTIME_AS_CHARGE_TIMER_MAX_SEC:
        h, m = int(elapsed // 3600), int((elapsed % 3600) // 60)
        return f"{h:02d}:{m:02d}"
    return s


def _apply_restore_time_corrections(charge_controller, live: Optional[Dict]) -> None:
    """
    После восстановления: пауза потери связи вычитается из таймеров.
    Если sensor.rd_6018_uptime возвращает таймер заряда (как на дисплее, ≤24ч) — синхронизируем общее время.
    """
    now = time.time()
    link_lost = getattr(charge_controller, "_link_lost_at", 0) or 0
    if link_lost > 0:
        gap = now - link_lost
        charge_controller.total_start_time += gap
        charge_controller.stage_start_time += gap
        charge_controller._link_lost_at = 0
    _sync_total_start_from_uptime(
        charge_controller,
        live,
        max_drift_sec=UPTIME_SYNC_MAX_DRIFT_SEC,
        allow_init=False,
    )


def format_electrical_data(v: float, i: float, p: float = None, precision: int = 2) -> str:
    """Форматтер для электрических данных V/I/P с HTML-экранированием и точностью .2f."""
    # Разделитель между значениями — один пробел (без вертикальных черт).
    result = f"{v:.2f}В {i:.2f}А"  # Принудительно .2f для всех V/I
    if p is not None:
        result += f" {p:.1f}Вт"
    return html.escape(result)


def format_temperature_data(t_ext: float, t_int: float = None, warn_threshold: float = 50.0) -> str:
    """Форматтер для температурных данных с предупреждениями и HTML-экранированием."""
    parts = [f"🌡 АКБ {t_ext:.1f}°C"]
    if t_int is not None:
        block_part = f"БП {t_int:.1f}°C"
        if t_int > warn_threshold:
            block_part += " ⚠️"
        parts.append(block_part)
    return html.escape(" | ".join(parts))


def format_status_data(is_on: bool, mode: str, stage: str = None) -> str:
    """Форматтер для статусных данных с HTML-экранированием."""
    status_emoji = "⚡️" if is_on else "⏸️"
    result = f"{status_emoji}{mode}"
    if stage:
        result += f" {html.escape(stage)}"
    return result


def safe_html_format(template: str, **kwargs) -> str:
    """Безопасное форматирование HTML с экранированием переменных."""
    # Экранируем все переменные, кроме тех что уже содержат HTML теги
    safe_kwargs = {}
    for key, value in kwargs.items():
        if isinstance(value, str) and ('<' in value or '>' in value or '&' in value):
            # Если значение уже содержит HTML теги, не экранируем
            if not any(tag in value for tag in ['<b>', '<i>', '<code>', '</b>', '</i>', '</code>']):
                safe_kwargs[key] = html.escape(value)
            else:
                safe_kwargs[key] = value
        else:
            safe_kwargs[key] = html.escape(str(value)) if value is not None else ""
    
    # Заменяем неподдерживаемые HTML теги на текстовые аналоги
    result = template.format(**safe_kwargs)
    result = result.replace('<hr>', '___________________')
    result = result.replace('<hr/>', '___________________')
    result = result.replace('<hr />', '___________________')
    
    return result


# Глобальные переменные для отслеживания RESTORE событий
_last_restore_time: float = 0.0
_script_start_time: float = time.time()


def _collapse_noisy_events(events: list) -> list:
    """Сжать подряд идущие шумные события в одну запись с (xN)."""
    if not events:
        return events
    collapsed: list = []
    run_event: Optional[str] = None
    run_count = 0

    def _flush_run() -> None:
        nonlocal run_event, run_count
        if not run_event:
            return
        if run_count <= 1:
            collapsed.append(run_event)
        else:
            parts = run_event.split(" | ")
            if len(parts) > 6:
                parts[6] = f"{parts[6].strip()} (x{run_count})"
                collapsed.append(" | ".join(parts))
            else:
                collapsed.append(run_event)
        run_event = None
        run_count = 0

    for event in events:
        parts = event.split(" | ")
        event_name = parts[6].strip() if len(parts) > 6 else ""
        is_noisy = event_name == "EMERGENCY_UNAVAILABLE"
        if is_noisy:
            if run_event is None:
                run_event = event
                run_count = 1
            else:
                run_count += 1
            continue
        _flush_run()
        collapsed.append(event)
    _flush_run()
    return collapsed


def _remove_duplicate_events(events: list) -> list:
    """Compress only noisy duplicates and preserve transition/state events order."""
    if not events:
        return events
    events = _collapse_noisy_events(events)

    filtered_events = []
    restore_count = 0
    last_restore_event = None
    last_restore_stage = None
    emergency_count = 0
    last_emergency_event = None
    last_emergency_stage = None
    last_emergency_ts = None

    def _parse_ts(event: str):
        try:
            raw = event.split(" | ", 1)[0].strip("[]")
            return datetime.strptime(raw, "%Y-%m-%d %H:%M:%S")
        except Exception:
            return None

    def _flush_restore_group() -> None:
        nonlocal restore_count, last_restore_event, last_restore_stage
        if not last_restore_event:
            return
        if restore_count > 1:
            parts = last_restore_event.split(" | ")
            if len(parts) > 6:
                parts[6] = f"RESTORE (x{restore_count})"
                filtered_events.append(" | ".join(parts))
            else:
                filtered_events.append(last_restore_event)
        else:
            filtered_events.append(last_restore_event)
        restore_count = 0
        last_restore_event = None
        last_restore_stage = None

    def _flush_emergency_group() -> None:
        nonlocal emergency_count, last_emergency_event, last_emergency_stage, last_emergency_ts
        if not last_emergency_event:
            return
        if emergency_count > 1:
            parts = last_emergency_event.split(" | ")
            if len(parts) > 6:
                parts[6] = f"EMERGENCY_UNAVAILABLE (x{emergency_count})"
                filtered_events.append(" | ".join(parts))
            else:
                filtered_events.append(last_emergency_event)
        else:
            filtered_events.append(last_emergency_event)
        emergency_count = 0
        last_emergency_event = None
        last_emergency_stage = None
        last_emergency_ts = None

    for event in events:
        event_parts = event.split(" | ")
        if len(event_parts) > 6:
            event_field = event_parts[6].strip()
            current_event_type = event_field.split()[0] if event_field else ""
            stage = event_parts[1].strip()
            if current_event_type == "RESTORE":
                _flush_emergency_group()
                if last_restore_event and last_restore_stage == stage:
                    restore_count += 1
                    last_restore_event = event
                else:
                    _flush_restore_group()
                    restore_count = 1
                    last_restore_event = event
                    last_restore_stage = stage
                continue
            if current_event_type == "EMERGENCY_UNAVAILABLE":
                current_ts = _parse_ts(event)
                if last_emergency_event and last_emergency_stage == stage and last_emergency_ts and current_ts:
                    if (current_ts - last_emergency_ts).total_seconds() <= 600:
                        emergency_count += 1
                        last_emergency_event = event
                        last_emergency_ts = current_ts
                        continue
                _flush_restore_group()
                _flush_emergency_group()
                emergency_count = 1
                last_emergency_event = event
                last_emergency_stage = stage
                last_emergency_ts = current_ts
                continue

        _flush_emergency_group()
        _flush_restore_group()
        filtered_events.append(event)

    _flush_emergency_group()
    _flush_restore_group()
    return filtered_events


def _should_hide_restore_event(event: str) -> bool:
    """Определяет, нужно ли скрыть RESTORE событие от пользователя."""
    global _last_restore_time, _script_start_time
    
    if "RESTORE" not in event:
        return False
    
    current_time = time.time()
    
    # Показываем RESTORE только если:
    # 1. Это первый RESTORE после запуска скрипта (в течение первых 5 минут)
    # 2. Прошло более 2 минут с последнего показанного RESTORE
    if (current_time - _script_start_time < 300 and _last_restore_time == 0) or \
       (current_time - _last_restore_time > 120):
        _last_restore_time = current_time
        return False  # Показываем событие
    
    return True  # Скрываем событие


def format_log_event(event_line: str) -> str:
    """Форматирование строки события в красивый вид с иконками."""
    try:
        parts = event_line.split(' | ')
        if len(parts) < 6:
            return f"<code>{html.escape(event_line)}</code>"

        timestamp = parts[0].strip('[]')
        stage = parts[1].strip()
        voltage = parts[2].strip()
        current = parts[3].strip()
        temp = parts[4].strip()
        ah = parts[5].strip()
        event = " | ".join(parts[6:]).strip() if len(parts) > 6 else ""

        time_only = timestamp.split(' ')[1][:5] if ' ' in timestamp else timestamp[-8:-3]
        stage_short = stage.replace("Main Charge", "Main").replace("Десульфатация", "Desulf").replace("Безопасное ожидание", "Wait")
        stage_escaped = html.escape(stage_short)

        if event.startswith("SESSION_"):
            icon = "📘"
            event_tail = event.replace("SESSION_", "", 1).strip()
            text = f"[{time_only}] {icon} <b>{stage_escaped}: {html.escape(event_tail.split(' | ')[0])}</b>\n"
            for part in event.split(" | ")[1:]:
                part = part.strip()
                if not part or "=" not in part:
                    continue
                k, v = part.split("=", 1)
                if k.strip() == "rules":
                    text += f"└ Правила: {html.escape(v.strip())}\n"
                elif k.strip() == "profile":
                    text += f"└ Профиль: {html.escape(v.strip())}\n"
                elif k.strip() == "capacity_ah":
                    text += f"└ Емкость: {html.escape(v.strip())}Ah\n"
                elif k.strip() != "kind":
                    text += f"└ {html.escape(k.strip())}: {html.escape(v.strip())}\n"
            return text.rstrip()

        if event.startswith("EMERGENCY_UNAVAILABLE"):
            icon = "🧯"
            summary = event
            if "(x" in event:
                summary = event
            return f"[{time_only}] {icon} <b>{stage_escaped}</b>: {html.escape(summary)}"

        if event.startswith("BANK_FAULT_"):
            icon = "⚠️"
            summary = event.replace("BANK_FAULT_", "КЗ банки: ", 1)
            return f"[{time_only}] {icon} <b>{stage_escaped}</b>: {html.escape(summary)}"

        if event.startswith("END |"):
            icon = "📉"
            text = f"[{time_only}] {icon} <b>{stage_escaped}: завершён</b>\n"
            rest = event[5:].strip()
            for part in rest.split(" | "):
                part = part.strip()
                if ":" in part:
                    k, v = part.split(":", 1)
                    text += f"└ {k.strip()}: {v.strip()}\n"
            return text.rstrip()

        if event.strip().startswith("└"):
            detail = event.strip()[1:].strip()
            return f"[{time_only}] └ {html.escape(detail)}"

        if event.startswith("START"):
            icon = "🏁"
            text = f"[{time_only}] {icon} <b>{stage_escaped}: START</b>\n"
            if "Емкость:" in event:
                m = re.search(r"Емкость:\s*(\d+)\s*Ah", event, re.IGNORECASE)
                if m:
                    text += f"└ Емкость: {m.group(1)}Ah\n"
            if "profile=" in event:
                for p in ("EFB", "AGM", "Ca/Ca"):
                    if p in event:
                        text += f"└ Профиль: {p}\n"
                        break
            if "CUSTOM" in event and "profile=" not in event:
                text += "└ Профиль: Custom\n"
            return text.rstrip()

        if event.startswith("STAGE_CHANGE |"):
            transition = event.replace("STAGE_CHANGE |", "", 1).strip()
            return f"[{time_only}] >> <b>{stage_escaped}</b>: {html.escape(transition)}"

        icon = "📋"
        if "DONE" in event or "FINISH" in event:
            icon = "✅"
        elif "STOP" in event or "EMERGENCY" in event:
            icon = "🛑"
        elif "WARNING" in event or "TEMP" in event:
            icon = "⚠️"
        elif "CHECKPOINT" in event:
            return ""
        elif "RESTORE" in event:
            return ""
        if _should_hide_restore_event(event):
            return ""
        event_escaped = html.escape(event)
        return f"[{time_only}] {icon} <b>{stage_escaped}</b>: {event_escaped}"

    except Exception as ex:
        logger.error("Failed to format log event: %s", ex)
        return f"<code>{html.escape(event_line[:100])}</code>"


def _retire_graph_tracking_for_message(chat_id: int, user_id: int, message_id: int) -> None:
    """Forget a graph workspace before replacing its Telegram message.

    The log view is text-only.  When it is opened from the photo-based active
    workspace, Telegram cannot edit that photo into text, so the handler sends a
    replacement and deletes the photo.  Leaving the graph IDs cached after that
    deletion makes ``К панели`` treat a non-existent message as the live graph
    workspace and prevents graph recreation.
    """
    graph_by_user = globals().get("user_graph_dashboard")
    graph_by_chat = globals().get("chat_graph_dashboard")
    if not isinstance(graph_by_user, dict) and not isinstance(graph_by_chat, dict):
        return
    graph_message_id = (
        graph_by_user.get(user_id) if isinstance(graph_by_user, dict) else None
    )
    chat_graph_message_id = (
        graph_by_chat.get(chat_id) if isinstance(graph_by_chat, dict) else None
    )
    if graph_message_id != message_id and chat_graph_message_id != message_id:
        return
    if isinstance(graph_by_user, dict) and graph_by_user.get(user_id) == message_id:
        graph_by_user.pop(user_id, None)
    if isinstance(graph_by_chat, dict) and graph_by_chat.get(chat_id) == message_id:
        graph_by_chat.pop(chat_id, None)


async def _safe_output_on() -> bool:
    """Безопасно получить текущий статус выхода для построения клавиатуры."""
    try:
        live = await hass.get_all_live()
        return str(live.get("switch", "")).lower() == "on"
    except Exception:
        return False


async def _operator_pause_toggle(call: Any) -> str:
    """Pause/resume the active charge without converting it into a stop."""
    global operator_pause_started_at, last_chat_id, last_user_id

    user_id = call.from_user.id if call.from_user else 0
    if not _is_action_allowed(user_id, "operator_pause_toggle", cooldown_sec=1.5):
        return "Команда уже выполняется..."
    last_chat_id = call.message.chat.id
    last_user_id = user_id
    live = await hass.get_all_live()
    output_on = str(live.get("switch", "")).lower() == "on"

    if not _operator_pause_active():
        if not charge_controller.is_active:
            return "Активной сессии заряда нет"
        if output_on:
            await _runtime_execution_port().request_verified_off()
        after = await hass.get_all_live()
        if str(after.get("switch", "")).lower() == "on":
            return "Пауза не включена: Output не подтверждён OFF"
        async with _runtime_execution_port()._guard_owner_lock:
            charge_controller._save_session(
                _safe_float(after.get("battery_voltage")),
                _safe_float(after.get("current")),
                _safe_float(after.get("ah")),
            )
        operator_pause_started_at = time.time()
        _save_operator_pause_state()
        log_event(
            charge_controller.current_stage,
            _safe_float(after.get("battery_voltage")),
            _safe_float(after.get("current")),
            _safe_float(after.get("temp_ext")),
            _safe_float(after.get("ah")),
            "OPERATOR_PAUSE_ON",
        )
        return "Пауза включена · Output OFF подтверждён"

    if output_on:
        await _runtime_execution_port().request_verified_off()
        after = await hass.get_all_live()
        if str(after.get("switch", "")).lower() == "on":
            return "Продолжение заблокировано: Output не подтверждён OFF"
        live = after

    ovp_triggered = _canonical_bool(live, "ovp_triggered")
    ocp_triggered = _canonical_bool(live, "ocp_triggered")
    temp_ext = _safe_float(live.get("temp_ext"))
    input_voltage = _safe_float(live.get("input_voltage"), 0.0)
    if ovp_triggered or ocp_triggered:
        return "Продолжение заблокировано: активна защита OVP/OCP"
    if temp_ext < MIN_START_TEMP:
        return f"Продолжение заблокировано: температура АКБ {temp_ext:.1f}°C"
    if input_voltage < MIN_INPUT_VOLTAGE:
        return f"Продолжение заблокировано: вход БП {input_voltage:.0f}V"

    if not charge_controller.is_active:
        if not paused_done_resume_is_authorized(
            sys.modules[__name__],
            charge_controller,
        ):
            return (
                "Продолжение заблокировано: сохранённый Done не имеет "
                "подтверждённого Storage Output ON intent"
            )
        ok, _ = charge_controller.try_restore_session(
            _safe_float(live.get("battery_voltage")),
            _safe_float(live.get("current")),
            _safe_float(live.get("ah")),
            output_is_on=output_on,
            is_cv=_canonical_bool(live, "is_cv"),
            is_cc=_canonical_bool(live, "is_cc"),
        )
        if not ok:
            return "Продолжение заблокировано: сессия не восстановлена"

    pause_seconds = max(0.0, time.time() - float(operator_pause_started_at or time.time()))
    stage = charge_controller.current_stage
    if stage == charge_controller.STAGE_SAFE_WAIT:
        _shift_operator_pause_clocks(pause_seconds)
        _clear_operator_pause()
        return "Пауза снята · ожидание продолжает контролироваться"

    uv, ui = charge_controller._get_target_v_i(temp_ext)
    await _apply_phase_protection(uv, ui)
    await _runtime_execution_port().program_voltage(uv)
    await _runtime_execution_port().program_current(_cap_current(ui))
    enabled = await _runtime_execution_port().request_verified_on()
    if not enabled:
        return "Продолжение заблокировано: безопасное включение не подтверждено"

    _shift_operator_pause_clocks(pause_seconds)
    _clear_operator_pause()
    log_event(
        charge_controller.current_stage,
        _safe_float(live.get("battery_voltage")),
        _safe_float(live.get("current")),
        temp_ext,
        _safe_float(live.get("ah")),
        "OPERATOR_PAUSE_OFF",
    )
    return "Пауза снята · заряд продолжен"


async def _build_ai_analysis_text() -> str:
    """Собрать AI-анализ для кнопки/команды."""
    try:
        times, voltages, currents = await get_raw_history(limit=50)
        trend_summary = _build_trend_summary(times, voltages, currents)
        live = await hass.get_all_live()
        is_cv = _canonical_bool(live, "is_cv")
        is_cc = _canonical_bool(live, "is_cc")
        mode_flags = "CV" if is_cv else ("CC" if is_cc else "-")
        capacity_ah = int(getattr(charge_controller, "ah_capacity", 0) or 0)
        capacity_known = bool(charge_controller.is_active and capacity_ah > 0)
        stage_remaining = "—"
        if charge_controller.is_active:
            try:
                stage_remaining = charge_controller.get_timers().get("remaining_time", "—")
            except Exception:
                stage_remaining = "—"
        temp_ext_now = _safe_float(live.get("temp_ext", 0.0))
        controller_snapshot = _safe_stage_snapshot(temp_ext_now)
        recent_events = get_recent_events(10)
        history = {
            "times": times,
            "voltages": voltages,
            "currents": currents,
            "trend_summary": trend_summary,
            "ai_context": {
                "output_status": "ON" if str(live.get("switch", "")).lower() == "on" else "OFF",
                "current_stage": charge_controller.current_stage if charge_controller.is_active else "Idle",
                "battery_type": charge_controller.battery_type if charge_controller.is_active else "UNKNOWN",
                "mode": mode_flags,
                "capacity_known": capacity_known,
                "capacity_ah": capacity_ah if capacity_known else "UNKNOWN",
                "remaining_time": stage_remaining,
                "v_batt_now": _safe_float(live.get("battery_voltage", 0.0)),
                "i_now": _safe_float(live.get("current", 0.0)),
                "temp_ext_now": _safe_float(live.get("temp_ext", 0.0)),
                "temp_int_now": _safe_float(live.get("temp_int", 0.0)),
            },
            "controller_snapshot": controller_snapshot,
            "recent_events": recent_events,
        }
        result = await ask_deepseek(history)
        result_html = _sanitize_telegram_html(
            _md_to_html(result).replace("<br>", "\n").replace("<br/>", "\n").replace("<br />", "\n")
        )
        return f"<b>🧠 AI Анализ</b>\n{result_html}"
    except Exception as ex:
        logger.warning("AI analysis failed: %s", ex)
        return "<b>🧠 AI Анализ</b>\n<i>Сервис временно недоступен, попробуйте позже.</i>"


def _build_dashboard_blocks(live: Dict[str, Any]) -> tuple:
    """
    Построить блоки текста дашборда по данным live.
    Возвращает (status_line, live_line, stage_block, capacity_line, idle_warning).
    """
    battery_v = _safe_float(live.get("battery_voltage"))
    set_v = _safe_float(live.get("set_voltage"))
    set_i = _safe_float(live.get("set_current"))
    is_on = str(live.get("switch", "")).lower() == "on"
    i = _safe_float(live.get("current"))
    temp_ext = _safe_float(live.get("temp_ext"))
    temp_int = _safe_float(live.get("temp_int"))
    ah = _safe_float(live.get("ah"))
    is_cv = _canonical_bool(live, "is_cv")
    is_cc = _canonical_bool(live, "is_cc")
    mode = "CV" if is_cv else ("CC" if is_cc else "-")
    output_v = _safe_float(live.get("voltage"))

    if charge_controller.is_active:
        timers = charge_controller.get_timers()
        status_emoji = "🟢" if (is_on and i > 0.05) else "🟡"
        stage_name = html.escape(_stage_label(charge_controller.current_stage, short=True))
        battery_type = html.escape(charge_controller.battery_type)
        total_time = html.escape(timers["total_time"])
        status_line = f"{status_emoji} Заряд: {stage_name} | {battery_type} | ⏱ {total_time}"
    else:
        status_line = f"⚪ Ожидание АКБ | Vакб {battery_v:.2f}В"
    # Выход включён и ток идёт, но бот не ведёт заряд (ручной режим на приборе). Таймер «выкл по условию» при этом сработает.
    idle_warning = ""
    if not charge_controller.is_active and is_on and i > 0.05:
        idle_warning = "🟡 Ручной режим: выход включен без автоэтапов"

    electrical_data = format_electrical_data(battery_v, i)
    temp_data = format_temperature_data(temp_ext, temp_int)
    
    live_line = f"⚡ LIVE: {mode} {electrical_data} {temp_data}"

    stage_block = ""
    if charge_controller.is_active:
        timers = charge_controller.get_timers()
        stage_time = timers["stage_time"]
        current_v_set = _safe_float(live.get("set_voltage", set_v))
        current_i_set = _safe_float(live.get("set_current", set_i))
        transition_condition = ""
        raw_stage = charge_controller.current_stage
        time_limit = timers["remaining_time"]

        if "Main" in raw_stage:
            if charge_controller.battery_type == "Custom":
                transition_condition = "🔜 ФИНИШ: &lt;0.30А"
            elif charge_controller.battery_type in ["Ca/Ca", "EFB"]:
                transition_condition = "🔜 ПЕРЕХОД: &lt;0.30А"
            elif charge_controller.battery_type == "AGM":
                transition_condition = "🔜 ПЕРЕХОД: &lt;0.20А"
        elif "Mix" in raw_stage:
            v_max = charge_controller.v_max_recorded
            i_min = charge_controller.i_min_recorded
            if is_cv:
                if i_min is not None:
                    expect_i = i_min + DELTA_I_EXIT
                    transition_condition = f"🔜 ФИНИШ: ΔI +{DELTA_I_EXIT}А I≥{expect_i:.2f}А"
                else:
                    transition_condition = f"🔜 ФИНИШ: ΔI +{DELTA_I_EXIT}А"
            elif is_cc:
                if v_max is not None:
                    expect_v = v_max - DELTA_V_EXIT
                    transition_condition = f"🔜 ФИНИШ: ΔV −{DELTA_V_EXIT}В V≤{expect_v:.2f}В"
                else:
                    transition_condition = f"🔜 ФИНИШ: ΔV −{DELTA_V_EXIT}В"
            else:
                transition_condition = f"🔜 ФИНИШ: ΔV −{DELTA_V_EXIT}В (CC) или ΔI +{DELTA_I_EXIT}А (CV)"
        elif "Десульфатация" in raw_stage:
            transition_condition = "🔜 ПЕРЕХОД: 2ч"
        elif "Безопасное ожидание" in raw_stage:
            transition_condition = "🔜 ПЕРЕХОД: падение V"
        elif "Остывание" in raw_stage:
            transition_condition = "🔜 ВОЗВРАТ: T&le;35°C"

        if time_limit != "—":
            try:
                if ":" in time_limit:
                    hours = int(time_limit.split(":")[0])
                    time_display = f"{hours}ч" if hours > 0 else "менее 1ч"
                else:
                    time_display = time_limit
            except Exception:
                time_display = time_limit
            if transition_condition:
                transition_condition = f"{transition_condition} | ⏱ {time_display}"
            else:
                transition_condition = f"🔜 ⏱ {time_display}"

        progress_line = _format_stage_progress_line(live)
        if progress_line:
            transition_condition = progress_line
        stage_name = html.escape(_stage_label(charge_controller.current_stage, short=False))
        stage_time_safe = html.escape(stage_time)
        stage_block = (
            f"\n📍 Этап: {stage_name} | ⏱ {stage_time_safe}\n"
            f"⚙ Уставки: {current_v_set:.2f}В | {current_i_set:.2f}А\n"
            f"{transition_condition}"
        )

    capacity_line = f"🔋 Емкость: {ah:.2f} Ач"
    return status_line, live_line, stage_block, capacity_line, idle_warning


def _strip_html_tags(text: str) -> str:
    """Убрать HTML-теги и нормализовать пробелы для компактного текста."""
    plain = re.sub(r"<[^>]+>", "", text or "")
    plain = plain.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&")
    return re.sub(r"\s+", " ", plain).strip()


from runtime.ui.components.stage_duration import (
    format_eta_compact as _format_eta_compact,
    format_seconds_compact as _format_seconds_compact,
)


def _format_stage_progress_line(live: Dict[str, Any]) -> str:
    """Compact stage target/fact/remaining line for dashboard cards."""
    if not charge_controller.is_active:
        return ""

    current_v = _safe_float(live.get("battery_voltage"))
    current_i = _safe_float(live.get("current"))
    temp_ext = _safe_float(live.get("temp_ext"))
    snapshot = _safe_stage_snapshot(temp_ext)
    timers = snapshot.get("timers") or {}
    hold = snapshot.get("hold") or {}
    is_cv = _canonical_bool(live, "is_cv")
    is_cc = _canonical_bool(live, "is_cc")
    stage = charge_controller.current_stage
    remaining = _format_eta_compact(timers.get("remaining_time", "—"))

    def _line(target: str, fact: str, rem: str, reached: bool, suffix: str = "") -> str:
        mark = "✅" if reached else "⚪"
        tail = f" {suffix}" if suffix else ""
        return f"🎯 {target} | {mark} {fact} | ⏳ {rem}{tail}"

    kind = str(hold.get("kind") or "").lower()
    if hold:
        if "low-current hold" in kind:
            threshold = _safe_float(hold.get("threshold_a"))
            target = f"I≤{threshold:.2f}A"
            fact = f"I {current_i:.2f}A"
            reached = bool(hold.get("active")) or current_i <= threshold
            if reached:
                return _line(target, fact, html.escape(str(hold.get("remaining_text") or remaining)), True, "до Mix")
            return _line(target, fact, _format_seconds_compact(hold.get("required_sec")), False, "hold")

        if "desulf timer" in kind:
            fact = html.escape(str(hold.get("elapsed_text") or timers.get("stage_time", "—")))
            return _line("2ч", fact, html.escape(str(hold.get("remaining_text") or remaining)), False, "до SAFE_WAIT")

        if "mix delta timer" in kind:
            fact = html.escape(str(hold.get("elapsed_text") or timers.get("stage_time", "—")))
            return _line("Δ подтверждена", f"таймер {fact}", html.escape(str(hold.get("remaining_text") or remaining)), True, "до SAFE_WAIT")

        if "safe wait" in kind:
            threshold_v = _safe_float(hold.get("threshold_v"))
            target = f"V≤{threshold_v:.2f}V"
            fact = f"V {current_v:.2f}V"
            reached = current_v <= threshold_v
            return _line(target, fact, html.escape(str(hold.get("remaining_text") or remaining)), reached, "до выхода")

        if stage == charge_controller.STAGE_MIX:
            policy = snapshot.get("mix_exit_policy") or {}
            mix_delta = charge_controller._mix_current_delta_threshold()
            if charge_controller.finish_timer_start is not None:
                if is_cv and charge_controller.i_min_recorded is not None:
                    delta_now = max(0.0, current_i - charge_controller.i_min_recorded)
                    fact = f"ΔI {delta_now:.3f}A"
                    reached = charge_controller._exit_cv_condition(current_i)
                    return _line(f"ΔI≥{mix_delta:.2f}A", fact, remaining, reached, "до SAFE_WAIT")
                if is_cc and charge_controller.v_max_recorded is not None:
                    delta_now = max(0.0, charge_controller.v_max_recorded - current_v)
                    fact = f"ΔV {delta_now:.3f}V"
                    reached = charge_controller._exit_cc_condition(current_v)
                    return _line(f"ΔV≥{DELTA_V_EXIT:.2f}V", fact, remaining, reached, "до SAFE_WAIT")
            return _line("Δ подтверждена", "таймер 2ч", remaining, True, "до SAFE_WAIT")

        if is_cv:
            base_i = charge_controller.i_min_recorded if charge_controller.i_min_recorded is not None else current_i
            delta_now = max(0.0, current_i - base_i)
            mix_delta = charge_controller._mix_current_delta_threshold()
            target = f"ΔI≥{mix_delta:.2f}A"
            fact = f"ΔI {delta_now:.3f}A"
            reached = charge_controller._exit_cv_condition(current_i)
        elif is_cc:
            base_v = charge_controller.v_max_recorded if charge_controller.v_max_recorded is not None else current_v
            delta_now = max(0.0, base_v - current_v)
            target = f"ΔV≥{DELTA_V_EXIT:.2f}V"
            fact = f"ΔV {delta_now:.3f}V"
            reached = charge_controller._exit_cc_condition(current_v)
        else:
            mix_delta = charge_controller._mix_current_delta_threshold()
            target = f"ΔV≥{DELTA_V_EXIT:.2f}V / ΔI≥{mix_delta:.2f}A"
            fact = f"V {current_v:.2f}V, I {current_i:.2f}A"
            reached = False

        fallback_hours = policy.get("fallback_limit_hours")
        if isinstance(fallback_hours, (int, float)):
            fallback_text = f"{int(fallback_hours)}ч" if float(fallback_hours).is_integer() else f"{fallback_hours:.1f}ч"
        else:
            fallback_text = remaining
        return _line(target, fact, fallback_text or remaining, reached, "лимит")

    if stage == charge_controller.STAGE_COOLING:
        return _line("T≤35°C", f"АКБ {temp_ext:.1f}°C", "возврат после остывания", temp_ext <= 35.0)

    if stage == charge_controller.STAGE_DESULFATION:
        return _line("2ч", html.escape(str(timers.get("stage_time", "—"))), html.escape(str(timers.get("remaining_time", "—"))), False, "до SAFE_WAIT")

    return ""


def _safe_stage_snapshot(temp_ext: Optional[float]) -> Dict[str, Any]:
    """Безопасный snapshot стратегии: при сбое вернёт минимальный, но валидный контекст."""
    if not charge_controller.is_active:
        return {
            "stage": "Idle",
            "profile": "UNKNOWN",
            "is_active": False,
            "summary": "Активный заряд не идет.",
            "transition": "Нет активного перехода.",
            "next_stage": "Idle",
            "timers": {"total_time": "—", "stage_time": "—", "remaining_time": "—"},
            "hold": None,
            "safety": {},
            "target_voltage": 0.0,
            "target_current": 0.0,
        }

    try:
        return charge_controller.get_ai_stage_snapshot(temp_ext)
    except Exception as ex:
        logger.warning("safe stage snapshot fallback: %s", ex)
        try:
            timers = charge_controller.get_timers()
        except Exception:
            timers = {"total_time": "—", "stage_time": "—", "remaining_time": "—"}

        try:
            target_v, target_i = charge_controller._get_target_v_i(temp_ext)
        except Exception:
            target_v, target_i = 0.0, 0.0

        return {
            "stage": charge_controller.current_stage,
            "profile": charge_controller.battery_type,
            "is_active": True,
            "summary": "Снимок стратегии временно недоступен.",
            "transition": "Fallback snapshot after error.",
            "next_stage": charge_controller.current_stage,
            "timers": timers,
            "hold": None,
            "safety": {},
            "target_voltage": target_v,
            "target_current": target_i,
            "previous_stage": getattr(charge_controller, "previous_stage", charge_controller.current_stage),
            "stage_path": getattr(charge_controller, "_stage_history", []),
            "last_transition_reason": getattr(charge_controller, "_last_transition_reason", ""),
        }


def _compact_dashboard_caption(
    live: Dict[str, Any],
    chart_mode: str,
    mode: str,
    idle_warning: str,
) -> str:
    """Короткая подпись дашборда для мобильного экрана."""
    battery_v = _safe_float(live.get("battery_voltage"))
    current = _safe_float(live.get("current"))
    ah = _safe_float(live.get("ah"))
    temp_ext = _safe_float(live.get("temp_ext"))
    temp_int = _safe_float(live.get("temp_int"))
    is_on = str(live.get("switch", "")).lower() == "on"
    ovp_tr = _canonical_bool(live, "ovp_triggered")
    ocp_tr = _canonical_bool(live, "ocp_triggered")

    lines = []
    if charge_controller.is_active:
        timers = charge_controller.get_timers()
        profile = html.escape(charge_controller.battery_type)
        capacity_ah = int(getattr(charge_controller, "ah_capacity", 0) or 0)
        cap_suffix = f" | {capacity_ah}Ah" if capacity_ah > 0 else ""
        stage_name = html.escape(_stage_label(charge_controller.current_stage, short=True))
        remaining = html.escape(_format_eta_compact(timers.get("remaining_time", "—")))
        lines.append(f"<b>📊 RD6018 · {profile}{cap_suffix}</b>")
        lines.append(f"<b>Стадия: {stage_name}</b>")
        lines.append(f"V: <b>{battery_v:.2f}V</b>   I: <b>{current:.2f}A</b>")
        lines.append(f"Ah: <b>{ah:.2f}</b>   АКБ: <b>{temp_ext:.1f}°C</b>")
        lines.append(f"Режим: {html.escape(mode)}  Лимит этапа: {remaining}")
        progress_line = _format_stage_progress_line(live)
        if progress_line:
            lines.append(progress_line)
    else:
        state_label = "Готов" if is_on else "Ожидание"
        lines.append(f"<b>📊 RD6018 · {state_label}</b>")
        lines.append(f"АКБ: <b>{battery_v:.2f}V</b>   I: <b>{current:.2f}A</b>")
        lines.append(f"Ah: <b>{ah:.2f}</b>   АКБ: <b>{temp_ext:.1f}°C</b>")
        lines.append(f"Режим: {html.escape(mode)}")

    alerts = []
    off_line = _format_manual_off_for_dashboard()
    if off_line:
        alerts.append("⏹ Off: активно")
    if ovp_tr or ocp_tr:
        alerts.append(f"🛡 OVP:{'ON' if ovp_tr else 'off'} OCP:{'ON' if ocp_tr else 'off'}")
    if idle_warning:
        alerts.append("⚠ Ручной режим на приборе")

    if alerts:
        lines.append(" | ".join(alerts))
        lines.append(f"📈 {_chart_label(chart_mode)}")
    else:
        lines.append(f"✅ Норма · 📈 {_chart_label(chart_mode)}")
    return "\n".join(line for line in lines if line)


async def charge_monitor() -> None:
    """Фоновая задача: раз в 15 мин проверяет ток; алерты при завершении заряда и при нулевом потреблении."""
    global last_chat_id, last_charge_alert_at, last_idle_alert_at, zero_current_since
    while True:
        await asyncio.sleep(15 * 60)
        try:
            live = await hass.get_all_live()
            output_on = str(live.get("switch", "")).lower() == "on"
            battery_v = _safe_float(live.get("battery_voltage"))
            i = _safe_float(live.get("current"))
            now = datetime.now()

            if not output_on:
                zero_current_since = None
                continue

            # Алерт: ток 0.0А более 30 мин при включенном выходе
            if i <= 0.0:
                if zero_current_since is None:
                    zero_current_since = now
                elif (now - zero_current_since).total_seconds() >= ZERO_CURRENT_THRESHOLD_MINUTES * 60:
                    if not last_idle_alert_at or (now - last_idle_alert_at) >= IDLE_ALERT_COOLDOWN:
                        msg = (
                            "⚠️ Выход включен, но потребление отсутствует. "
                            "Не забудьте выключить прибор."
                        )
                        logger.info("Charge monitor (idle): %s", msg)
                        last_idle_alert_at = now
                        _charge_notify(msg)
            else:
                zero_current_since = None

            # Алерт: заряд завершён (высокое U на АКБ, низкий I). При V < 14В (хранение) — не чаще 1 раза в час
            battery_v = _safe_float(live.get("battery_voltage"))
            if battery_v >= 13.5 and i < 0.1:
                cooldown = STORAGE_ALERT_COOLDOWN if battery_v < 14.0 else CHARGE_ALERT_COOLDOWN
                if last_charge_alert_at and (now - last_charge_alert_at) < cooldown:
                    continue
                msg = (
                    f"⚠️ Заряд завершён или аккумулятор почти полон. "
                    f"Ток упал до {i:.2f}А при напряжении {battery_v:.2f}В."
                )
                logger.info("Charge monitor: %s", msg)
                last_charge_alert_at = now
                _charge_notify(msg)
        except Exception as ex:
            logger.error("charge_monitor (сеть/ошибка): %s", ex)
            await asyncio.sleep(60)


async def data_logger() -> None:
    """Фоновая задача: опрос HA каждые 30с, сохранение в DB, ChargeController tick, проверка безопасности."""
    global last_chat_id, last_ha_ok_time, last_checkpoint_time, link_lost_alert_sent, link_failure_streak, last_live_context, soft_watchdog_outage_reported
    last_cleanup_time = 0.0
    
    while True:
        # A dead command path cannot be made safer by sending the same STOP
        # repeatedly. Keep the charge session intact and let the independent
        # edge lease remain the blind-operation backstop until readback returns.
        try:
            live = await hass.get_all_live()
        except Exception as ex:
            if _is_physical_transport_error(ex):
                link_failure_streak += 1
                charge_controller._was_unavailable = True
                charge_controller._link_lost_at = time.time()
                if (
                    charge_controller._last_known_output_on
                    and link_failure_streak >= LINK_FAILURE_NOTIFY_THRESHOLD
                    and not link_lost_alert_sent
                ):
                    _charge_notify("🚨 Связь с RD6018 не восстановилась после "
                                   f"{link_failure_streak} попыток. Аппаратный lease остаётся последним рубежом.")
                    link_lost_alert_sent = True
                logger.warning(
                    "ESPHome transport outage #%d; no host STOP sent: %s",
                    link_failure_streak,
                    ex,
                )
            else:
                logger.error("data_logger read failed: %s", ex)
            await asyncio.sleep(30)
            continue

        if (
            "_native_link_outage_since" in live
            or live.get("_managed_telemetry_recovery_pending") is True
        ):
            # Reconnect or delayed ordinary/transition callback evidence.
            # Defer controller decisions without treating partial data as a
            # healthy heartbeat; the existing 300s guard owns the timeout.
            logger.info("Native link recovering; charge controller tick deferred")
            await asyncio.sleep(30)
            continue

        last_ha_ok_time = time.time()
        link_failure_streak = 0
        link_lost_alert_sent = False
        soft_watchdog_outage_reported = False
        try:
            battery_v = _safe_float(live.get("battery_voltage"))
            output_v = _safe_float(live.get("voltage"))
            i = _safe_float(live.get("current"))
            p = _safe_float(live.get("power"))
            temp_ext = live.get("temp_ext")
            t = _safe_float(temp_ext)
            ah = _safe_float(live.get("ah"))
            try:
                _log_temperature_source_if_changed(
                    live, stage=charge_controller.current_stage,
                    voltage=battery_v, current=i, temperature=temp_ext, ah=ah,
                    session_id=getattr(charge_controller, "_v2_trace_session_id", None),
                )
            except Exception as exc:
                # Observability is best-effort. It must not interrupt the
                # established safety/charge control path.
                logger.warning("TEMP_SOURCE journal unavailable: %s", type(exc).__name__)
            is_cv = _canonical_bool(live, "is_cv")
            is_cc = _canonical_bool(live, "is_cc")
            output_switch = live.get("switch")
            output_on = str(output_switch or "").lower() == "on"
            ovp_triggered = _canonical_bool(live, "ovp_triggered")
            ocp_triggered = _canonical_bool(live, "ocp_triggered")
            battery_mode = str(live.get("battery_mode", "")).lower() == "on"
            input_voltage = _safe_float(live.get("input_voltage"), 0.0)
            temp_int = _safe_float(live.get("temp_int"), 0.0)
            manual_manager = globals().get("manual_session_manager")
            manual_request = getattr(manual_manager, "request", None)
            manual_active = bool(getattr(manual_manager, "is_active", False) and manual_request)
            mode = (
                getattr(manual_request, "operation_mode_label", "Ручной")
                if manual_active
                else ("CV" if is_cv else ("CC" if is_cc else "режим не подтверждён"))
            )
            last_live_context = (
                f"📊 Факт: V {battery_v:.2f}В | I {i:.2f}А | T {t:.1f}°C | "
                f"режим {mode}"
            )
            
            # v2.5 Умный watchdog: обновляем последнее известное состояние выхода
            if output_switch is not None and str(output_switch).lower() not in ("unavailable", "unknown", ""):
                charge_controller._last_known_output_on = (
                    output_switch is True or str(output_switch).lower() == "on"
                )
            # Фактические уставки прибора — для сохранения в сессию (восстановление после перезапуска/потери связи)
            set_v = _safe_float(live.get("set_voltage"))
            set_i = _safe_float(live.get("set_current"))
            if set_v > 0 and set_i > 0:
                charge_controller._device_set_voltage = set_v
                charge_controller._device_set_current = set_i
            
            # Синхронизация с прибором только при малом расхождении (чтобы не затирать новую сессию)
            _sync_total_start_from_uptime(
                charge_controller,
                live,
                max_drift_sec=UPTIME_SYNC_MAX_DRIFT_SEC,
                allow_init=False,
            )
            
            # Protection policy owns the trip decision; this runtime only
            # dispatches the established journal, notification and OFF effects.
            protection_decision = evaluate_live_protection(
                charge_active=charge_controller.is_active,
                output_on=output_on,
                ovp_triggered=ovp_triggered,
                ocp_triggered=ocp_triggered,
                internal_temperature_c=temp_int,
                precritical_temperature_c=TEMP_INT_PRECRITICAL,
            )
            if "OVP_TRIGGERED" in protection_decision.triggers:
                log_event(charge_controller.current_stage, battery_v, i, t, ah, "OVP_TRIGGERED")
                _charge_notify("🛑 Сработала защита OVP (перенапряжение). Выход выключен.")
            if "OCP_TRIGGERED" in protection_decision.triggers:
                log_event(charge_controller.current_stage, battery_v, i, t, ah, "OCP_TRIGGERED")
                _charge_notify("🛑 Сработала защита OCP (переток). Выход выключен.")
            if ("OVP_TRIGGERED" in protection_decision.triggers
                    or "OCP_TRIGGERED" in protection_decision.triggers):
                await _hard_stop_charge()

            if "TEMP_INT_PRECRITICAL" in protection_decision.triggers:
                log_event(
                    charge_controller.current_stage,
                    battery_v,
                    i,
                    t,
                    ah,
                    f"TEMP_INT_PRECRITICAL_{temp_int:.0f}C",
                )
                _charge_notify(
                    f"🌡 Температура блока {temp_int:.0f}°C ≥ {TEMP_INT_PRECRITICAL:.0f}°C. "
                    "Выход выключен для защиты БП."
                )
                await _hard_stop_charge()

            # Команда off: выключить по напряжению / току / таймеру (защиты не отключаются)
            if output_on and _has_manual_off_condition():
                now_ts = time.time()
                off_reason = None
                # «Достигли» V: оба порога заданы и равны — выкл при |V - value| <= eps
                if (
                    manual_off_voltage is not None
                    and manual_off_voltage_le is not None
                    and abs(manual_off_voltage - manual_off_voltage_le) < 0.01
                ):
                    if abs(battery_v - manual_off_voltage) <= OFF_REACH_EPS:
                        off_reason = f"напряжение достигло {manual_off_voltage:.2f} В (сейчас {battery_v:.2f} В)"
                elif manual_off_voltage is not None and battery_v >= manual_off_voltage:
                    off_reason = f"напряжение {battery_v:.2f} В ≥ {manual_off_voltage:.1f} В"
                elif manual_off_voltage_le is not None and battery_v <= manual_off_voltage_le:
                    off_reason = f"напряжение {battery_v:.2f} В ≤ {manual_off_voltage_le:.1f} В"
                # «Достигли» I: оба порога заданы и равны — выкл при |I - value| <= eps
                if off_reason is None:
                    if (
                        manual_off_current is not None
                        and manual_off_current_ge is not None
                        and abs(manual_off_current - manual_off_current_ge) < 0.01
                    ):
                        if abs(i - manual_off_current) <= OFF_REACH_EPS:
                            off_reason = f"ток достиг {manual_off_current:.2f} А (сейчас {i:.2f} А)"
                    elif manual_off_current is not None and i <= manual_off_current:
                        off_reason = off_reason or f"ток {i:.2f} А ≤ {manual_off_current:.2f} А"
                    elif manual_off_current_ge is not None and i >= manual_off_current_ge:
                        off_reason = off_reason or f"ток {i:.2f} А ≥ {manual_off_current_ge:.2f} А"
                if manual_off_time_sec is not None and (now_ts - manual_off_start_time) >= manual_off_time_sec:
                    off_reason = off_reason or f"таймер {manual_off_time_sec / 3600:.1f} ч"
                if off_reason:
                    log_event(charge_controller.current_stage, battery_v, i, t, ah, f"MANUAL_OFF_{off_reason[:30]}")
                    _charge_notify(f"⏹ Выключено по условию: {off_reason}")
                    await _hard_stop_charge()
                    _clear_manual_off()
            
            await add_record(battery_v, i, p, t)

            # Explicit operator pause: keep telemetry/safety monitoring alive, but
            # never let recovery, controller ticks or link restoration re-energize
            # the Output until the operator explicitly resumes the session.
            if _operator_pause_active():
                if output_on:
                    logger.warning("Operator pause found Output ON; forcing verified OFF")
                    await _runtime_execution_port().request_verified_off()
                await asyncio.sleep(30)
                continue

            # All normal restore/state changes and subsequent tick/action
            # share the same app owner. Verified emergency OFF remains outside.
            async with _runtime_execution_port()._guard_owner_lock:
                # Восстановление после потери связи: нет OVP/OCP, вход ≥ 60 В
                # (battery_mode не требуем — после потери связи мы сами выключили
                # выход).  An active in-memory session is resumed in place; only an
                # IDLE session goes through persisted-session reconstruction.
                # First fresh observation after process start cannot authorize a
                # persisted-session Output ON. Actual later link recovery is distinct.
                cold_start = not getattr(charge_controller, "_d125_startup_observation_seen", False)
                charge_controller._d125_startup_observation_seen = True
                recovery_route = choose_recovery_route(RecoveryRouteInput(
                    was_unavailable=charge_controller._was_unavailable,
                    stage=charge_controller.current_stage,
                    idle_stage=charge_controller.STAGE_IDLE,
                    done_stage=charge_controller.STAGE_DONE,
                    cooling_stage=getattr(charge_controller, "STAGE_COOLING", "__no_cooling__"),
                    output_on=output_on,
                    current_a=i,
                    temperature_available=(
                        temp_ext is not None and temp_ext not in ("unavailable", "unknown", "")
                    ),
                ))
                # Resolve the current app-scoped port only for a recovery action
                # and inside the same lock as the controller/session transition.
                # Do not cache it across a later physical owner rebind.
                if recovery_route is not RecoveryRoute.NONE:
                    recovery_execution = SessionRecoveryService(
                        _runtime_execution_port(), _apply_phase_protection, _cap_current
                    )
                recovery_guard = _runtime_execution_port().session_recovery_guard
                if recovery_guard.quarantined:
                    logger.warning(
                        "D084 session recovery quarantine remains active (%s); "
                        "automatic restore and controller tick are suppressed",
                        recovery_guard.state.reason,
                    )
                elif recovery_route is RecoveryRoute.ACTIVE_LINK and authorize_recovery_action(
                    RecoveryAuthorizationInput(
                        route=recovery_route,
                        restored=True,
                        auto_enable_authorized=True,
                        cold_start=cold_start,
                        safe_wait=False,
                        ovp_triggered=ovp_triggered,
                        ocp_triggered=ocp_triggered,
                        input_voltage_ok=input_voltage >= MIN_INPUT_VOLTAGE,
                    )
                ) is RecoveryAction.REENABLE_ACTIVE:
                    uv, ui = charge_controller._get_target_v_i(t)
                    enabled = await recovery_execution.reenable_active(uv, ui)
                    if enabled:
                        output_on = True
                        charge_controller._last_known_output_on = True
                        _apply_restore_time_corrections(charge_controller, live)
                        last_checkpoint_time = time.time()
                        log_event(charge_controller.current_stage, battery_v, i, t, ah, "RESTORE")
                        _charge_notify(
                            "✅ Связь восстановлена, заряд продолжен с текущего этапа.",
                            critical=False,
                        )
                        logger.info(
                            "Active session resumed after link recovery: %s",
                            charge_controller.current_stage,
                        )
                    else:
                        reason = recovery_guard.state.reason or "verified_on"
                        logger.warning(
                            "D084 quarantined active session restore (%s); physical Output state is unknown",
                            reason,
                        )
                        _charge_notify(
                            "⚠️ Восстановление не подтверждено; автоматическое управление "
                            "приостановлено, состояние Output неизвестно. Проверьте оборудование."
                        )
                elif not recovery_guard.quarantined and recovery_route is RecoveryRoute.IDLE_LINK:
                    ok, msg = charge_controller.try_restore_session(
                        battery_v, i, ah, output_is_on=output_on,
                        is_cv=is_cv, is_cc=is_cc,
                    )
                    if ok and msg:
                        _apply_restore_time_corrections(charge_controller, live)
                        action = authorize_recovery_action(RecoveryAuthorizationInput(
                            route=recovery_route,
                            restored=True,
                            auto_enable_authorized=_restore_allows_auto_enable(charge_controller),
                            cold_start=cold_start,
                            safe_wait=charge_controller.current_stage == charge_controller.STAGE_SAFE_WAIT,
                            ovp_triggered=ovp_triggered,
                            ocp_triggered=ocp_triggered,
                            input_voltage_ok=input_voltage >= MIN_INPUT_VOLTAGE,
                        ))
                        if action is not RecoveryAction.SKIP:
                            if action is RecoveryAction.SAFE_WAIT_OFF:
                                uv, ui = charge_controller._safe_wait_target_v, charge_controller._safe_wait_target_i
                            else:
                                uv, ui = charge_controller._get_target_v_i(t)
                            result = await recovery_execution.restore_idle_link(
                                uv, ui, safe_wait=action is RecoveryAction.SAFE_WAIT_OFF
                            )
                            if not result.confirmed:
                                logger.warning(
                                    "Session restore execution was not confirmed (%s); "
                                    "physical Output state is unknown",
                                    result.failed_step,
                                )
                                _charge_notify(
                                    "⚠️ Действие восстановления не подтверждено "
                                    f"({result.failed_step}); состояние Output неизвестно. "
                                    "Проверьте состояние оборудования."
                                )
                            else:
                                last_checkpoint_time = time.time()
                                log_event(
                                    charge_controller.current_stage,
                                    battery_v,
                                    i,
                                    t,
                                    ah,
                                    "RESTORE",
                                )
                                _charge_notify("✅ Связь восстановлена, действие подтверждено.\n" + (msg or ""), critical=False)
                                logger.info("Session restored after link recovery: %s", charge_controller.current_stage)
                        else:
                            if ovp_triggered or ocp_triggered:
                                _charge_notify(
                                    "⚠️ Недавно сработала защита OVP/OCP. "
                                    "Включите заряд вручную после проверки."
                                )
                            elif input_voltage < MIN_INPUT_VOLTAGE:
                                _charge_notify(
                                    f"⚠️ Низкое входное напряжение ({input_voltage:.0f} В < {MIN_INPUT_VOLTAGE:.0f} В). "
                                    "Включите заряд вручную после проверки питания."
                                )
                            logger.info("Restore skipped: protections or input_voltage")
                    else:
                        # Нет файла сессии или старше 24 ч — выход может быть всё ещё вкл
                        if output_on and i > 0.05:
                            _charge_notify(
                                "⚠️ Связь восстановлена, но сессии нет (или старше 24 ч). "
                                f"Выход включён ({i:.2f} А). Нажмите Остановить или запустите заряд заново."
                            )
                            logger.warning("Link restored but no session; output still on I=%.2fA", i)

                # Выход уже включён, но бот в IDLE (перезапуск бота или ручное включение) — подхватываем сессию без turn_on
                if (not recovery_guard.quarantined and recovery_route is RecoveryRoute.IDLE_OUTPUT_ON
                        and os.path.isfile(SESSION_FILE)):
                    ok, msg = charge_controller.try_restore_session(
                        battery_v, i, ah, output_is_on=output_on,
                        is_cv=is_cv, is_cc=is_cc,
                    )
                    if ok and msg:
                        _apply_restore_time_corrections(charge_controller, live)
                        action = authorize_recovery_action(RecoveryAuthorizationInput(
                            route=recovery_route,
                            restored=True,
                            auto_enable_authorized=_restore_allows_auto_enable(charge_controller),
                            cold_start=cold_start,
                            safe_wait=charge_controller.current_stage == charge_controller.STAGE_SAFE_WAIT,
                            ovp_triggered=ovp_triggered,
                            ocp_triggered=ocp_triggered,
                            input_voltage_ok=input_voltage >= MIN_INPUT_VOLTAGE,
                        ))
                        if action is not RecoveryAction.SKIP:
                            if action is RecoveryAction.SAFE_WAIT_OFF:
                                uv, ui = charge_controller._safe_wait_target_v, charge_controller._safe_wait_target_i
                            else:
                                uv, ui = charge_controller._get_target_v_i(t)
                            result = await recovery_execution.restore_output_on(
                                uv, ui, safe_wait=action is RecoveryAction.SAFE_WAIT_OFF
                            )
                            if not result.confirmed:
                                logger.warning(
                                    "Already-on session restore was not confirmed (%s); "
                                    "physical Output state is unknown",
                                    result.failed_step,
                                )
                                _charge_notify(
                                    "⚠️ Действие восстановления не подтверждено "
                                    f"({result.failed_step}); состояние Output неизвестно. "
                                    "Проверьте состояние оборудования."
                                )
                            else:
                                last_checkpoint_time = time.time()
                                log_event(
                                    charge_controller.current_stage,
                                    battery_v,
                                    i,
                                    t,
                                    ah,
                                    "RESTORE",
                                )
                                _charge_notify(
                                    "✅ Сессия восстановлена; параметры применены. "
                                    "Output ON отдельно не подтверждался.",
                                    critical=False,
                                )
                                logger.info("Session restore parameters applied (Output was not re-confirmed): %s", charge_controller.current_stage)
                        else:
                            logger.debug("Restore (output on, idle) skipped: allow=%s ovp=%s ocp=%s input_v=%.0f", action is not RecoveryAction.SKIP, ovp_triggered, ocp_triggered, input_voltage)
                    else:
                        logger.debug("Restore (output on, idle): try_restore_session returned ok=%s (нет файла или сессия старше 24 ч)", ok)

                now_ts = time.time()
                # Hold the same app-wide normal execution owner from the
                # controller decision/session checkpoint through the resulting
                # physical action. Emergency verified OFF remains independent.
                async with _runtime_execution_port()._guard_owner_lock:
                    prev_stage = charge_controller.current_stage
                    # Observation-only D073 hook. Session identity is supplied
                    # only by an explicit accepted-session owner; absent that
                    # proof this is a no-op and never creates a journal.
                    # The UI/legacy switch is not authoritative Guard
                    # evidence. Require real native Output register 18 and
                    # measured current with independent fresh source metadata.
                    native_guard_fresh = (
                        isinstance(live.get("_meta"), dict)
                        and telemetry_freshness(
                            live, ("output_state_code_v2", "current"),
                            max_age_s=10.0, max_skew_s=10.0,
                        ).valid
                    )
                    native_output_code = finite_float(live.get("output_state_code_v2"))
                    native_current = finite_float(live.get("current"))
                    native_on = (
                        (native_output_code == 1)
                        if native_guard_fresh and native_output_code in (0, 1)
                        else None
                    )
                    # Accepted MAIN identity is not a runtime-private hint:
                    # compare the canonical durable session, its recipe and
                    # fresh physical Iset readback while holding the common owner.
                    canonical_main_session = read_canonical_session(SESSION_FILE)
                    admission = admit_main_guard_shadow(
                        controller=charge_controller,
                        session_document=canonical_main_session,
                        live=live, now_epoch_s=now_ts,
                    )
                    if admission is None:
                        _main_guard_shadow.invalidate_evidence(now_s=time.monotonic())
                        # Persist only a conservative continuity break when
                        # this is still the exact guarded MAIN epoch. The
                        # reconciliation rejects pending/faulted or mismatched
                        # guard state, so missing/foreign telemetry cannot
                        # reset the session or broaden its Iset ceiling.
                        if (charge_controller.current_stage == charge_controller.STAGE_MAIN
                                and str(charge_controller.battery_type).strip().upper()
                                in ("EFB", "CA/CA")):
                            persisted_revision = None
                            if (isinstance(canonical_main_session, dict)
                                    and "main_current_guard_v1" in canonical_main_session):
                                try:
                                    from runtime.charge.strategy.main_guard_session import read_guard
                                    _, persisted_revision = read_guard(
                                        canonical_main_session,
                                        session_id=str(getattr(charge_controller, "_v2_trace_session_id", "")),
                                        battery_id=str(getattr(charge_controller, "_v2_battery_id", "")),
                                        now_s=time.monotonic(),
                                    )
                                except (ValueError, TypeError):
                                    persisted_revision = None
                            _main_guard_shadow.reconcile_checkpoint(
                                charge_controller,
                                session_id=getattr(charge_controller, "_v2_trace_session_id", None),
                                battery_id=getattr(charge_controller, "_v2_battery_id", None),
                                persisted_revision=persisted_revision,
                            )
                    else:
                        _main_guard_shadow.bind_new_canonical_session(
                            session_id=admission.session_id,
                            battery_id=admission.battery_id,
                            unguarded_document_proven=(
                                getattr(charge_controller, "_main_current_guard", None) is None
                            ),
                        )
                        _main_guard_shadow.seed_from_controller(
                            charge_controller,
                            session_id=admission.session_id,
                            battery_id=admission.battery_id,
                        )
                        main_proposal = _main_guard_shadow.observe(
                            now_s=time.monotonic(),
                            session_id=admission.session_id,
                            battery_id=admission.battery_id,
                            chemistry=str(charge_controller.battery_type),
                            capacity_ah=admission.capacity_ah,
                            recipe_current_a=admission.recipe_initial_current_a,
                            stage="MAIN",
                            output_on=native_on,
                            output_current_a=native_current if native_guard_fresh else None,
                            fresh=bool(native_guard_fresh and native_on is not None and native_current is not None),
                        )
                        if main_proposal is None:
                            _main_guard_shadow.reconcile_checkpoint(
                                charge_controller,
                                session_id=admission.session_id,
                                battery_id=admission.battery_id,
                                persisted_revision=admission.guard_revision,
                            )
                        if (main_proposal is not None and not manual_active
                                and not _has_manual_off_condition()):
                            outcome = await execute_due_main_guard(
                                app=sys.modules[__name__],
                                port=_runtime_execution_port(),
                                admission=admission,
                                shadow=_main_guard_shadow,
                                proposal=main_proposal,
                                session_path=SESSION_FILE,
                            )
                            if outcome is not None:
                                if outcome.verified:
                                    logger.info(
                                        "MAIN Guard Iset reduced and journaled: %.2f A",
                                        outcome.guard.hardware_limit_a,
                                    )
                                else:
                                    logger.warning(
                                        "MAIN Guard reduction not verified: %s; OFF=%s; diagnostic=%s",
                                        outcome.reason, outcome.off_confirmed,
                                        outcome.diagnostic,
                                    )
                    actions = (await run_charge_session_tick(
                        charge_controller,
                        battery_v, i, temp_ext, is_cv, ah, output_switch,
                        manual_off_active=_has_manual_off_condition(),
                        is_cc=is_cc,
                        manual_active=manual_active,
                    ) if _runtime_execution_port().session_recovery_guard.may_run_automatic_control() else {})
                    if actions.get("notify"):
                        _charge_notify(str(actions["notify"]))
                    if prev_stage != charge_controller.current_stage:
                        log_event(
                            charge_controller.current_stage,
                            battery_v,
                            i,
                            t,
                            ah,
                            f"STAGE_CHANGE | {prev_stage} -> {charge_controller.current_stage}",
                        )

                    end = actions.get("log_event_end")
                    if end:
                        log_stage_end(
                            end["stage"],
                            end["v"],
                            end["i"],
                            end["t"],
                            end["ah"],
                            end["time_sec"],
                            end["ah_on_stage"],
                            end["trigger"],
                        )
                    if actions.get("log_event_sub"):
                        log_event(
                            end["stage"] if end else charge_controller.current_stage,
                            battery_v,
                            i,
                            t,
                            ah,
                            actions["log_event_sub"],
                        )
                    if actions.get("log_event"):
                        event_name = str(actions["log_event"])
                        if not _should_skip_noisy_log_event(charge_controller.current_stage, event_name, now_ts):
                            log_event(
                                charge_controller.current_stage,
                                battery_v,
                                i,
                                t,
                                ah,
                                event_name,
                            )

                    if charge_controller.is_active and (now_ts - last_checkpoint_time >= 600):
                        log_checkpoint(charge_controller.current_stage, battery_v, i, t, ah)
                        if charge_controller.current_stage == charge_controller.STAGE_MIX:
                            try:
                                progress = mix_progress_event(
                                    live,
                                    getattr(charge_controller, "_v2_session_signal_context", None),
                                    stage=charge_controller.STAGE_MIX,
                                    session_id=getattr(charge_controller, "_v2_trace_session_id", None),
                                    now_s=now_ts,
                                    max_age_s=float(WATCHDOG_TIMEOUT_S.default),
                                    hold_started_at=getattr(charge_controller, "finish_timer_start", None),
                                )
                                log_event(charge_controller.current_stage, battery_v, i, t, ah, progress)
                            except Exception as exc:
                                logger.warning("MIX_PROGRESS journal unavailable: %s", type(exc).__name__)
                        last_checkpoint_time = now_ts
                    
                    # Очистка БД и журнала событий каждые 24 часа (записи старше 30 дней)
                    if now_ts - last_cleanup_time >= 86400:  # 24 часа
                        await cleanup_old_records()
                        try:
                            rotate_if_needed()
                            trim_log_older_than_days(30)
                        except Exception as ex:
                            logger.warning("trim_log_older_than_days: %s", ex)
                        last_cleanup_time = now_ts

                    if actions.get("emergency_stop"):
                        await _runtime_execution_port().request_verified_off()
                        await _apply_idle_protection()
                        if actions.get("full_reset"):
                            charge_controller.full_reset()
                        # иначе контроллер уже сделал stop(clear_session=False) — сессия сохранена для restore при возврате связи
                    elif charge_controller.is_active:
                        await _apply_controller_output_actions(
                            actions,
                            live,
                            battery_v=battery_v,
                            current=i,
                            temp=t,
                            ah=ah,
                        )

        except Exception as ex:
            err_str = str(ex).lower()
            if _is_recoverable_link_boundary_error(ex):
                link_failure_streak += 1
                charge_controller._was_unavailable = True
                charge_controller._link_lost_at = time.time()
                if (
                    charge_controller._last_known_output_on
                    and link_failure_streak >= LINK_FAILURE_NOTIFY_THRESHOLD
                    and not link_lost_alert_sent
                ):
                    _charge_notify("🚨 Связь с RD6018 не восстановилась после "
                                   f"{link_failure_streak} попыток. Аппаратный lease остаётся последним рубежом.")
                    link_lost_alert_sent = True
                logger.warning(
                    "ESPHome transport outage during cycle #%d; no host STOP sent: %s",
                    link_failure_streak,
                    ex,
                )
                await asyncio.sleep(30)
                continue
            if "name resolution" in err_str or "dns" in err_str or "nodename" in err_str:
                logger.warning("data_logger (DNS/сеть): %s", ex)
            else:
                logger.error("data_logger: %s", ex)
            
            # v2.5 Умный watchdog: поведение зависит от последнего состояния выхода
            output_was_on = charge_controller._last_known_output_on
            charge_controller._was_unavailable = True
            charge_controller._link_lost_at = time.time()

            if not output_was_on:
                # Выход был выключен — тихий переход в IDLE, без уведомлений
                if charge_controller.is_active:
                    charge_controller.stop(clear_session=False)
                    logger.info("Link lost with output OFF: quiet transition to IDLE")
            else:
                # Выход был включён — однократное уведомление и аварийное отключение
                if not link_lost_alert_sent:
                    _charge_notify("🚨 Связь потеряна во время активного заряда!")
                    link_lost_alert_sent = True
                    logger.critical("Link lost during active charge: emergency shutdown")
                
                try:
                    off_confirmed = await _runtime_execution_port().request_verified_off()
                    if not off_confirmed:
                        raise RuntimeError('emergency OFF was not verified')
                    await _apply_idle_protection()
                except Exception as off_exc:
                    logger.exception('LINK_LOST_EMERGENCY_OFF_FAILED; session retained: %s', off_exc)
                    await asyncio.sleep(30)
                    continue

                if charge_controller.is_active:
                    charge_controller.stop(clear_session=False)
                    log_event(
                        "EMERGENCY",
                        0.0,
                        0.0,
                        0.0,
                        0.0,
                        "LINK_LOST_DURING_CHARGE",
                    )
        await asyncio.sleep(30)


# --- Handlers ---


async def get_ai_context() -> str:
    """Получить полный слепок данных RD6018 для AI анализа."""
    try:
        live = await hass.get_all_live()
        
        # Электрические параметры
        v_out = _safe_float(live.get("voltage", 0.0))
        i_out = _safe_float(live.get("current", 0.0))
        p_out = _safe_float(live.get("power", 0.0))
        v_batt = _safe_float(live.get("battery_voltage", 0.0))
        
        # Счетчики
        ah = _safe_float(live.get("ah", 0.0))
        wh = _safe_float(live.get("wh", 0.0))
        
        # Уставки
        v_set = _safe_float(live.get("set_voltage", 0.0))
        i_set = _safe_float(live.get("set_current", 0.0))
        ovp = _safe_float(live.get("ovp", 0.0))
        ocp = _safe_float(live.get("ocp", 0.0))
        
        # Статусы
        output_on = str(live.get("switch", "")).lower() == "on"
        cv_mode = _canonical_bool(live, "is_cv")
        cc_mode = _canonical_bool(live, "is_cc")
        battery_mode = not output_on  # Режим батареи = выход выключен
        
        # Температуры
        t_internal = _safe_float(live.get("temp_int", 0.0))
        t_external = _safe_float(live.get("temp_ext", 0.0))
        
        # Системные параметры (если доступны в HA)
        v_input = _safe_float(live.get("input_voltage", 0.0)) or 0.0  # Может отсутствовать
        uptime = live.get("uptime", "неизвестно")
        
        # Данные контроллера заряда
        controller_info = ""
        capacity_known = False
        capacity_ah = 0
        controller_snapshot = {
            "stage": "Idle",
            "profile": "UNKNOWN",
            "is_active": False,
            "summary": "Активный заряд не идет.",
            "transition": "Активный переход отсутствует.",
            "next_stage": "Idle",
            "timers": {"total_time": "—", "stage_time": "—", "remaining_time": "—"},
            "hold": None,
            "safety": {},
            "target_voltage": 0.0,
            "target_current": 0.0,
        }
        recent_events = get_recent_events(8)
        if charge_controller.is_active:
            timers = charge_controller.get_timers()
            capacity_ah = int(getattr(charge_controller, "ah_capacity", 0) or 0)
            capacity_known = capacity_ah > 0
            controller_info = f"""
Контроллер заряда:
- Активный этап: {charge_controller.current_stage}
- Тип АКБ: {charge_controller.battery_type}
- Заданная емкость: {capacity_ah}Ач
- Общее время: {timers['total_time']}
- Время этапа: {timers['stage_time']}
- Лимит этапа: {timers['remaining_time']}"""
        controller_snapshot = _safe_stage_snapshot(t_external)

        controller_info += f"""

Карточка стратегии:
{format_ai_snapshot(controller_snapshot)}"""
        if recent_events:
            controller_info += f"""

Последние важные события:
{format_recent_events(recent_events, limit=8)}"""
        output_status = "ON" if output_on else "OFF"
        
        # Формируем полный контекст
        context = f"""ПОЛНЫЙ СЛЕПОК RD6018:

Статус выхода: {output_status} (включен/выключен)
Емкость известна: {"да" if capacity_known else "нет"}
Емкость АКБ: {capacity_ah if capacity_known else "UNKNOWN"} Ач

Электрика:
- Напряжение на выходе: {v_out:.3f}В
- Ток нагрузки: {i_out:.3f}А
- Мощность: {p_out:.2f}Вт
- Напряжение на клеммах АКБ: {v_batt:.3f}В

Счетчики:
- Накопленная емкость: {ah:.3f} Ач
- Накопленная энергия: {wh:.2f} Вч

Уставки:
- Целевое напряжение: {v_set:.2f}В
- Лимит тока: {i_set:.2f}А
- Защита перенапряжения: {ovp:.1f}В
- Защита перетока: {ocp:.1f}А

Статусы:
- Выход включен: {'да' if output_on else 'нет'}
- Режим стабилизации напряжения: {'да' if cv_mode else 'нет'}
- Режим стабилизации тока: {'да' if cc_mode else 'нет'}
- Режим измерения АКБ: {'да' if battery_mode else 'нет'}

Температура:
- Температура блока: {t_internal:.1f}°C
- Температура АКБ: {t_external:.1f}°C

Система:
- Входное напряжение БП: {v_input:.1f}В
- Время работы: {uptime}{controller_info}"""
        
        # Последние события из лога
        from charging_log import get_recent_events
        recent_events = get_recent_events(5)
        if recent_events:
            context += "\n\nПоследние события:\n"
            for event in recent_events:
                context += f"- {event}\n"
        
        return context
    except Exception as ex:
        return f"Ошибка получения AI контекста: {ex}"


async def get_ai_context_dict() -> Dict[str, Any]:
    """Return the structured AI context expected by the legacy AI engine.

    The dialog already builds its human-readable context separately.  This
    compatibility shape is intentionally read-only and fails closed to
    explicit UNKNOWN values when telemetry or a controller snapshot is absent.
    """
    unknown: Dict[str, Any] = {
        "output_status": "UNKNOWN",
        "current_stage": "UNKNOWN",
        "battery_type": "UNKNOWN",
        "mode": "UNKNOWN",
        "capacity_ah": "UNKNOWN",
        "capacity_known": False,
        "remaining_time": "—",
        "v_batt_now": None,
        "i_now": None,
        "temp_ext_now": None,
        "temp_int_now": None,
    }
    try:
        live = await hass.get_all_live()
        snapshot = _safe_stage_snapshot(_safe_float(live.get("temp_ext"))) or {}
        capacity = getattr(charge_controller, "ah_capacity", 0) or 0
        capacity_known = float(capacity) > 0
        return {
            **unknown,
            "output_status": "ON" if str(live.get("switch", "")).lower() == "on" else "OFF",
            "current_stage": snapshot.get("stage", getattr(charge_controller, "current_stage", "UNKNOWN")),
            "battery_type": snapshot.get("profile", getattr(charge_controller, "battery_type", "UNKNOWN")),
            "mode": snapshot.get("phase", "UNKNOWN"),
            "capacity_ah": int(capacity) if capacity_known else "UNKNOWN",
            "capacity_known": capacity_known,
            "remaining_time": (snapshot.get("timers") or {}).get("remaining_time", "—"),
            "v_batt_now": _safe_float(live.get("battery_voltage")),
            "i_now": _safe_float(live.get("current")),
            "temp_ext_now": _safe_float(live.get("temp_ext")),
            "temp_int_now": _safe_float(live.get("temp_int")),
        }
    except Exception as ex:
        logger.warning("get_ai_context_dict: unavailable: %s", ex)
        return unknown


async def get_current_context_for_llm() -> str:
    """v2.6 Получить расширенный контекст для LLM: таймеры, параметры RD6018, события."""
    # Используем новую функцию для обратной совместимости
    return await get_ai_context()


# Порог «достигли» для выключения по V или I (с любой стороны)
OFF_REACH_EPS = 0.02


def _parse_three_values(text: str) -> Optional[Dict[str, Any]]:
    """
    Парсит строку из трёх частей: V I и третья — таймер H:MM, ток X.XXA/А, или напряжение X.XV/В.
    Возвращает dict с v, i и одним из: time_sec, off_current, off_voltage; иначе None.
    """
    parts = (text or "").strip().replace(",", ".").split()
    if len(parts) != 3:
        return None
    try:
        v = float(parts[0])
        i = float(parts[1])
        third = parts[2].strip().upper().rstrip("AАВV")
        if not third:
            return None
        # Таймер: 2:35 или 2:35:00
        if ":" in parts[2]:
            comp = parts[2].split(":")
            if len(comp) == 2:
                h, m = int(comp[0].strip()), int(comp[1].strip())
                time_sec = h * 3600 + m * 60
            elif len(comp) == 3:
                h, m, s = int(comp[0].strip()), int(comp[1].strip()), int(comp[2].strip())
                time_sec = h * 3600 + m * 60 + s
            else:
                return None
            if time_sec <= 0:
                return None
            return {"v": v, "i": i, "time_sec": time_sec}
        # Ток: 2.35A / 2.35А (латиница или кириллица) — выкл по достижении тока
        raw3 = parts[2].strip().replace(",", ".")
        last_char = (raw3[-1].upper() if len(raw3) > 1 else "")
        if last_char in ("A", "А"):  # A (Latin) или А (Cyrillic)
            val = float(third)
            if 0.1 <= val <= MAX_STAGE_CURRENT:
                return {"v": v, "i": i, "off_current": val}
            return None
        # Напряжение: 15V / 15В (латиница или кириллица) — выкл по достижении напряжения
        if last_char in ("V", "В"):  # V (Latin) или В (Cyrillic)
            val = float(third)
            if 0 <= val <= 20.0:
                return {"v": v, "i": i, "off_voltage": val}
            return None
    except (ValueError, IndexError):
        pass
    return None


def _parse_two_numbers(text: str) -> Optional[tuple]:
    """Парсит строку вида '16.50 1.4' (напряжение и ток). Возвращает (v, i) или None."""
    parts = (text or "").strip().replace(",", ".").split()
    if len(parts) != 2:
        return None
    try:
        v = float(parts[0])
        i = float(parts[1])
        return (v, i)
    except ValueError:
        return None


@router.message(F.text & ~F.text.startswith("/"))
async def text_message_handler(message: Message) -> None:
    """v2.6 Обработка текстовых сообщений: ввод ёмкости АКБ, ручной режим или режим диалога с LLM."""
    if not await _check_chat_and_respond(message):
        return
    global awaiting_ah, custom_mode_state, last_chat_id, last_checkpoint_time
    global manual_off_voltage, manual_off_voltage_le, manual_off_current, manual_off_current_ge, manual_off_time_sec, manual_off_start_time
    user_id = message.from_user.id if message.from_user else 0
    text = (message.text or "").strip()

    # Команды вида /help, /start и т.п. не должны попадать в LLM-диалог.
    if text.startswith("/"):
        return

    # Команда off: выключить по напряжению / току / таймеру (вне ручного режима)
    if not (user_id in custom_mode_state or awaiting_ah.get(user_id)):
        off_parsed = _parse_off_command(text)
        if off_parsed is not None:
            manual_off_voltage = off_parsed.get("voltage_ge")
            manual_off_voltage_le = off_parsed.get("voltage_le")
            manual_off_current = off_parsed.get("current_le")
            manual_off_current_ge = off_parsed.get("current_ge")
            manual_off_time_sec = off_parsed.get("time_sec")
            manual_off_start_time = off_parsed["start_time"]
            _save_manual_off_state()
            cond = ", ".join(off_parsed["parts"])
            await message.answer(
                f"✅ <b>Выключение по условию:</b> {cond}",
                parse_mode=ParseMode.HTML,
            )
            last_chat_id = message.chat.id

            return
        if text.strip().lower() == "off":
            _clear_manual_off()
            await message.answer("Сброс условия выключения. Уставки «off» больше не активны.")
            last_chat_id = message.chat.id

            return

    # Три значения: V I и таймер (2:35), или ток 2.35A/А, или напряжение 15V/В — уставки + условие выключения
    if not (user_id in custom_mode_state or awaiting_ah.get(user_id)):
        three = _parse_three_values(text)
        if three is not None:
            v_set, i_set = three["v"], three["i"]
            if 12.0 <= v_set <= 17.0 and 0.1 <= i_set <= MAX_STAGE_CURRENT:
                ok_v, ok_i = await _runtime_execution_port().program_voltage_current(
                    v_set, _cap_current(i_set)
                )
                manual_off_voltage = None
                manual_off_voltage_le = None
                manual_off_current = None
                manual_off_current_ge = None
                manual_off_time_sec = None
                if "time_sec" in three:
                    manual_off_time_sec = three["time_sec"]
                    manual_off_start_time = time.time()
                    cond = f"таймер {manual_off_time_sec / 3600:.1f} ч"
                elif "off_current" in three:
                    manual_off_current = three["off_current"]
                    manual_off_current_ge = three["off_current"]
                    cond = f"при достижении тока {three['off_current']:.2f} А"
                else:
                    manual_off_voltage = three["off_voltage"]
                    manual_off_voltage_le = three["off_voltage"]
                    cond = f"при достижении напряжения {three['off_voltage']:.2f} В"
                _save_manual_off_state()
                on_dev = ""
                if ok_v and ok_i:
                    await asyncio.sleep(0.8)
                    live = await hass.get_all_live()
                    on_v = _safe_float(live.get("set_voltage"), 0.0)
                    on_i = _safe_float(live.get("set_current"), 0.0)
                    on_dev = f" На приборе: {on_v:.2f} В | {on_i:.2f} А"
                else:
                    on_dev = " ⚠️ Проверьте уставки на приборе."
                await message.answer(
                    f"✅ Уставки: {v_set:.1f} В, {i_set:.2f} А. Выключение: {cond}.{on_dev}",
                    parse_mode=ParseMode.HTML,
                )
                last_chat_id = message.chat.id

                return
            else:
                await message.answer(f"Диапазоны: напряжение 12–17 В, ток 0.1–{MAX_STAGE_CURRENT:.1f} А.")
                last_chat_id = message.chat.id

                return

    # Быстрая установка уставок: два числа через пробел — напряжение (В) и ток (А)
    # Не перехватываем, если пользователь в диалоге выбора режима или ввода ёмкости
    if not (user_id in custom_mode_state or awaiting_ah.get(user_id)):
        parsed = _parse_two_numbers(text)
        if parsed is not None:
            v_set, i_set = parsed
            if 12.0 <= v_set <= 17.0 and 0.1 <= i_set <= MAX_STAGE_CURRENT:
                ok_v, ok_i = await _runtime_execution_port().program_voltage_current(
                    v_set, _cap_current(i_set)
                )
                if not ok_v or not ok_i:
                    await message.answer(
                        f"⚠️ Ошибка отправки в HA: напряжение — {'ок' if ok_v else 'ошибка'}, ток — {'ок' if ok_i else 'ошибка'}. Проверьте связь с Home Assistant.",
                        parse_mode=ParseMode.HTML,
                    )
                    last_chat_id = message.chat.id

                    return
                await asyncio.sleep(0.8)
                live = await hass.get_all_live()
                on_v = _safe_float(live.get("set_voltage"), 0.0)
                on_i = _safe_float(live.get("set_current"), 0.0)
                tol = 0.02
                match = abs(on_v - v_set) <= tol and abs(on_i - i_set) <= tol
                if match:
                    await message.answer(
                        f"✅ <b>Уставки установлены:</b> {v_set:.2f} В | {i_set:.2f} А\n"
                        f"📟 На приборе: {on_v:.2f} В | {on_i:.2f} А",
                        parse_mode=ParseMode.HTML,
                    )
                else:
                    await message.answer(
                        f"✅ Уставки отправлены в HA: {v_set:.2f} В | {i_set:.2f} А\n"
                        f"📟 На приборе сейчас: {on_v:.2f} В | {on_i:.2f} А\n"
                        "⚠️ Значения на приборе отличаются — проверьте интеграцию RD6018 и связь.",
                        parse_mode=ParseMode.HTML,
                    )
                last_chat_id = message.chat.id

                return
            await message.answer(
                        f"⚠️ Допустимые диапазоны: напряжение 12–17 В, ток 0.1–{MAX_STAGE_CURRENT:.1f} А. Пример: <code>16.50 1.4</code>",
                parse_mode=ParseMode.HTML,
            )

            return

    # Проверяем ручной режим
    if user_id in custom_mode_state:
        await handle_custom_mode_input(message, user_id)
        return
    
    # Если ожидаем ввод ёмкости АКБ
    profile = awaiting_ah.get(user_id)
    if profile:
        await handle_ah_input(message, profile, user_id)
        return
    
    # v2.6 Режим диалога: отправляем сообщение в LLM с контекстом
    await handle_dialog_mode(message)


async def handle_ah_input(message: Message, profile: str, user_id: int) -> None:
    """Обработка ввода ёмкости АКБ после выбора профиля."""
    global awaiting_ah, last_chat_id, last_checkpoint_time
    text = (message.text or "").strip()
    try:
        ah = int(float(text))
        if ah < 1 or ah > 500:
            await message.answer("Введите число от 1 до 500.")

            return
    except ValueError:
        await message.answer("Введите число (например 60).")

        return

    # Production composition routes the legacy text-input continuation through
    # the same V3 START boundary as saved-battery callbacks.  The old body below
    # remains available only for rollback compositions that do not install V3.
    route = globals().get("_v3_production_start_route")
    if route is not None:
        intent = OperatorIntent(
            OperatorIntentKind.START_CHARGE,
            "telegram",
            str(user_id),
            {
                "profile": profile,
                "capacity_ah": ah,
                "battery_identity": None,
                "battery_id": "operator-battery",
                "intent": _pending_intent.get(user_id, ChargeIntent.NORMAL),
                "condition": BatteryCondition.UNKNOWN,
            },
        )
        result = await route.submit(intent)
        if not result.accepted:
            await message.answer(f"START отклонён: {result.reason}", parse_mode=ParseMode.HTML)
            return
        from production_bot_ui import format_start_feedback

        await message.answer(format_start_feedback(result), parse_mode=ParseMode.HTML)
        return

    logger.error(
        "START denied: production start route is not composed; direct legacy START is retired"
    )
    await message.answer(
        "❌ START недоступен: production-маршрут запуска не собран. "
        "Старый прямой запуск отключён.",
        parse_mode=ParseMode.HTML,
    )
    return


async def handle_dialog_mode(message: Message) -> None:
    """v2.6 Режим диалога: отправка сообщения пользователя в LLM с текущим контекстом."""
    if not DEEPSEEK_API_KEY:
        await message.answer("🤖 AI-консультант недоступен (не настроен API ключ)")

        return
    
    user_question = (message.text or "").strip()
    if not user_question:
        return
    
    # Показываем что бот думает
    thinking_msg = await message.answer("🤖 Анализирую данные...")
    
    try:
        # Получаем полный слепок данных RD6018
        context = await get_ai_context()
        
        # Системный промпт для эксперта-аккумуляторщика (из ai_system_prompt.py)
        system_prompt = AI_CONSULTANT_SYSTEM_PROMPT

        user_prompt = f"""=== ПОЛНЫЙ СЛЕПОК RD6018 ===
{context}

=== ВОПРОС ПОЛЬЗОВАТЕЛЯ ===
{user_question}

=== КАК ОТВЕЧАТЬ ===
1. Сначала дай прямой ответ на вопрос.
2. Если вопрос про текущий этап, время на минимальном токе или переход, используй только факты из контекста, hold-снимка и таймеров.
3. Не называй ток "минимальным", если hold-снимок не активен или rule_met = NO.
4. Не делай общих прогнозов и не уходи в рассуждения.
5. Если данных не хватает, скажи это прямо."""
        ai_response = await ask_deepseek({
            "times": [],
            "voltages": [],
            "currents": [],
            "ai_context": await get_ai_context_dict(),
            "controller_snapshot": charge_controller.get_snapshot() if hasattr(charge_controller, 'get_snapshot') else {},
            "recent_events": get_recent_events(8),
            "trend_summary": "",
            "user_question": user_question,
            "system_prompt_override": system_prompt,
            "user_prompt_override": user_prompt,
        })
        
        if ai_response.startswith("ERROR:"):
            await thinking_msg.edit_text(f"🤖 {ai_response}")
        else:
            safe_ai_response = _sanitize_telegram_html(ai_response)
            await thinking_msg.edit_text(
                f"🤖 <b>AI-Консультант:</b>\n\n{safe_ai_response}",
                parse_mode=ParseMode.HTML
            )

    except Exception as ex:
        logger.error("handle_dialog_mode: %s", ex)
        await thinking_msg.edit_text("🤖 Ошибка при обращении к AI-консультанту.")



async def handle_custom_mode_input(message: Message, user_id: int) -> None:
    """Обработка ввода параметров в ручном режиме."""
    global custom_mode_state, custom_mode_data
    
    state = custom_mode_state.get(user_id)
    if not state:
        return
    
    text = (message.text or "").strip()
    if not text:
        await message.answer("❌ Пустое значение. Попробуйте еще раз.")

        return
    
    # Кнопка отмены для всех этапов
    cancel_kb = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="❌ Отмена", callback_data=CUSTOM_CANCEL_CALLBACK_DATA)]]
    )
    
    # В шаге "voltage" допускаем ввод двух чисел через пробел: "16.50 1.4" (В и А)
    if state == "voltage":
        two = _parse_two_numbers(text)
        if two is not None:
            v_val, i_val = two
            if 12.0 <= v_val <= 17.0 and 0.1 <= i_val <= MAX_STAGE_CURRENT:
                custom_mode_data[user_id]["main_voltage"] = v_val
                custom_mode_data[user_id]["main_current"] = i_val
                custom_mode_state[user_id] = "delta"
                custom_mode_confirm.pop(user_id, None)
                await message.answer(
                    f"✅ Main: {v_val:.1f}В / {i_val:.1f}А\n\n"
                    "<b>Шаг 3/5:</b> Введите дельту (0.01 - 0.05):\n"
                    "<i>Чем меньше, тем чувствительнее финиш. Стандарт: 0.03</i>",
                    parse_mode=ParseMode.HTML,
                    reply_markup=cancel_kb
                )

                return
            await message.answer(
                f"⚠️ Допустимые диапазоны: напряжение 12–17 В, ток 0.1–{MAX_STAGE_CURRENT:.1f} А. Введите заново (например 16.50 1.4):",
                reply_markup=cancel_kb
            )

            return
    
    try:
        value = float(text.replace(",", "."))
    except ValueError:
        await message.answer("❌ Некорректное число. Введите значение заново:", reply_markup=cancel_kb)
        return
    
    # Валидация в зависимости от этапа
    if state == "voltage":
        if value > 17.0 or value < 12.0:
            await message.answer(
                "⚠️ Опасно! Значение слишком высокое или низкое.\n"
                "Введите напряжение Main (12.0 - 17.0В):",
                reply_markup=cancel_kb
            )
            return
        custom_mode_data[user_id]["main_voltage"] = value
        custom_mode_state[user_id] = "current"
        custom_mode_confirm.pop(user_id, None)  # Очищаем подтверждение при переходе
        await message.answer(
            f"✅ Main: {value:.1f}В\n\n"
            "<b>Шаг 2/5:</b> Введите лимит тока Main (например 5.0):\n"
            f"<i>Диапазон: 0.1 - {MAX_STAGE_CURRENT:.1f}А</i>",
            parse_mode=ParseMode.HTML,
            reply_markup=cancel_kb
        )
    
    elif state == "current":
        # Проверка критических значений
        if value > MAX_STAGE_CURRENT:
            await message.answer(
                f"🚫 ОШИБКА: RD6018 не поддерживает ток выше {MAX_STAGE_CURRENT:.1f}А. Введите корректное значение.",
                reply_markup=cancel_kb
            )
            return
        elif value < 0.1:
            await message.answer(
                f"⚠️ Слишком низкое значение. Введите лимит тока Main (0.1 - {MAX_STAGE_CURRENT:.1f}А):",
                reply_markup=cancel_kb
            )
            return
        
        # Проверка опасных значений (10.1 - 12.0А)
        elif value > 10.0:
            # Проверяем, не подтверждение ли это
            confirm_data = custom_mode_confirm.get(user_id, {})
            if confirm_data.get("step") == "current" and abs(confirm_data.get("value", 0) - value) < 0.01:
                # Подтверждение получено - принимаем опасное значение
                custom_mode_data[user_id]["main_current"] = value
                custom_mode_state[user_id] = "delta"
                custom_mode_confirm.pop(user_id, None)  # Очищаем подтверждение
                
                await message.answer(
                    f"⚠️ ПРИНЯТО: {custom_mode_data[user_id]['main_voltage']:.1f}В / {value:.1f}А\n\n"
                    "<b>Шаг 3/5:</b> Введите дельту (0.01 - 0.05):\n"
                    "<i>Чем меньше, тем чувствительнее финиш. Стандарт: 0.03</i>",
                    parse_mode=ParseMode.HTML,
                    reply_markup=cancel_kb
                )
            else:
                # Первый ввод опасного значения - требуем подтверждения
                custom_mode_confirm[user_id] = {"step": "current", "value": value}
                await message.answer(
                    f"⚠️ ВНИМАНИЕ: Ток {value:.1f}А выше 10А опасен для большинства АКБ и может перегреть RD6018.\n\n"
                    "Вы уверены? Введите ток еще раз для подтверждения или введите значение до 10А.",
                    reply_markup=cancel_kb
                )
            return
        
        # Безопасное значение (0.1 - 10.0А)
        else:
            custom_mode_data[user_id]["main_current"] = value
            custom_mode_state[user_id] = "delta"
            custom_mode_confirm.pop(user_id, None)  # Очищаем подтверждение если было
            
            await message.answer(
                f"✅ Main: {custom_mode_data[user_id]['main_voltage']:.1f}В / {value:.1f}А\n\n"
                "<b>Шаг 3/5:</b> Введите дельту (0.01 - 0.05):\n"
                "<i>Чем меньше, тем чувствительнее финиш. Стандарт: 0.03</i>",
                parse_mode=ParseMode.HTML,
                reply_markup=cancel_kb
            )
    
    elif state == "delta":
        if value < 0.005 or value > 0.1:
            await message.answer(
                "⚠️ Значение вне допустимого диапазона!\n"
                "Введите дельту (0.005 - 0.1В). Рекомендуется: 0.03В",
                reply_markup=cancel_kb
            )
            return
        custom_mode_data[user_id]["delta"] = value
        custom_mode_state[user_id] = "time_limit"
        custom_mode_confirm.pop(user_id, None)  # Очищаем подтверждение при переходе
        await message.answer(
            f"✅ Delta: {value:.3f}В\n\n"
            "<b>Шаг 4/5:</b> Введите лимит времени в часах (например 24):\n"
            "<i>Диапазон: 1 - 72ч. Заряд без присмотра запрещен!</i>",
            parse_mode=ParseMode.HTML,
            reply_markup=cancel_kb
        )
    
    elif state == "time_limit":
        if value <= 0 or value > 72:
            await message.answer(
                "⚠️ БЕЗОПАСНОСТЬ: Оставлять заряд без присмотра категорически запрещено.\n"
                "Введите лимит от 1 до 72 часов:",
                reply_markup=cancel_kb
            )
            return
        
        custom_mode_data[user_id]["time_limit"] = value
        custom_mode_state[user_id] = "capacity"
        custom_mode_confirm.pop(user_id, None)  # Очищаем подтверждение при переходе
        await message.answer(
            f"✅ Лимит: {value:.0f}ч\n\n"
            "<b>Шаг 5/5:</b> Введите ёмкость АКБ в Ah (например 60):\n"
            "<i>Диапазон: 10 - 300 Ah</i>",
            parse_mode=ParseMode.HTML,
            reply_markup=cancel_kb
        )
    
    elif state == "capacity":
        if value < 10 or value > 300:
            await message.answer(
                "⚠️ Значение вне допустимого диапазона!\n"
                "Введите ёмкость АКБ (10 - 300 Ah):",
                reply_markup=cancel_kb
            )
            return
        
        # Завершаем настройку
        custom_mode_data[user_id]["capacity"] = value
        data = custom_mode_data[user_id]
        
        # Очищаем состояние FSM
        del custom_mode_state[user_id]
        del custom_mode_data[user_id]
        custom_mode_confirm.pop(user_id, None)  # Очищаем подтверждение если было
        
        route = globals().get("manual_ui_route")
        if route is None or not callable(getattr(route, "submit", None)):
            logger.error("Manual UI START rejected: typed Manual route is unavailable")
            await message.answer("❌ Ручной режим недоступен: Manual-маршрут не инициализирован.")
            return
        try:
            intent = ManualUIIntent.from_dialog(
                user_id=user_id,
                chat_id=message.chat.id,
                params=data,
            )
            result = await route.submit(intent)
        except (KeyError, TypeError, ValueError) as exc:
            await message.answer(f"❌ Ручной режим не запущен: {exc}")
            return
        if not result.accepted:
            await message.answer(
                f"❌ Ручной режим не запущен: {result.reason or 'безопасное включение не подтверждено.'}"
            )
            return
        request = result.request
        await message.answer(
            "<b>🛠 Ручной режим запущен</b>\n"
            f"U = {request.voltage_v:.2f} V\n"
            f"I = {request.current_a:.2f} A\n"
            f"OVP = {request.ovp_v:.2f} V (рассчитано)\n"
            f"OCP = {request.ocp_a:.2f} A (рассчитано)\n"
            "Автоматическая химическая FSM отключена; действуют только заданные условия "
            "остановки и неотключаемая безопасность."
        )


def _cancel_custom_mode_state(user_id: int) -> None:
    """Clear compatibility Custom-wizard state without Telegram concerns."""

    custom_mode_state.pop(int(user_id), None)
    custom_mode_data.pop(int(user_id), None)
    custom_mode_confirm.pop(int(user_id), None)


_lifecycle = ProductionRuntimeLifecycle(sys.modules[__name__], _telegram_runtime)


async def on_shutdown(dispatcher: Dispatcher) -> None:
    await _lifecycle.on_shutdown(dispatcher)


async def main() -> None:
    await _lifecycle.run()


if __name__ == "__main__":
    asyncio.run(main())


